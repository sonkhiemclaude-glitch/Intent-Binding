"""The evaluated world: topology, operator, domain authorities and certified agents (paper Sec. 3, 7.3).

Parser, refiners and planner sit in an operations domain ``ops``; the executor sits in the SDN
domain ``sdn`` or, for slice intents, the 5G-core domain ``5g`` (so slice chains cross domains).
"""
from __future__ import annotations

from dataclasses import dataclass

from ..binding.protocol import Agent, DomainAuthority, Operator
from ..binding.verifier import Verifier
from ..crypto import KeyPair, h
from ..network.model import Topology

#: Logical clock used by the component evaluation (seconds). Validity windows are relative to it.
NOW = 1_000_000
#: Declared software hash certified for every scripted agent.
SW_HASH = h({"agent": "scripted", "version": "1.0"})
DOMAINS = ("ops", "sdn", "5g")


@dataclass
class World:
    topo: Topology
    op: Operator
    app_key: KeyPair  # an application key used by the "spoofed issuer" forgery class
    doms: dict
    agents: dict  # name -> Agent: parser, planner, refiner1.., exec-sdn, exec-5g
    verifiers: dict  # {"seqs": allowed role sequences}

    @classmethod
    def build(cls, max_refiners: int = 2, *, topo: Topology | None = None, key_seed: bytes | None = None) -> World:
        """Create keys, certificates and agents.

        ``key_seed`` derives deterministic test keys (byte-identical tokens across runs); ``None`` uses
        fresh random keys, as in the archived paper run. Detection decisions do not depend on key bytes.
        """
        if max_refiners < 0:
            raise ValueError("max_refiners must be >= 0")
        topo = topo or Topology()

        def key(kid: str) -> KeyPair:
            return KeyPair.generate(kid, key_seed)

        op = Operator("operator-1", key("op-1"))
        doms = {d: DomainAuthority(d, key(f"da-{d}")) for d in DOMAINS}
        agents = {}

        def mk(role: str, dom: str, kid: str) -> Agent:
            k = key(kid)
            a = Agent(role, dom, k)
            a.cert = doms[dom].certify(k, role, SW_HASH, NOW + 10**6)
            return a

        agents["parser"] = mk("parser", "ops", "ag-parser")
        agents["planner"] = mk("planner", "ops", "ag-planner")
        for r in range(1, max_refiners + 1):
            agents[f"refiner{r}"] = mk("refiner", "ops", f"ag-refiner{r}")
        agents["exec-sdn"] = mk("executor", "sdn", "ag-exec-sdn")
        agents["exec-5g"] = mk("executor", "5g", "ag-exec-5g")
        seqs = [tuple(["parser"] + ["refiner"] * r + ["planner", "executor"]) for r in range(max_refiners + 1)]
        return cls(topo, op, key("app-1"), doms, agents, {"seqs": seqs})

    def verifier(self, dom: str) -> Verifier:
        """A fresh verifier V for controller domain ``dom`` (one replay table per verifier)."""
        return Verifier(operators={self.op.oid: self.op.key.pk},
                        domain_roots={d: a.key.pk for d, a in self.doms.items()},
                        allowed_sequences=self.verifiers["seqs"], controller_dom=dom, now=NOW)


def exec_dom(itype: str) -> str:
    """Controller domain of the executor for an intent type."""
    return "5g" if itype == "slice" else "sdn"
