"""Running one fulfilment attempt through the bound pipeline (paper Sec. 4 and 7.3).

``run_pipeline`` executes parser -> refiner* -> planner -> executor, emitting a signed hop token at every
hop and a Merkle commitment at the executor. ``hop_hook(name, artefact) -> (signed_out, next_in)`` lets
an attack alter what a hop signs (``signed_out``) or what the next hop receives (``next_in``).
"""
from __future__ import annotations

import random
from collections.abc import Callable
from dataclasses import dataclass, field

from ..agents.base import AgentPolicy, ScriptedPolicy
from ..binding.protocol import executor_artifact
from ..binding.verifier import Bundle
from .world import NOW, World, exec_dom

HopHook = Callable[[str, dict], tuple]


@dataclass
class Episode:
    intent: dict  # the intent as received by the checker
    bundle: Bundle | None
    cmds: list  # commands arriving at the controller, in arrival order
    proofs: list  # Merkle proof presented with each arriving command
    plan: list  # the executor's committed plan
    family: str = "benign"
    cls: str = "none"
    benign_cmds: list = field(default_factory=list)  # benign counterfactual (same intent and seed)
    idx: list | None = None  # committed index claimed for each arriving command
    prior: Bundle | None = None  # replay classes: the earlier, legitimate execution

    def __post_init__(self) -> None:
        if self.idx is None:
            self.idx = list(range(len(self.cmds)))
        if len(self.proofs) != len(self.cmds) or len(self.idx) != len(self.cmds):
            raise ValueError("cmds, proofs and idx must have equal length")


def run_pipeline(world: World, intent: dict, rng_seed: int, n_refiners: int = 0, *, root: str | None = None,
                 hop_hook: HopHook | None = None, eid: str | None = None, detour_p: float = 0.2,
                 policy: AgentPolicy | None = None):
    """Return (bundle, commands as received by the controller, proofs).

    ``root`` overrides the operator-signed root (forgery classes). ``eid`` overrides the execution id.
    ``policy`` defaults to the paper's scripted agents.
    """
    if n_refiners < 0:
        raise ValueError("n_refiners must be >= 0")
    if n_refiners and f"refiner{n_refiners}" not in world.agents:
        raise ValueError(f"world was built with fewer than {n_refiners} refiners")
    policy = policy or ScriptedPolicy(world.topo, detour_p)
    rng = random.Random(rng_seed)
    eid = eid or f"E-{intent['iid']}-{rng_seed}"
    if root is None:
        root = world.op.sign_intent(intent, nonce=f"n-{intent['iid']}", iat=NOW - 10, exp=NOW + 3600)
    hops: list[str] = []
    certs: list[str] = []
    prev_tok, inp = root, intent
    # parser and refiners (paper Fig. 1)
    task = policy.parse(intent)
    stages = [("parser", world.agents["parser"])] + \
             [(f"refiner{r}", world.agents[f"refiner{r}"]) for r in range(1, n_refiners + 1)]
    for k, (name, ag) in enumerate(stages):
        out = task if k == 0 else policy.refine(task, k)
        signed_out, next_in = out, out
        if hop_hook:
            signed_out, next_in = hop_hook(name, out)
        tok = ag.emit(intent["iid"], len(hops) + 1, eid, prev_tok, inp, signed_out)
        hops.append(tok)
        certs.append(ag.cert)
        prev_tok, inp, task = tok, next_in, next_in
    # planner
    plan = policy.plan(task, rng)
    pl_art = {"iid": intent["iid"], "cmds": plan}
    signed_out, next_in = pl_art, pl_art
    if hop_hook:
        signed_out, next_in = hop_hook("planner", pl_art)
    ag = world.agents["planner"]
    tok = ag.emit(intent["iid"], len(hops) + 1, eid, prev_tok, inp, signed_out)
    hops.append(tok)
    certs.append(ag.cert)
    prev_tok, inp = tok, next_in
    # executor (honest): commits exactly the plan it received
    cmds = next_in["cmds"]
    art, proofs = executor_artifact(intent["iid"], eid, cmds)
    ex = world.agents["exec-" + exec_dom(intent["type"])]
    tok = ex.emit(intent["iid"], len(hops) + 1, eid, prev_tok, inp, art)
    hops.append(tok)
    certs.append(ex.cert)
    return Bundle(intent, root, hops, certs, art), list(cmds), proofs


def benign_episode(world: World, intent: dict, seed: int, n_refiners: int = 0, detour_p: float = 0.2,
                   policy: AgentPolicy | None = None) -> Episode:
    b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, detour_p=detour_p, policy=policy)
    return Episode(intent, b, cmds, proofs, list(cmds), benign_cmds=list(cmds))
