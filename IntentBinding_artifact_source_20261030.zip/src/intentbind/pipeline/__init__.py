"""World construction and bound-pipeline episodes (paper Sec. 3, 7.3)."""
