"""intentbind: reference implementation of "Intent Binding" (binding protocol + constraint conformance
for multi-agent intent-based networking pipelines).

No paper-level experimental results are claimed by this package unless real benchmark outputs are
generated and their provenance is recorded.
"""
__version__ = "1.0.0"
