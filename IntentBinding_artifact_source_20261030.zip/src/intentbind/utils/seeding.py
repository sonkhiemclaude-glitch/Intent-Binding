"""Seed derivation.

All randomness flows through explicit ``random.Random`` instances derived from the configured seeds, so
results do not depend on global state or on process scheduling (paper Sec. 7.3: 10 seeds x 200 intents).
The derivations below are part of the reproducibility contract with the archived paper run.
"""
from __future__ import annotations

import random
import zlib


def intent_rng(seed: int) -> random.Random:
    """RNG for drawing intents and refiner counts for one seed."""
    return random.Random(seed)


def episode_seed(seed: int, k: int) -> int:
    """Seed of the k-th intent's benign episode (planner RNG)."""
    return seed * 100003 + k


def attack_rng(episode_seed_value: int, family: str, cls: str) -> random.Random:
    """RNG for one attack class applied to one episode."""
    return random.Random(episode_seed_value * 31 + zlib.crc32(f"{family}/{cls}".encode()))
