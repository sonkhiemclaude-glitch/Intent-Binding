"""Experiment configuration (YAML) with validation.

Configs are plain data: they are never executed and may not contain shell commands. Unknown keys are
rejected so that typos do not silently fall back to defaults.
"""
from __future__ import annotations

import copy
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import yaml

from ..attacks.catalogue import ATTACKS
from ..defenses.runner import DEFENSES
from ..errors import ConfigError

SCOPE_MODES = ("strict", "path0", "path2")
LABELS = ("paper", "synthetic_smoke", "custom")
SYNTHETIC_LABEL_TEXT = "synthetic smoke-test output, not a paper result"


@dataclass
class IntentSource:
    source: str = "generator"  # "generator" (paper Sec. 7.3) | "file" (JSONL in IntentRecord schema)
    path: str | None = None


@dataclass
class MissAuditConfig:
    enabled: bool = True
    mode: str = "path2"


@dataclass
class OverheadConfig:
    enabled: bool = True
    reps_primitive: int = 3000  # paper: 3000 runs per primitive
    rounds_chain: int = 10  # paper: 10 interleaved rounds x 60 runs = 600 per point
    reps_chain_per_round: int = 60
    reps_conformance: int = 200
    max_hops: int = 8


@dataclass
class TestbedConfig:
    benign_intents: int = 40
    attacked_intents: int = 16
    seed: int = 11
    hosts_per_access: int = 2


@dataclass
class ExperimentConfig:
    name: str = "experiment"
    label: str = "custom"
    output_dir: str = "outputs/experiment"
    seeds: list[int] = field(default_factory=lambda: list(range(1, 11)))
    intents_per_seed: int = 200
    scope_modes: list[str] = field(default_factory=lambda: list(SCOPE_MODES))
    max_refiners: int = 2
    refiner_choices: list[int] = field(default_factory=lambda: [0, 1, 2])
    detour_p: float = 0.2
    defenses: list[str] = field(default_factory=lambda: list(DEFENSES))
    attack_families: list[str] = field(default_factory=lambda: list(ATTACKS))
    procs: int = 1
    key_seed: str | None = None
    intents: IntentSource = field(default_factory=IntentSource)
    miss_audit: MissAuditConfig = field(default_factory=MissAuditConfig)
    overhead: OverheadConfig = field(default_factory=OverheadConfig)
    testbed: TestbedConfig = field(default_factory=TestbedConfig)
    data: dict[str, Any] = field(default_factory=lambda: {"root": None})

    # ------------------------------------------------------------------ helpers
    @property
    def is_synthetic(self) -> bool:
        return self.label == "synthetic_smoke"

    def label_text(self) -> str:
        if self.label == "synthetic_smoke":
            return SYNTHETIC_LABEL_TEXT
        if self.label == "paper":
            return "paper-configuration run; see run_metadata.json for provenance"
        return "custom run; not a paper result unless its provenance is recorded"

    def key_seed_bytes(self) -> bytes | None:
        return None if self.key_seed is None else str(self.key_seed).encode()

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def validate(self) -> ExperimentConfig:
        if self.label not in LABELS:
            raise ConfigError(f"label must be one of {LABELS}, got {self.label!r}")
        if not self.seeds or any(not isinstance(s, int) or s < 0 for s in self.seeds):
            raise ConfigError("seeds must be a non-empty list of non-negative integers")
        if len(set(self.seeds)) != len(self.seeds):
            raise ConfigError("seeds must be unique")
        if not isinstance(self.intents_per_seed, int) or self.intents_per_seed < 1:
            raise ConfigError("intents_per_seed must be a positive integer")
        bad = [m for m in self.scope_modes if m not in SCOPE_MODES]
        if bad or not self.scope_modes:
            raise ConfigError(f"scope_modes must be a non-empty subset of {SCOPE_MODES}; bad: {bad}")
        if self.max_refiners < 0 or any(r < 0 or r > self.max_refiners for r in self.refiner_choices):
            raise ConfigError("refiner_choices must lie in [0, max_refiners]")
        if self.max_refiners < 1 and "drift" in self.attack_families:
            raise ConfigError("the drift family needs max_refiners >= 1")
        if not 0.0 <= float(self.detour_p) <= 1.0:
            raise ConfigError("detour_p must be in [0, 1]")
        bad = [d for d in self.defenses if d not in DEFENSES]
        if bad or not self.defenses:
            raise ConfigError(f"defenses must be a non-empty subset of {DEFENSES}; bad: {bad}")
        bad = [f for f in self.attack_families if f not in ATTACKS]
        if bad:
            raise ConfigError(f"unknown attack families {bad}; known: {list(ATTACKS)}")
        if self.procs < 1:
            raise ConfigError("procs must be >= 1")
        if self.intents.source not in ("generator", "file"):
            raise ConfigError("intents.source must be 'generator' or 'file'")
        if self.intents.source == "file" and not self.intents.path:
            raise ConfigError("intents.path is required when intents.source is 'file'")
        if self.miss_audit.mode not in SCOPE_MODES:
            raise ConfigError("miss_audit.mode must be a scope mode")
        for k in ("reps_primitive", "rounds_chain", "reps_chain_per_round", "reps_conformance"):
            if getattr(self.overhead, k) < 1:
                raise ConfigError(f"overhead.{k} must be >= 1")
        if self.overhead.max_hops < 3:
            raise ConfigError("overhead.max_hops must be >= 3 (parser, planner, executor)")
        return self


_SECTIONS = {"intents": IntentSource, "miss_audit": MissAuditConfig, "overhead": OverheadConfig,
             "testbed": TestbedConfig}


def config_from_dict(raw: dict[str, Any], base_dir: Path | None = None) -> ExperimentConfig:
    raw = copy.deepcopy(raw or {})
    known = set(ExperimentConfig.__dataclass_fields__)
    unknown = sorted(set(raw) - known)
    if unknown:
        raise ConfigError(f"unknown config keys {unknown}")
    kwargs: dict[str, Any] = {}
    for key, value in raw.items():
        if key in _SECTIONS:
            cls: Any = _SECTIONS[key]
            if not isinstance(value, dict):
                raise ConfigError(f"{key} must be a mapping")
            unk = sorted(set(value) - set(cls.__dataclass_fields__))
            if unk:
                raise ConfigError(f"unknown keys in {key}: {unk}")
            kwargs[key] = cls(**value)
        elif key == "seeds" and isinstance(value, dict):
            start, count = int(value.get("start", 1)), int(value.get("count", 1))
            kwargs[key] = list(range(start, start + count))
        else:
            kwargs[key] = value
    cfg = ExperimentConfig(**kwargs)
    if cfg.intents.path and base_dir is not None and not Path(cfg.intents.path).is_absolute():
        candidate = (base_dir / cfg.intents.path).resolve()
        if candidate.exists():
            cfg.intents.path = str(candidate)
    return cfg.validate()


def load_config(path: str | Path, overrides: dict[str, Any] | None = None) -> ExperimentConfig:
    p = Path(path)
    if not p.exists():
        raise ConfigError(f"config file not found: {p}")
    with p.open() as f:
        raw = yaml.safe_load(f) or {}
    if not isinstance(raw, dict):
        raise ConfigError("config root must be a mapping")
    raw.update(overrides or {})
    return config_from_dict(raw, base_dir=p.parent)
