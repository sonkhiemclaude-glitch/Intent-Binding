"""Comparison of result dictionaries with a float tolerance.

Aggregates recomputed with other numpy/pandas versions can differ in the last bit (summation order), so
exact JSON equality is too strict; 1e-12 absolute is far below any reported precision (0.1 percentage point).
"""
from __future__ import annotations

import math
from typing import Any


def equal_within(a: Any, b: Any, atol: float = 1e-12) -> bool:
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(equal_within(a[k], b[k], atol) for k in a)
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(equal_within(x, y, atol) for x, y in zip(a, b))
    if isinstance(a, bool) or isinstance(b, bool):
        return a == b
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        if isinstance(a, float) and isinstance(b, float) and math.isnan(a) and math.isnan(b):
            return True
        return abs(a - b) <= atol
    return a == b


def differing_keys(old: dict, new: dict, atol: float = 1e-12) -> list[str]:
    """Top-level keys of ``old`` whose values differ in ``new`` beyond ``atol``."""
    return sorted(k for k in old if k not in new or not equal_within(old[k], new[k], atol))
