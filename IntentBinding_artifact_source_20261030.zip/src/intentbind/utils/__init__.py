"""Configuration, I/O, provenance, logging and seeding utilities."""
