"""Small, safe file helpers (atomic JSON writes, JSONL)."""
from __future__ import annotations

import json
import math
from collections.abc import Iterable
from pathlib import Path
from typing import Any


def _clean(obj: Any) -> Any:
    """Replace non-finite floats with None so the JSON is standard (no NaN literals)."""
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    return obj


def write_json(path: str | Path, obj: Any, indent: int = 1) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(_clean(obj), indent=indent, default=float))
    tmp.replace(p)
    return p


def read_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text())


def write_jsonl(path: str | Path, records: Iterable[dict]) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w") as f:
        for r in records:
            f.write(json.dumps(r, sort_keys=True) + "\n")
    return p


def read_jsonl(path: str | Path) -> list[dict]:
    out = []
    with Path(path).open() as f:
        for n, line in enumerate(f, start=1):
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError as e:
                raise ValueError(f"{path}:{n}: invalid JSON ({e})") from e
            if not isinstance(rec, dict):
                raise ValueError(f"{path}:{n}: each line must be a JSON object")
            out.append(rec)
    return out
