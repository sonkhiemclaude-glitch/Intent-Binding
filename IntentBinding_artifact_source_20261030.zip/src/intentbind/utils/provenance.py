"""Run metadata and result provenance.

Every experiment stage writes ``run_metadata.json`` next to its outputs: config snapshot, label,
package version, interpreter and library versions, platform, command line, start/end time and the
SHA-256 of every output file. Tables and figures are only generated from such files.
"""
from __future__ import annotations

import hashlib
import json
import platform
import sys
import time
from importlib import metadata
from pathlib import Path
from typing import Any

from .. import __version__


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _version(pkg: str) -> str | None:
    try:
        return metadata.version(pkg)
    except metadata.PackageNotFoundError:
        return None


def environment() -> dict[str, Any]:
    return {
        "intentbind": __version__,
        "python": platform.python_version(),
        "implementation": platform.python_implementation(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "libraries": {p: _version(p) for p in ("cryptography", "networkx", "numpy", "pandas", "scipy",
                                               "matplotlib", "PyYAML")},
    }


class RunRecord:
    """Collects metadata for one stage and writes it atomically at the end."""

    def __init__(self, stage: str, out_dir: str | Path, config: dict[str, Any] | None, label: str):
        self.stage = stage
        self.out_dir = Path(out_dir)
        self.meta: dict[str, Any] = {
            "stage": stage,
            "label": label,
            "config": config,
            "argv": list(sys.argv),
            "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "environment": environment(),
            "outputs": {},
        }
        self._t0 = time.time()

    def add_output(self, path: str | Path) -> None:
        p = Path(path)
        self.meta["outputs"][p.name] = {"sha256": sha256_file(p), "bytes": p.stat().st_size}

    def write(self, extra: dict[str, Any] | None = None) -> Path:
        self.meta["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        self.meta["wall_seconds"] = round(time.time() - self._t0, 3)
        if extra:
            self.meta.update(extra)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        path = self.out_dir / f"run_metadata_{self.stage}.json"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.meta, indent=1, sort_keys=True, default=str))
        tmp.replace(path)
        return path


def verify_manifest(directory: str | Path, manifest_name: str = "MANIFEST.sha256") -> list[str]:
    """Check files against a ``sha256  filename`` manifest; return a list of problems (empty = OK)."""
    d = Path(directory)
    man = d / manifest_name
    if not man.exists():
        return [f"missing manifest {man}"]
    problems = []
    for line in man.read_text().splitlines():
        if not line.strip():
            continue
        digest, name = line.split(maxsplit=1)
        f = d / name.strip()
        if not f.exists():
            problems.append(f"missing file {name}")
        elif sha256_file(f) != digest:
            problems.append(f"checksum mismatch {name}")
    return problems
