"""Natural-language intent to IntentRecord. NOT IMPLEMENTED (paper Sec. 8; experiment plan E5).

The paper's intents are generated structurally (``intents.generator``); free-text intents are not parsed.
An implementation would map operator text to a type and spec (docs/data_format.md), after which
``data.intent_sets.compile_record`` produces the signed constraints with the template library.
"""
from __future__ import annotations

from ..errors import ExternalDependencyMissing


def parse_nl_intent(text: str) -> dict:
    raise ExternalDependencyMissing(
        "natural-language intent parsing is not implemented (TODO T-NL-1); provide IntentRecords as JSONL")
