"""Intent generation and compilation to constraint templates (paper Sec. 5, Table 2)."""
