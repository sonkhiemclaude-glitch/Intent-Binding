"""Template-library compiler (paper Sec. 5, "Compilation", "Scope modes"; Table 2).

Maps each of the five intent types to a fixed set of templates and fills their parameters from
the structured spec. The compiled list Phi_I is a field of the intent object and therefore part
of the operator-signed digest (Sec. 4, "Intent object")."""
from __future__ import annotations

from typing import Any

from ..network.model import INFRA, Topology

COMPILER = "ib-templates/1.0"
PORTS = (22, 80, 443, 3389)
INTENT_TYPES = ("isolate", "block", "bandwidth", "waypoint", "slice")

OPS_BY_TYPE = {
    "isolate": ["isolate", "read_stats"],
    "block": ["block", "read_stats"],
    "bandwidth": ["route", "set_bw", "read_stats"],
    "waypoint": ["route", "read_stats"],
    "slice": ["create_slice", "assign_ue", "set_slice_qos"],
}


def _paths_union(topo, pairs, slack):
    sw = set()
    for a, b in pairs:
        for p in topo.host_paths(a, b, slack):
            sw.update(p)
    return sw


def _waypoint_paths(topo, a, b, w, slack):
    """All simple switch paths edge(a) -> w -> edge(b) at most ``slack`` hops longer than shortest."""
    cache = topo.__dict__.setdefault("_wp_cache", {})
    key = (topo.edge_of[a], topo.edge_of[b], w, slack)
    if key not in cache:
        cache[key] = _waypoint_paths_raw(topo, a, b, w, slack)
    return list(cache[key])


def _waypoint_paths_raw(topo, a, b, w, slack):
    import networkx as nx
    g = topo.g
    sa, sb = topo.edge_of[a], topo.edge_of[b]
    d = nx.shortest_path_length(g, sa, w) + nx.shortest_path_length(g, w, sb)
    out = []
    p2s = list(nx.all_simple_paths(g, w, sb, cutoff=d + slack))
    for p1 in nx.all_simple_paths(g, sa, w, cutoff=d + slack):
        for p2 in p2s:
            p = list(p1) + list(p2[1:])
            inner = p[1:-1]
            if (len(p) - 1 <= d + slack and len(set(inner)) == len(inner)
                    and p[0] not in inner and p[-1] not in inner):
                out.append(tuple(p))
    return out


def scope_switches(topo, itype, spec, mode):
    if itype in ("isolate",):
        return {topo.edge_of[spec["host"]]}
    if itype == "block":
        return {topo.edge_of[spec["dst"]]} | {topo.edge_of[s] for s in spec["srcs"]}
    if itype == "slice":
        return set()
    a, b = spec["src"], spec["dst"]
    if mode == "strict":
        sw = {topo.edge_of[a], topo.edge_of[b]}
        if itype == "waypoint":
            sw.add(spec["via"])
        return sw
    slack = {"path0": 0, "path2": 2}[mode]
    if itype == "bandwidth":
        return _paths_union(topo, [(a, b)], slack)
    sw = set()
    for p in _waypoint_paths(topo, a, b, spec["via"], slack):
        sw.update(p)
    return sw


def compile_intent(topo: Topology, itype: str, spec: dict, mode: str):
    """Template library. Returns a list of constraint dicts (ids are positional)."""
    C: list[dict[str, Any]] = [{"t": "opset", "ops": OPS_BY_TYPE[itype]}]
    if itype != "slice":
        C.append({"t": "scope_sw", "allowed": sorted(scope_switches(topo, itype, spec, mode))})
    if itype == "isolate":
        h = spec["host"]
        neigh = [x for x in topo.subnet[topo.edge_of[h]] if x != h]
        C += [
            {"t": "scope_param", "op": "isolate", "param": "host", "allowed": [h]},
            {"t": "frame", "allowed": [["host", h]]},
            {"t": "invariant_reach", "pairs": [[x, y] for x in neigh for y in ("gw", "dns")]},
            {"t": "goal_isolated", "host": h, "probe": sorted(set(topo.hosts + list(INFRA)) - {h})},
        ]
    elif itype == "block":
        C += [
            {"t": "scope_param", "op": "block", "param": "src", "allowed": spec["srcs"]},
            {"t": "scope_param", "op": "block", "param": "dst", "allowed": [spec["dst"]]},
            {"t": "scope_param", "op": "block", "param": "port", "allowed": [spec["port"]]},
            {"t": "frame", "allowed": [["pair", s, spec["dst"]] for s in spec["srcs"]]},
            {"t": "invariant_reach", "pairs": [[s, spec["dst"]] for s in spec["srcs"]]},
            {"t": "goal_blocked", "srcs": spec["srcs"], "dst": spec["dst"], "port": spec["port"]},
        ]
    elif itype in ("bandwidth", "waypoint"):
        a, b = spec["src"], spec["dst"]
        C += [
            {"t": "scope_param", "op": "route", "param": "src", "allowed": [a]},
            {"t": "scope_param", "op": "route", "param": "dst", "allowed": [b]},
            {"t": "frame", "allowed": [["flow", a, b]]},
            {"t": "invariant_reach", "pairs": [[a, b]]},
        ]
        if itype == "bandwidth":
            C += [
                {"t": "scope_param", "op": "set_bw", "param": "src", "allowed": [a]},
                {"t": "scope_param", "op": "set_bw", "param": "dst", "allowed": [b]},
                {"t": "bound", "op": "set_bw", "param": "rate", "lo": spec["min"], "hi": spec["max"]},
                {"t": "goal_bw", "src": a, "dst": b, "lo": spec["min"], "hi": spec["max"]},
            ]
        else:
            C += [{"t": "goal_via", "src": a, "dst": b, "via": spec["via"]}]
    elif itype == "slice":
        s = spec["slice"]
        C += [
            {"t": "scope_param", "op": "create_slice", "param": "slice", "allowed": [s]},
            {"t": "scope_param", "op": "set_slice_qos", "param": "slice", "allowed": [s]},
            {"t": "scope_param", "op": "assign_ue", "param": "slice", "allowed": [s]},
            {"t": "scope_param", "op": "assign_ue", "param": "ue", "allowed": spec["ues"]},
            {"t": "bound", "op": "create_slice", "param": "rate", "lo": spec["min"], "hi": spec["max"]},
            {"t": "bound", "op": "set_slice_qos", "param": "rate", "lo": spec["min"], "hi": spec["max"]},
            {"t": "precedence", "a": "create_slice", "b": "assign_ue", "key": "slice"},
            {"t": "frame", "allowed": [["slice", s]] + [["ue", u] for u in spec["ues"]]},
            {"t": "goal_slice", "slice": s, "ues": spec["ues"], "lo": spec["min"], "hi": spec["max"]},
        ]
    for i, c in enumerate(C):
        c["id"] = f"phi{i}"
    return C


