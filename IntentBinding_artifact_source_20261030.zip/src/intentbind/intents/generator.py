"""Intent generator for the component evaluation (paper Sec. 7.3, "Intents and agents").

Each seed draws intents of five types (isolate, block, bandwidth, waypoint, slice) with random
endpoints, ports, rate bounds and UE sets. This generated workload *is* the paper's evaluation
workload; it is not a stand-in for an external dataset.
"""
from __future__ import annotations

import random

from ..network.model import Topology
from .compiler import COMPILER, PORTS, compile_intent


def gen_spec(topo: Topology, rng: random.Random, itype: str, n: int):
    hosts = topo.hosts
    if itype == "isolate":
        h = rng.choice(hosts)
        return {"host": h}, f"Isolate host {h}; its neighbours must stay connected to the gateway and DNS."
    if itype == "block":
        sub = rng.choice(sorted(topo.subnet))
        dst = rng.choice([x for x in hosts if topo.edge_of[x] != sub])
        port = rng.choice(PORTS)
        return ({"src_subnet": sub, "srcs": list(topo.subnet[sub]), "dst": dst, "port": port},
                f"Block TCP port {port} from subnet {sub} to {dst}; other traffic must still flow.")
    if itype == "bandwidth":
        a, b = rng.sample(hosts, 2)
        lo = rng.choice([50, 100, 200])
        hi = lo + rng.choice([50, 100, 200])
        return ({"src": a, "dst": b, "min": lo, "max": hi},
                f"Guarantee between {lo} and {hi} Mbps from {a} to {b}.")
    if itype == "waypoint":
        a, b = rng.sample(hosts, 2)
        return ({"src": a, "dst": b, "via": "fw1"},
                f"Traffic from {a} to {b} must traverse firewall fw1.")
    if itype == "slice":
        s = f"s-{n}"
        lo = rng.choice([20, 50, 100])
        hi = lo + rng.choice([20, 50, 100])
        ues = rng.sample(topo.ues, rng.choice([2, 3, 4]))
        return ({"slice": s, "min": lo, "max": hi, "ues": ues},
                f"Create slice {s} with {lo}-{hi} Mbps and attach {', '.join(ues)}.")
    raise ValueError(itype)


def make_intent(topo: Topology, rng: random.Random, itype: str, n: int, mode: str, prefix="I"):
    spec, text = gen_spec(topo, rng, itype, n)
    return {"iid": f"{prefix}-{n}", "type": itype, "text": text, "spec": spec,
            "compiler": COMPILER, "scope_mode": mode,
            "constraints": compile_intent(topo, itype, spec, mode)}
