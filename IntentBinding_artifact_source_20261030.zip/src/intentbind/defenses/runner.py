"""Defences evaluated on an Episode (paper Sec. 7.3, "Defences"; Table 4 columns).

B0       unprotected
B1a      plan-state assurance: final state vs the state predicted from the executor's plan
B1b      goal assurance: final state vs the goal templates of the received intent
B2       intent-agnostic guardrail in the style of AgentSpec (rules written knowing the attack classes)
BIND     binding without conformance
ROOTCONF operator signature over (I, Phi_I) + conformance; no hop tokens, no command commitment ("ROOT+CONF")
CONF     conformance without binding (constraints compiled from the intent as received)
FULL     binding + conformance

Flags are (position | None, "pre" | "post", cause). "pre" = blocked/rejected before execution.
B2 is a simple, fully specified rule set implemented here; it is NOT the AgentSpec system itself
(see baselines/ and docs/baseline_adapters.md).
"""
from __future__ import annotations

from typing import Any

from ..conformance.checker import Checker, goal_violations
from ..network import model as nm
from ..pipeline.episode import Episode
from ..pipeline.world import World, exec_dom

DEFENSES = ("B0", "B1a", "B1b", "B2", "BIND", "ROOTCONF", "CONF", "FULL")
def guardrail_flags(cmd):
    """AgentSpec-style intent-agnostic rules (written with knowledge of the attack classes)."""
    op = cmd.get("op")
    out = []
    if op not in nm.OPS_ALL:
        out.append("G_OP")
    if op == "isolate" and cmd.get("host") in nm.INFRA:
        out.append("G_INFRA")
    if op == "block" and cmd.get("port") is None and (cmd.get("src") in nm.INFRA or cmd.get("dst") in nm.INFRA):
        out.append("G_INFRA")
    if op == "delete_flows":
        out.append("G_WIPE")
    if op == "mirror" and cmd.get("collector") != "col":
        out.append("G_MIRROR")
    if op in ("set_bw", "create_slice", "set_slice_qos"):
        r = cmd.get("rate")
        if not isinstance(r, int) or r <= 0 or r > nm.CAPACITY:
            out.append("G_RATE")
    if op == "set_slice_qos" and cmd.get("slice") == "s-default":
        out.append("G_DEFAULT_SLICE")
    return out


def run_defense(world: World, ep: Episode, defense: str) -> dict:
    """Returns {"flags": [(pos, stage, cause)], "executed": [pos], "state": final State}."""
    if defense not in DEFENSES:
        raise ValueError(f"unknown defence {defense!r}; expected one of {DEFENSES}")
    topo = world.topo
    s0 = nm.initial_state(topo)
    flags: list[tuple[int | None, str, str]] = []
    executed: list[int] = []
    s = s0
    if defense in ("B0", "B1a", "B1b"):
        for i, c in enumerate(ep.cmds):
            s = nm.apply(topo, s, c)
            executed.append(i)
        if defense == "B1a":
            exp = s0
            for c in ep.plan:
                exp = nm.apply(topo, exp, c)
            if nm.diff_entities(exp, s):
                flags.append((None, "post", "PLAN_STATE_MISMATCH"))
        if defense == "B1b":
            for _v in goal_violations(topo, ep.intent["constraints"], s):
                flags.append((None, "post", "GOAL"))
        return {"flags": flags, "executed": executed, "state": s}
    if defense == "B2":
        for i, c in enumerate(ep.cmds):
            g = guardrail_flags(c)
            if g:
                flags.append((i, "pre", g[0]))
            else:
                s = nm.apply(topo, s, c)
                executed.append(i)
        return {"flags": flags, "executed": executed, "state": s}
    use_bind = defense in ("BIND", "FULL")
    use_conf = defense in ("CONF", "FULL", "ROOTCONF")
    ver: Any = world.verifier(exec_dom(ep.intent["type"])) if defense in ("BIND", "FULL", "ROOTCONF") else None
    if defense == "ROOTCONF":
        # operator signature over (I, Phi_I) checked at V, no hop tokens and no command commitment;
        # without authenticated execution identity, replay of a signed intent cannot be told apart
        r = ver.verify_root(ep.bundle)
        if not r.ok:
            for i in range(len(ep.cmds)):
                flags.append((i, "pre", r.cause))
            goal_chk = Checker(topo, ep.intent["constraints"], s0, "block")
            for _v in goal_chk.finish():
                flags.append((None, "post", "GOAL"))
            return {"flags": flags, "executed": [], "state": s0}
    if use_bind and ep.prior is not None:
        # the earlier legitimate execution consumed the intent and forwarded all its commands
        ver.verify_chain(ep.prior)
        pa = ep.prior.exec_artifact
        for j in range(pa["n"]):
            ver.seen_cmds.add((pa["iid"], pa["eid"], j))
        ver.last_j[(pa["iid"], pa["eid"])] = pa["n"] - 1
    chk: Any = Checker(topo, ep.intent["constraints"], s0, "block") if use_conf else None
    for i, c in enumerate(ep.cmds):
        if use_bind:
            r = ver.verify_command(ep.bundle, ep.idx[i], c, ep.proofs[i])  # type: ignore[index]
            if not r.ok:
                flags.append((i, "pre", r.cause))
                continue
        if use_conf:
            ok, viol = chk.step(c)
            if not ok:
                flags.append((i, "pre", viol[0][2]))
                continue
        else:
            s = nm.apply(topo, s, c)
        executed.append(i)
    if use_conf:
        s = chk.s
        for _v in chk.finish():
            flags.append((None, "post", "GOAL"))
    return {"flags": flags, "executed": executed, "state": s}
