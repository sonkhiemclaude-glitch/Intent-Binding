"""Defences B0..FULL evaluated in the paper (Table 4 columns)."""
