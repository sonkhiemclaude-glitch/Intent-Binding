"""Attack catalogue: 34 classes in seven families (paper Table 3, Sec. 7.3).

Threat labels refer to draft-jiang-intent-security-03 (T1 directive tampering, T4 multi-hop semantic
drift, T6 origin spoofing). Injected actions have no single draft label (signed by an honest agent
steered by data it read).
"""
from __future__ import annotations

from dataclasses import dataclass

#: family -> classes, in the paper's order. Order matters for RNG-reproducible runs.
ATTACKS: dict[str, list[str]] = {
    "tamper_channel": ["widen", "relax", "redirect", "hijack"],
    "insider": ["widen", "relax", "redirect", "hijack", "inbound"],
    "forgery": ["unsigned", "spoofed_issuer", "replay", "replay_same_eid", "expired", "body_modified", "splice"],
    "injection": ["infra_isolate", "mirror", "delete_flows", "bw_grab", "cut", "in_scope"],
    "drift": ["widen", "relax", "drop_step", "shift"],
    "cmd_injection": ["infra_isolate", "mirror", "delete_flows", "bw_grab", "cut"],
    "exec_tamper": ["relax", "redirect", "reorder"],
}

#: Families whose deviation requires a key the adversary lacks (detected by binding).
CHAIN_FAMILIES = frozenset({"tamper_channel", "forgery", "cmd_injection", "exec_tamper"})
#: Families where a key holder signs the deviation (binding gives attribution only, Prop. 3).
KEYHOLDER_FAMILIES = frozenset({"insider", "injection", "drift"})
#: Classes designed to stay within the signed constraints (excluded from the second aggregate row of Table 4).
WITHIN_INTENT = frozenset({("insider", "inbound"), ("injection", "in_scope")})


@dataclass(frozen=True)
class FamilyInfo:
    name: str
    label: str  # as printed in Table 4
    threat: str  # draft-jiang-intent-security-03 label, '-' if none
    injection_point: str


FAMILIES: dict[str, FamilyInfo] = {
    "tamper_channel": FamilyInfo("tamper_channel", "Hop tampering in transit", "T1",
                                 "planner output altered on the channel to the executor (key not held)"),
    "insider": FamilyInfo("insider", "Keyed insider (planner)", "T1", "compromised planner signs an altered plan"),
    "forgery": FamilyInfo("forgery", "Origin forgery and replay", "T6",
                          "root, intent body or chain forged, expired, replayed or spliced"),
    "injection": FamilyInfo("injection", "Injected action (signed)", "-",
                            "honest planner steered by data it read adds one signed command"),
    "drift": FamilyInfo("drift", "Multi-hop semantic drift", "T4", "refiners reinterpret the task"),
    "cmd_injection": FamilyInfo("cmd_injection", "Command injection at controller", "T1",
                                "compromised tool layer inserts an uncommitted command"),
    "exec_tamper": FamilyInfo("exec_tamper", "Command tampering after commit", "T1",
                              "committed command altered or reordered between executor and V"),
}


def all_classes() -> list[tuple[str, str]]:
    """(family, class) pairs in catalogue order."""
    return [(f, c) for f, cs in ATTACKS.items() for c in cs]


assert len(all_classes()) == 34, "paper Table 3 lists 34 attack classes"
