"""Building attacked episodes for every family and class (paper Table 3, Sec. 7.3).

Each attacked episode is paired with the benign episode of the same intent and seed
(``Episode.benign_cmds``). Moved unchanged from the code that produced the archived paper run.
"""
from __future__ import annotations

import copy
import random
import zlib

from ..binding.verifier import Bundle
from ..crypto import b64u, h, jws_sign
from ..errors import NotApplicable
from ..intents.compiler import compile_intent
from ..intents.generator import make_intent
from ..pipeline.episode import Episode, benign_episode, run_pipeline
from ..pipeline.world import NOW
from .generators import _neighbor, drift_task, injected_cmd, mutate_plan


def attack_episode(world, intent, seed, family, cls, n_refiners=0, detour_p=0.2, rng=None, mode="strict"):
    rng = rng or random.Random(seed * 7919 + zlib.crc32(f"{family}/{cls}".encode()))
    topo = world.topo
    base = benign_episode(world, intent, seed, n_refiners, detour_p)
    task0 = {"type": intent["type"], "spec": intent["spec"]}

    if family in ("tamper_channel", "insider", "injection"):
        def hook(name, art):
            if name != "planner":
                return art, art
            if family == "injection":
                new = copy.deepcopy(art)
                x = injected_cmd(topo, task0, art["cmds"], cls, rng)
                new["cmds"].insert(rng.randrange(len(new["cmds"]) + 1), x)
            else:
                m = mutate_plan(topo, task0, art["cmds"], cls, rng)
                if m is None:
                    raise NotApplicable
                new = {"iid": art["iid"], "cmds": m}
            if family == "tamper_channel":
                return art, new  # planner signs original; executor receives modified
            return new, new  # insider/injected planner signs what it outputs
        b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, hop_hook=hook, detour_p=detour_p)
        return Episode(intent, b, cmds, proofs, list(cmds), family, cls, base.cmds)

    if family == "drift":
        nh = max(1, n_refiners)
        # apply drift inside refiners (and parser when no refiner): each hop drifts w.p. 0.5, at least once
        hops_drift = [rng.random() < 0.5 for _ in range(nh)]
        if not any(hops_drift):
            hops_drift[rng.randrange(nh)] = True
        state = {"i": 0}
        def dhook(name, art):
            if (n_refiners and name.startswith("refiner")) or (not n_refiners and name == "parser"):
                i = state["i"]
                state["i"] += 1
                if hops_drift[i]:
                    art = drift_task(topo, art, cls, rng)
                return art, art
            return art, art
        b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, hop_hook=dhook, detour_p=detour_p)
        return Episode(intent, b, cmds, proofs, list(cmds), family, cls, base.cmds)

    if family == "forgery":
        if cls == "unsigned":
            hdr = b64u(b'{"alg":"EdDSA","kid":"op-1","typ":"ib-intent"}')
            pl = b64u(b'{}')
            root = hdr + "." + pl + "." + b64u(b"\x00" * 64)
            b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, root=root, detour_p=detour_p)
        elif cls == "spoofed_issuer":
            payload = {"iid": intent["iid"], "iss": world.op.oid, "dig": h(intent), "nonce": "x",
                       "iat": NOW - 10, "exp": NOW + 3600}
            root = jws_sign(payload, world.app_key, "ib-intent")
            b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, root=root, detour_p=detour_p)
        elif cls == "expired":
            root = world.op.sign_intent(intent, nonce="old", iat=NOW - 7200, exp=NOW - 3600)
            b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, root=root, detour_p=detour_p)
        elif cls == "replay":
            # same signed intent re-run as a second execution (new eid); the first execution is
            # registered at the verifier by the caller via 'prior' bundle
            b, cmds, proofs = run_pipeline(world, intent, seed, n_refiners, eid=f"E-replay-{seed}", detour_p=detour_p)
            return Episode(intent, b, cmds, proofs, list(cmds), family, cls, [], prior=base.bundle)
        elif cls == "replay_same_eid":
            # a key holder re-plans the consumed intent under the same execution identifier
            b, cmds, proofs = run_pipeline(world, intent, seed + 1, n_refiners, eid=f"E-{intent['iid']}-{seed}",
                                           detour_p=detour_p)
            return Episode(intent, b, cmds, proofs, list(cmds), family, cls, [], prior=base.bundle)
        elif cls == "body_modified":
            mod = copy.deepcopy(intent)
            s = mod["spec"]
            if "max" in s:
                s["max"] += 300
            elif mod["type"] == "isolate":
                s["host"] = _neighbor(topo, s["host"], rng)
            elif mod["type"] == "block":
                s["dst"] = _neighbor(topo, s["dst"], rng)
            else:
                s["dst"] = _neighbor(topo, s["dst"], rng)
            mod["constraints"] = compile_intent(topo, mod["type"], s, mod["scope_mode"])
            root = world.op.sign_intent(intent, nonce=f"n-{intent['iid']}", iat=NOW - 10, exp=NOW + 3600)
            b, cmds, proofs = run_pipeline(world, mod, seed, n_refiners, root=root, detour_p=detour_p)
            return Episode(mod, b, cmds, proofs, list(cmds), family, cls, [])
        elif cls == "splice":
            other = make_intent(topo, random.Random(seed + 99991), intent["type"], 10**6 + seed, intent["scope_mode"],
                                prefix="Y")
            by, cmds, proofs = run_pipeline(world, other, seed + 1, n_refiners, detour_p=detour_p)
            b = Bundle(intent, base.bundle.root, by.hops, by.certs, by.exec_artifact)
            return Episode(intent, b, cmds, proofs, list(cmds), family, cls, [])
        return Episode(intent, b, cmds, proofs, list(cmds), family, cls, [])

    if family == "cmd_injection":
        x = injected_cmd(topo, task0, base.cmds, cls, rng)
        pos = rng.randrange(len(base.cmds) + 1)
        cmds = base.cmds[:pos] + [x] + base.cmds[pos:]
        proofs = base.proofs[:pos] + [base.proofs[0]] + base.proofs[pos:]
        idx = list(range(pos)) + [0] + list(range(pos, len(base.cmds)))
        return Episode(intent, base.bundle, cmds, proofs, base.cmds, family, cls, base.cmds, idx=idx)

    if family == "exec_tamper" and cls == "reorder":
        # tool layer forwards two committed commands in swapped order (valid proofs, wrong order)
        if len(base.cmds) < 2:
            raise NotApplicable
        i = rng.randrange(len(base.cmds) - 1)
        order = list(range(len(base.cmds)))
        order[i], order[i + 1] = order[i + 1], order[i]
        if base.cmds[order[i]] == base.cmds[order[i + 1]]:
            raise NotApplicable
        return Episode(intent, base.bundle, [base.cmds[k] for k in order], [base.proofs[k] for k in order],
                       base.cmds, family, cls, base.cmds, idx=order)
    if family == "exec_tamper":
        m = mutate_plan(topo, task0, base.cmds, cls, rng)
        if m is None or len(m) != len(base.cmds):
            raise NotApplicable
        return Episode(intent, base.bundle, m, base.proofs, base.cmds, family, cls, base.cmds)
    raise ValueError(family)
