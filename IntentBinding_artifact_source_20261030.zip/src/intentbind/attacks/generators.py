"""Attack mutations, injected commands and drift steps (paper Table 3, Sec. 7.3).

Moved unchanged from the code that produced the archived paper run; RNG call order is part of the
reproducibility contract (tests/test_regression_paper_run.py).
"""
from __future__ import annotations

import copy

from ..errors import NotApplicable


def _neighbor(topo, host, rng):
    return rng.choice([x for x in topo.subnet[topo.edge_of[host]] if x != host])


def _other_host(topo, rng, avoid):
    return rng.choice([x for x in topo.hosts if x not in avoid])


def mutate_plan(topo, task, cmds, cls, rng):
    """Plan-level mutation (insider planner or in-transit tampering). Returns new cmds or None if N/A."""
    t, s = task["type"], task["spec"]
    E = topo.edge_of
    c = copy.deepcopy(cmds)
    if cls == "widen":
        if t == "isolate":
            x = _neighbor(topo, s["host"], rng)
            c.append({"op": "isolate", "host": x, "switch": E[x]})
        elif t == "block":
            x = _other_host(topo, rng, s["srcs"] + [s["dst"]])
            c.append({"op": "block", "src": x, "dst": s["dst"], "port": s["port"], "switch": E[s["dst"]]})
        elif t == "slice":
            u = rng.choice([x for x in topo.ues if x not in s["ues"]])
            c.append({"op": "assign_ue", "ue": u, "slice": s["slice"]})
        else:
            x = _other_host(topo, rng, [s["src"], s["dst"]])
            p = topo.host_paths(s["src"], x, 0)[0]
            c.append({"op": "route", "src": s["src"], "dst": x, "path": list(p)})
        return c
    if cls == "relax":
        for cmd in c:
            if cmd["op"] in ("set_bw", "create_slice"):
                cmd["rate"] = s["max"] + rng.choice([10, 50, 100, 300])
                return c
        return None
    if cls == "redirect":
        if t == "isolate":
            x = _neighbor(topo, s["host"], rng)
            c = [{"op": "isolate", "host": x, "switch": E[x]} if k["op"] == "isolate" else k for k in c]
        elif t == "block":
            x = _other_host(topo, rng, s["srcs"] + [s["dst"]])
            c = [dict(k, dst=x, switch=E[x]) for k in c]
        elif t == "slice":
            u = rng.choice([x for x in topo.ues if x not in s["ues"]])
            i = next(i for i, k in enumerate(c) if k["op"] == "assign_ue")
            c[i] = dict(c[i], ue=u)
        else:
            x = _other_host(topo, rng, [s["src"], s["dst"]])
            p = topo.host_paths(s["src"], x, 0)[0]
            c = [dict(k, dst=x, path=list(p)) if k["op"] == "route" else (dict(k, dst=x) if k["op"] == "set_bw" else k)
                 for k in c]
        return c
    if cls == "hijack":
        if t not in ("bandwidth", "waypoint"):
            return None
        a, b = s["src"], s["dst"]
        P = [p for p in topo.host_paths(a, b, 2) if "x1" in p]
        if not P:
            return None
        return [dict(k, path=list(rng.choice(P))) if k["op"] == "route" else k for k in c]
    if cls == "inbound":
        for cmd in c:
            if cmd["op"] in ("set_bw", "create_slice"):
                choices = [r for r in range(s["min"], s["max"] + 1, 10) if r != cmd["rate"]]
                cmd["rate"] = rng.choice(choices)
                return c
        return None
    raise ValueError(cls)


def injected_cmd(topo, task, cmds, cls, rng):
    t, s = task["type"], task["spec"]
    E = topo.edge_of
    ep = s.get("host") or s.get("src") or s.get("dst") or rng.choice(topo.hosts)
    if t == "slice":
        ep = rng.choice(topo.hosts)
    if cls == "infra_isolate":
        x = rng.choice(["gw", "dns"])
        return {"op": "isolate", "host": x, "switch": E[x]}
    if cls == "mirror":
        return {"op": "mirror", "src": ep, "collector": "atk", "switch": E[ep]}
    if cls == "delete_flows":
        return {"op": "delete_flows", "switch": rng.choice(["c1", "c2", "d11", "d12", "d21", "d22"])}
    if cls == "bw_grab":
        if t == "slice":
            return {"op": "set_slice_qos", "slice": "s-default", "rate": 5}
        x = rng.choice(topo.hosts)
        return {"op": "set_bw", "src": "atk", "dst": x, "rate": 1000, "switch": "x1"}
    if cls == "cut":
        a, b = rng.sample(topo.hosts, 2)
        return {"op": "block", "src": a, "dst": b, "port": None, "switch": E[b]}
    if cls == "in_scope":
        return copy.deepcopy(rng.choice(cmds))
    raise ValueError(cls)


def drift_task(topo, task, cls, rng):
    """One reinterpretation step that changes the meaning of the task."""
    t = copy.deepcopy(task)
    s, ty = t["spec"], t["type"]
    if cls == "widen":  # target set grows
        if ty == "isolate":
            s.setdefault("_extra", []).append(_neighbor(topo, s["host"], rng))
        elif ty == "block":
            subs = [x for x in topo.subnet if x != s["src_subnet"]]
            s["srcs"] = s["srcs"] + topo.subnet[rng.choice(subs)][:2]
        elif ty == "slice":
            s["ues"] = s["ues"] + [rng.choice([x for x in topo.ues if x not in s["ues"]])]
        else:  # 'from a to b' read as 'between a and b': reverse direction added
            s["_reverse"] = True
    elif cls == "relax":  # bound or qualifier loosened
        if "max" in s:
            s["max"] = int(s["max"] * 1.25) // 10 * 10
        elif ty == "block":
            s["port"] = None  # 'block port p' read as 'block traffic'
        else:
            raise NotApplicable
    elif cls == "drop_step":  # a sub-goal is lost (under-fulfilment)
        s["_dropped"] = True
    elif cls == "shift":  # target moves to a neighbour
        if ty == "isolate":
            s["host"] = _neighbor(topo, s["host"], rng)
        elif ty == "block":
            s["dst"] = _neighbor(topo, s["dst"], rng)
        elif ty == "slice":
            s["ues"] = s["ues"][:-1] + [rng.choice([x for x in topo.ues if x not in s["ues"]])]
        else:
            s["dst"] = _neighbor(topo, s["dst"], rng)
    return t
