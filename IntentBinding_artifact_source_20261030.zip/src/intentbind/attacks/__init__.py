"""Attack catalogue (paper Table 3) and attacked-episode construction."""
