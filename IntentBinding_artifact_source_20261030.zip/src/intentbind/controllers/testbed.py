"""Emulated data-plane evaluation (paper Sec. 7.7, Table 6). Run only on a Linux host or VM as root.

Per benign intent: run the bound pipeline, verify the chain, check each command (block mode), install the
allowed commands, probe the data plane and compare with the checker's effect model. Attacked episodes with
data-plane-visible harm are run unprotected (B0) and with FULL. The RNG order matches the archived run.
"""
from __future__ import annotations

import json
import random
import subprocess
import time
from pathlib import Path

from ..attacks.episodes import attack_episode
from ..conformance.checker import Checker
from ..defenses.runner import run_defense
from ..errors import NotApplicable
from ..intents.generator import make_intent
from ..network import model as nm
from ..pipeline.episode import benign_episode
from ..pipeline.world import World, exec_dom
from ..utils.config import ExperimentConfig
from ..utils.provenance import RunRecord
from .probes import PORTS_TCP, model_pred, probes_for

TESTBED_FILE = "testbed.json"
ATTACK_CLASSES = [("injection", "infra_isolate"), ("injection", "cut"), ("insider", "widen"), ("drift", "shift")]


def run_testbed(cfg: ExperimentConfig, out_dir: str | Path | None = None) -> Path:
    from . import mininet_ovs as mo
    mo.check_environment()
    tc = cfg.testbed
    out = Path(out_dir or cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rec_meta = RunRecord("testbed", out, cfg.to_dict(), cfg.label_text())
    topo = nm.Topology(hosts_per_access=tc.hosts_per_access)
    world = World.build(cfg.max_refiners, topo=topo, key_seed=cfg.key_seed_bytes())
    net = mo.build_network(topo)
    net.start()
    ex = mo.OVSExecutor(net, topo)
    rng = random.Random(tc.seed)
    for hn in net.hosts:  # userspace datapath + veth: disable checksum offload or TCP fails
        hn.cmd(f"ethtool -K {hn.defaultIntf()} tx off rx off >/dev/null 2>&1")
    for h in topo.hosts:
        for p in PORTS_TCP:
            net.get(h).cmd(f"nc -lk {p} >/dev/null 2>&1 &")
    ovs = subprocess.run(["ovs-vsctl", "--version"], capture_output=True, text=True, check=False).stdout.splitlines()
    rec: dict = {"benign": [], "attack": [], "label": cfg.label_text(),
                 "env": {"switches": len(topo.switches), "hosts": len(topo.edge_of), "ovs": ovs[0] if ovs else ""}}
    types = ["isolate", "block", "bandwidth", "waypoint"]
    path = out / TESTBED_FILE
    try:
        ex.reset()
        time.sleep(0.5)
        s0 = nm.initial_state(topo)
        ctrl: list[tuple] = []
        for _ in range(30):
            x, y = rng.sample(topo.hosts + ["gw", "dns"], 2)
            ctrl.append(("icmp", x, y))
            if x in topo.hosts and y in topo.hosts:
                ctrl.append(("tcp", x, y, rng.choice(PORTS_TCP)))
        rec["control"] = [{"probe": list(p), "model": model_pred(topo, s0, p), "measured": mo.measure(net, ex, p)}
                          for p in ctrl]
        for k in range(tc.benign_intents):
            itype = types[k % 4]
            it = make_intent(topo, rng, itype, k, "path2", prefix="T")
            ex.reset()
            time.sleep(0.3)
            ep = benign_episode(world, it, 500 + k, n_refiners=rng.choice(cfg.refiner_choices), detour_p=cfg.detour_p)
            assert ep.bundle is not None and ep.idx is not None
            ver = world.verifier(exec_dom(itype))
            t0 = time.perf_counter()
            chain_ok = ver.chain(ep.bundle).ok
            t_chain = time.perf_counter() - t0
            chk = Checker(topo, it["constraints"], nm.initial_state(topo), "block")
            t_check, t_inst, n_flagged = 0.0, 0.0, 0
            for j, c in enumerate(ep.cmds):
                t1 = time.perf_counter()
                okc = ver.verify_command(ep.bundle, ep.idx[j], c, ep.proofs[j]).ok
                allowed, _viol = chk.step(c)
                t_check += time.perf_counter() - t1
                if not (okc and allowed):
                    n_flagged += 1
                    continue
                t2 = time.perf_counter()
                ex.install(c, f"0x{k + 1:x}", chk.s)
                t_inst += time.perf_counter() - t2
            t3 = time.perf_counter()
            goals = chk.finish()
            t_check += time.perf_counter() - t3
            time.sleep(0.5)
            agree = [{"probe": list(p), "model": model_pred(topo, chk.s, p), "measured": mo.measure(net, ex, p)}
                     for p in probes_for(topo, it, rng)]
            rec["benign"].append({"k": k, "type": itype, "n_cmds": len(ep.cmds), "hops": len(ep.bundle.hops),
                                  "chain_ok": chain_ok, "flagged": n_flagged, "goal_viol": len(goals),
                                  "t_chain_ms": t_chain * 1e3, "t_check_ms": t_check * 1e3,
                                  "t_install_ms": t_inst * 1e3, "probes": agree})
        for k in range(min(tc.benign_intents, tc.attacked_intents)):
            itype = "isolate" if k % 2 == 0 else "bandwidth"
            it = make_intent(topo, rng, itype, 1000 + k, "path2", prefix="TA")
            fam, cls = ATTACK_CLASSES[k % 4]
            try:
                ep = attack_episode(world, it, 900 + k, fam, cls, n_refiners=1, detour_p=cfg.detour_p)
            except NotApplicable:
                continue
            for d in ("B0", "FULL"):
                ex.reset()
                time.sleep(0.3)
                r = run_defense(world, ep, d)
                st = nm.initial_state(topo)
                for i in r["executed"]:
                    try:
                        ex.install(ep.cmds[i], f"0x{2000 + k:x}", st)
                    except NotApplicable:
                        pass
                    st = nm.apply(topo, st, ep.cmds[i])
                time.sleep(0.5)
                probes = [("icmp", h, "gw") for h in rng.sample(topo.hosts, 6)] + probes_for(topo, it, rng)
                res = [{"probe": list(p), "model": model_pred(topo, st, p), "measured": mo.measure(net, ex, p)}
                       for p in probes]
                rec["attack"].append({"k": k, "family": fam, "cls": cls, "defense": d, "type": itype,
                                      "flags": [f[2] for f in r["flags"]], "executed": len(r["executed"]),
                                      "n_cmds": len(ep.cmds), "probes": res})
    finally:
        path.write_text(json.dumps(rec, indent=1))
        net.stop()
    rec_meta.add_output(path)
    rec_meta.write()
    return path
