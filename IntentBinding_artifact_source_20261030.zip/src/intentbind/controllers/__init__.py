"""Controller adapters: Mininet/OVS executor (Sec. 7.7); ONOS and Open5GS stubs (planned work)."""
