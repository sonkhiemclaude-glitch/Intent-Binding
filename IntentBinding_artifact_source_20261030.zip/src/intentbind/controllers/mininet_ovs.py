"""Minimal OpenFlow 1.3 executor on Mininet + Open vSwitch userspace datapath (paper Sec. 7.7, Table 6).

This stands in for a controller; it is not ONOS. Requirements: Linux, root, Mininet Python package,
Open vSwitch (ovs-vsctl, ovs-ofctl), ethtool and netcat on the experiment host. On macOS (Mac Studio)
run it inside a Linux VM (docs/mac_studio_experiment_guide.md). Mininet is imported lazily so that the
rest of the package works without it.

All subprocess calls use fixed argument lists built from topology names and integers; nothing from a
config file is executed.
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
from typing import Any

from ..errors import ExternalDependencyMissing, NotApplicable
from ..network import model as nm
from .probes import SERVICE, ip_of


def check_environment() -> None:
    """Raise ExternalDependencyMissing unless Mininet/OVS can run here."""
    problems = []
    if platform.system() != "Linux":
        problems.append(f"Linux required (found {platform.system()}); use a Linux VM on macOS")
    if hasattr(os, "geteuid") and os.geteuid() != 0:
        problems.append("root required (Mininet creates network namespaces)")
    for tool in ("ovs-vsctl", "ovs-ofctl", "ethtool", "nc"):
        if shutil.which(tool) is None:
            problems.append(f"{tool} not found")
    try:
        import mininet  # noqa: F401
    except ImportError:
        problems.append("Python package 'mininet' not importable")
    if problems:
        raise ExternalDependencyMissing("Mininet testbed unavailable: " + "; ".join(problems))


def _mininet():
    from mininet.log import setLogLevel
    from mininet.net import Mininet
    from mininet.node import OVSSwitch
    from mininet.topo import Topo
    return Mininet, OVSSwitch, Topo, setLogLevel


def build_network(topo: nm.Topology):
    Mininet, OVSSwitch, Topo, setLogLevel = _mininet()
    setLogLevel("warning")

    class UserOVS(OVSSwitch):  # type: ignore[valid-type,misc]
        def __init__(self, name, **kw):
            kw.update(datapath="user", failMode="secure", protocols="OpenFlow13")
            super().__init__(name, **kw)

    class CampusTopo(Topo):  # type: ignore[valid-type,misc]
        def build(self, t: nm.Topology):
            for i, s in enumerate(t.switches, start=1):
                self.addSwitch(s, dpid=f"{i:016x}")
            for a, b in sorted(t.g.edges):
                self.addLink(a, b)
            for hname, sw in t.edge_of.items():
                self.addHost(hname, ip=ip_of(hname) + "/24")
                self.addLink(hname, sw)

    return Mininet(topo=CampusTopo(t=topo), switch=UserOVS, controller=None, autoStaticArp=True)


class OVSExecutor:
    """Installs checked commands as OpenFlow rules with ovs-ofctl."""

    name = "mininet-ovs"

    def __init__(self, net: Any, topo: nm.Topology):
        self.net, self.topo = net, topo
        self.port: dict[tuple[str, str], int] = {}
        for s in net.switches:
            for intf, p in s.ports.items():
                if intf.link:
                    other = intf.link.intf1 if intf.link.intf2 is intf else intf.link.intf2
                    self.port[(s.name, other.node.name)] = p
        self.meter_id = 1

    def ofctl(self, *args: str, stdin: str | None = None) -> str:
        r = subprocess.run(["ovs-ofctl", "-O", "OpenFlow13", *args], input=stdin, capture_output=True, text=True,
                           check=False)
        if r.returncode:
            raise RuntimeError(r.stderr)
        return r.stdout

    def add_flows(self, sw: str, flows: list[str]) -> None:
        self.ofctl("add-flows", sw, "-", stdin="\n".join(flows) + "\n")

    def base(self) -> None:
        """Destination-based shortest-path forwarding. Service switches are never transit; they forward
        toward the destination via their nearest neighbour on the tree."""
        import networkx as nx
        t = self.topo
        for h, edge in t.edge_of.items():
            gt = t.g.subgraph([x for x in t.g.nodes if x not in SERVICE or x == edge])
            tree = nx.single_source_shortest_path(gt, edge)
            ip = ip_of(h)
            per = {edge: [f"cookie=0x0,priority=10,ip,nw_dst={ip},actions=output:{self.port[(edge, h)]}"]}
            for sw, path in tree.items():
                if sw != edge:
                    per.setdefault(sw, []).append(
                        f"cookie=0x0,priority=10,ip,nw_dst={ip},actions=output:{self.port[(sw, path[-2])]}")
            for sw in SERVICE:
                if sw == edge or sw not in t.g:
                    continue
                nbrs = [n for n in t.g.neighbors(sw) if n in tree]
                nxt = min(nbrs, key=lambda n: (len(tree[n]), n))
                per.setdefault(sw, []).append(
                    f"cookie=0x0,priority=10,ip,nw_dst={ip},actions=output:{self.port[(sw, nxt)]}")
            for sw, fl in per.items():
                self.add_flows(sw, fl)

    def path_flows(self, src: str, dst: str, path: list[str], cookie: str, prio: int,
                   meter: int | None = None) -> dict[str, list[str]]:
        """Explicit path; in_port matching makes hairpin paths (same switch twice) loop-free."""
        m = f"ip,nw_src={ip_of(src)},nw_dst={ip_of(dst)}"
        out: dict[str, list[str]] = {}
        for i, sw in enumerate(path):
            prev = path[i - 1] if i > 0 else src
            nxt = path[i + 1] if i + 1 < len(path) else dst
            act = f"output:{self.port[(sw, nxt)]}"
            if meter and i == 0:
                act = f"meter:{meter}," + act
            out.setdefault(sw, []).append(
                f"cookie={cookie},priority={prio},in_port={self.port[(sw, prev)]},{m},actions={act}")
        return out

    def install(self, cmd: dict, cookie: str, state: Any) -> None:
        t, op = self.topo, cmd["op"]
        flows: dict[str, list[str]] = {}
        if op == "isolate":
            ip = ip_of(cmd["host"])
            flows[cmd["switch"]] = [f"cookie={cookie},priority=300,ip,nw_src={ip},actions=drop",
                                    f"cookie={cookie},priority=300,ip,nw_dst={ip},actions=drop"]
        elif op == "block":
            base = f"ip,nw_src={ip_of(cmd['src'])},nw_dst={ip_of(cmd['dst'])}"
            if cmd.get("port") is not None:
                base = base.replace("ip,", "tcp,") + f",tp_dst={int(cmd['port'])}"
            flows[cmd["switch"]] = [f"cookie={cookie},priority=200,{base},actions=drop"]
        elif op == "route":
            flows = self.path_flows(cmd["src"], cmd["dst"], cmd["path"], cookie, 100)
        elif op == "set_bw":
            mid = self.meter_id
            self.meter_id += 1
            self.ofctl("add-meter", cmd["switch"], f"meter={mid},kbps,band=type=drop,rate={int(cmd['rate']) * 1000}")
            path = state.routes.get((cmd["src"], cmd["dst"])) or nm.route_of(t, state, cmd["src"], cmd["dst"])
            flows = self.path_flows(cmd["src"], cmd["dst"], list(path), cookie, 150, meter=mid)
        elif op == "delete_flows":
            self.ofctl("del-flows", cmd["switch"])
        elif op == "mirror":
            ip = ip_of(cmd["src"])
            # approximation of a mirror port, as in the archived testbed run
            flows[cmd["switch"]] = [f"cookie={cookie},priority=250,ip,nw_src={ip},actions=NORMAL"]
        elif op == "read_stats":
            self.ofctl("dump-flows", cmd["switch"])
        else:
            raise NotApplicable(op)
        for sw, fl in flows.items():
            self.add_flows(sw, fl)

    def reset(self) -> None:
        for s in self.net.switches:
            self.ofctl("del-flows", s.name)
            subprocess.run(["ovs-ofctl", "-O", "OpenFlow13", "del-meters", s.name], capture_output=True, check=False)
        self.base()


def ping(net: Any, a: str, b: str) -> bool:
    return " 0% packet loss" in net.get(a).cmd(f"ping -c1 -W1 -q {net.get(b).IP()}")


def tcp_ok(net: Any, a: str, b: str, port: int) -> bool:
    return "rc=0" in net.get(a).cmd(f"nc -z -w1 {net.get(b).IP()} {int(port)}; echo rc=$?")


def fw_counter(ex: OVSExecutor) -> int:
    out = ex.ofctl("dump-flows", "fw1")
    return sum(int(x.split("n_packets=")[1].split(",")[0]) for x in out.splitlines() if "priority=100" in x)


def measure(net: Any, ex: OVSExecutor, p: tuple) -> bool:
    if p[0] == "icmp":
        return ping(net, p[1], p[2])
    if p[0] == "tcp":
        return tcp_ok(net, p[1], p[2], p[3])
    if p[0] == "via":
        c0 = fw_counter(ex)
        net.get(p[1]).cmd(f"ping -c2 -W1 -q {net.get(p[2]).IP()}")
        return fw_counter(ex) > c0
    raise ValueError(f"unknown probe kind {p[0]!r}")
