"""Controller adapter interface: how verified, conformance-checked commands reach a real controller.

The paper's component evaluation applies commands to the abstract effect model (``network.model``).
Its emulated data-plane check (Sec. 7.7) uses a minimal OpenFlow executor on Mininet/OVS
(``controllers.mininet_ovs``), which is NOT ONOS. ONOS and Open5GS adapters are planned work (paper Sec. 8)
and exist here only as stubs that raise ``ExternalDependencyMissing``.
"""
from __future__ import annotations

from typing import Any, Protocol


class ControllerAdapter(Protocol):
    name: str

    def reset(self) -> None:
        """Return the controller and data plane to the base configuration."""

    def install(self, cmd: dict, cookie: str, state: Any) -> None:
        """Install one allowed command. ``state`` is the checker's predicted state before the command."""
