"""ONOS adapter. NOT IMPLEMENTED (paper Sec. 8: an ONOS evaluation is planned, not reported).

No ONOS REST endpoint, intent JSON format or application is assumed here, because none was used in the
paper. Implementing this adapter requires a running ONOS instance on the experiment host and a mapping
from the command vocabulary (docs/data_format.md) to ONOS flow rules or intents (TODO T-ONOS-1).
"""
from __future__ import annotations

from ..errors import ExternalDependencyMissing


class ONOSAdapter:
    name = "onos"

    def __init__(self, *args, **kwargs):
        raise ExternalDependencyMissing(
            "ONOS adapter is not implemented (TODO T-ONOS-1). The paper reports no ONOS results; see "
            "docs/baseline_adapters.md for the expected interface.")
