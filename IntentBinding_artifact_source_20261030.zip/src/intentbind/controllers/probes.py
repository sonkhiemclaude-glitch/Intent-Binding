"""Data-plane probes and their effect-model predictions (paper Sec. 7.7). Pure functions; no Mininet needed."""
from __future__ import annotations

import random

from ..network import model as nm

SERVICE = {"b1", "sv1", "fw1", "x1"}
PORTS_TCP = (22, 80, 443, 3389)
INFRA_IP = {"gw": 101, "dns": 102, "col": 103, "atk": 104}


def ip_of(hname: str) -> str:
    return f"10.0.0.{INFRA_IP[hname] if hname in INFRA_IP else int(hname[1:])}"


def probes_for(topo: nm.Topology, it: dict, rng: random.Random) -> list[tuple]:
    s, t = it["spec"], it["type"]
    P: list[tuple] = []
    if t == "isolate":
        h = s["host"]
        P += [("icmp", h, x) for x in rng.sample([y for y in topo.hosts if y != h], 3)] + [("icmp", h, "gw")]
        P += [("icmp", x, "gw") for x in topo.subnet[topo.edge_of[h]] if x != h][:2]
    elif t == "block":
        src = s["srcs"][0]
        P += [("tcp", src, s["dst"], s["port"]), ("icmp", src, s["dst"])]
        other = [p for p in PORTS_TCP if p != s["port"]][0]
        P += [("tcp", src, s["dst"], other)]
    elif t in ("bandwidth", "waypoint"):
        P += [("icmp", s["src"], s["dst"])]
        if t == "waypoint":
            P += [("via", s["src"], s["dst"], s["via"])]
    return P


def model_pred(topo: nm.Topology, st, p: tuple) -> bool:
    if p[0] == "icmp":
        return nm.reach(topo, st, p[1], p[2]) and nm.reach(topo, st, p[2], p[1])
    if p[0] == "tcp":
        return (not nm.port_blocked(st, p[1], p[2], p[3])) and nm.reach(topo, st, p[1], p[2]) \
            and nm.reach(topo, st, p[2], p[1])
    if p[0] == "via":
        return bool(nm.via(topo, st, p[1], p[2], p[3]))
    raise ValueError(f"unknown probe kind {p[0]!r}")
