"""Open5GS adapter for slice intents. NOT IMPLEMENTED (paper Sec. 8: planned work).

Slice commands (create_slice, assign_ue, set_slice_qos) are evaluated only on the abstract model in the
paper. A real 5G-core adapter needs a running Open5GS deployment and a verified mapping to its
subscriber/slice configuration interface (TODO T-5G-1).
"""
from __future__ import annotations

from ..errors import ExternalDependencyMissing


class Open5GSAdapter:
    name = "open5gs"

    def __init__(self, *args, **kwargs):
        raise ExternalDependencyMissing(
            "Open5GS adapter is not implemented (TODO T-5G-1). The paper reports no Open5GS results.")
