"""Abstract SDN + 5G-slice network model used as the effect model and as the
'observed state' in the component evaluation. It is deliberately simple: hosts,
switches, isolation, port blocks, explicit routes, meters, mirrors, flow wipes,
slices and UE membership."""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field

import networkx as nx

CAPACITY = 1000  # Mbps, every link
INFRA = ("gw", "dns", "col")  # infrastructure hosts
OPS_ALL = ("isolate", "unisolate", "block", "set_bw", "route", "mirror", "delete_flows",
           "read_stats", "create_slice", "assign_ue", "set_slice_qos")


class Topology:
    """Two-pod campus: 2 core, 4 distribution, 8 access switches, 4 hosts per access
    switch, a border switch (gw), a service switch (dns, approved collector), a
    firewall waypoint fw1, and one attacker-controlled switch x1 off the core."""

    def __init__(self, hosts_per_access: int = 4):
        g = nx.Graph()
        self.core = ["c1", "c2"]
        self.dist = {1: ["d11", "d12"], 2: ["d21", "d22"]}
        self.access = {1: ["a11", "a12", "a13", "a14"], 2: ["a21", "a22", "a23", "a24"]}
        for p in (1, 2):
            for d in self.dist[p]:
                for c in self.core:
                    g.add_edge(d, c)
                for a in self.access[p]:
                    g.add_edge(a, d)
        for extra in ("b1", "sv1", "fw1", "x1"):
            for c in self.core:
                g.add_edge(extra, c)
        self.edge_of: dict[str, str] = {}
        self.subnet: dict[str, list[str]] = {}
        n = 0
        for p in (1, 2):
            for a in self.access[p]:
                self.subnet[a] = []
                for _ in range(hosts_per_access):
                    n += 1
                    hname = f"h{n}"
                    self.edge_of[hname] = a
                    self.subnet[a].append(hname)
        self.edge_of.update({"gw": "b1", "dns": "sv1", "col": "sv1", "atk": "x1"})
        self.g = g
        self.switches = sorted(g.nodes)
        self.hosts = sorted([x for x in self.edge_of if x.startswith("h")], key=lambda s: int(s[1:]))
        self.ues = [f"u{i}" for i in range(1, 17)]
        self.slices0 = {"s-default": 1000}
        self._sp = dict(nx.all_pairs_shortest_path_length(g))
        self._pc: dict = {}

    def sw_dist(self, a, b):
        return self._sp[a][b]

    def host_paths(self, src, dst, slack=0, removed=frozenset()):
        """All simple switch paths edge(src)->edge(dst) of length <= shortest+slack (cached)."""
        key = (self.edge_of[src], self.edge_of[dst], slack, frozenset(removed))
        if key not in self._pc:
            self._pc[key] = self._host_paths(*key)
        return [list(p) for p in self._pc[key]]

    def _host_paths(self, s, t, slack, removed):
        if s in removed or t in removed:
            return []
        g = self.g.subgraph([x for x in self.g.nodes if x not in removed])
        try:
            d = nx.shortest_path_length(g, s, t)
        except nx.NetworkXNoPath:
            return []
        return [tuple(p) for p in nx.all_simple_paths(g, s, t, cutoff=d + slack)]

    def valid_path(self, p, removed=frozenset()):
        return all(x not in removed for x in p) and all(self.g.has_edge(a, b) for a, b in zip(p, p[1:]))


@dataclass
class State:
    isolated: set = field(default_factory=set)
    blocks: set = field(default_factory=set)  # (src, dst, port|None)
    bw: dict = field(default_factory=dict)  # (src,dst) -> rate
    routes: dict = field(default_factory=dict)  # (src,dst) -> tuple(path)
    mirrors: set = field(default_factory=set)  # (src, collector)
    wiped: set = field(default_factory=set)  # switches whose flows were deleted
    slices: dict = field(default_factory=dict)  # slice -> rate
    member: dict = field(default_factory=dict)  # ue -> slice

    def copy(self):
        return State(set(self.isolated), set(self.blocks), dict(self.bw), dict(self.routes),
                     set(self.mirrors), set(self.wiped), dict(self.slices), dict(self.member))


def initial_state(topo: Topology) -> State:
    return State(slices=dict(topo.slices0), member={u: "s-default" for u in topo.ues})


def apply(topo: Topology, s: State, c: dict) -> State:
    """Effect model. Returns a new state; unknown or malformed ops leave state unchanged."""
    n = s.copy()
    op = c.get("op")
    if op == "isolate":
        n.isolated.add(c["host"])
    elif op == "unisolate":
        n.isolated.discard(c["host"])
    elif op == "block":
        n.blocks.add((c["src"], c["dst"], c.get("port")))
    elif op == "set_bw":
        n.bw[(c["src"], c["dst"])] = int(c["rate"])
    elif op == "route":
        n.routes[(c["src"], c["dst"])] = tuple(c["path"])
    elif op == "mirror":
        n.mirrors.add((c["src"], c["collector"]))
    elif op == "delete_flows":
        n.wiped.add(c["switch"])
    elif op == "create_slice":
        n.slices[c["slice"]] = int(c["rate"])
    elif op == "set_slice_qos":
        if c["slice"] in n.slices:
            n.slices[c["slice"]] = int(c["rate"])
    elif op == "assign_ue":
        if c["slice"] in n.slices:
            n.member[c["ue"]] = c["slice"]
    return n


def route_of(topo: Topology, s: State, a: str, b: str):
    removed = frozenset(s.wiped)
    p = s.routes.get((a, b))
    if p is not None:
        return p if topo.valid_path(p, removed) and p[0] == topo.edge_of[a] and p[-1] == topo.edge_of[b] else None
    ps = topo.host_paths(a, b, 0, removed)
    return tuple(ps[0]) if ps else None


def reach(topo: Topology, s: State, a: str, b: str) -> bool:
    if a in s.isolated or b in s.isolated:
        return False
    if (a, b, None) in s.blocks:
        return False
    return route_of(topo, s, a, b) is not None


def port_blocked(s: State, a: str, b: str, port) -> bool:
    return (a, b, port) in s.blocks or (a, b, None) in s.blocks or a in s.isolated or b in s.isolated


def via(topo: Topology, s: State, a: str, b: str, w: str) -> bool:
    p = route_of(topo, s, a, b)
    return p is not None and w in p


def diff_entities(s0: State, s1: State) -> set:
    """Entities whose state differs between s0 and s1 (used by frame constraints)."""
    e: set[tuple] = set()
    for x in s0.isolated ^ s1.isolated:
        e.add(("host", x))
    for (a, b, _p) in s0.blocks ^ s1.blocks:
        e.add(("pair", a, b))
    for k in set(s0.bw) | set(s1.bw):
        if s0.bw.get(k) != s1.bw.get(k):
            e.add(("flow",) + k)
    for k in set(s0.routes) | set(s1.routes):
        if s0.routes.get(k) != s1.routes.get(k):
            e.add(("flow",) + k)
    for (a, _col) in s0.mirrors ^ s1.mirrors:
        e.add(("mirror", a))
    for x in s0.wiped ^ s1.wiped:
        e.add(("switch", x))
    for k in set(s0.slices) | set(s1.slices):
        if s0.slices.get(k) != s1.slices.get(k):
            e.add(("slice", k))
    for k in set(s0.member) | set(s1.member):
        if s0.member.get(k) != s1.member.get(k):
            e.add(("ue", k))
    return e


def switches_of(c: dict):
    sw = []
    if "switch" in c:
        sw.append(c["switch"])
    if "path" in c:
        sw.extend(c["path"])
    return sw


def all_pairs(xs):
    return list(itertools.permutations(xs, 2))
