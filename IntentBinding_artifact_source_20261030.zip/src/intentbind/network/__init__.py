"""Abstract network effect model and topology (paper Sec. 7.2)."""
