"""Record schemas and validators (docs/data_format.md).

Internally, intents, tasks, plans and commands are plain canonical-JSON dicts, because their exact bytes
are hashed and signed (paper Sec. 4). These validators check structure and value domains; they raise
``SchemaError`` with the offending field.
"""
from __future__ import annotations

from typing import Any

from ..errors import SchemaError
from ..intents.compiler import INTENT_TYPES, PORTS
from ..network.model import OPS_ALL, Topology

#: Required spec fields per intent type (paper Sec. 5, "Compilation"; Sec. 7.3).
SPEC_FIELDS: dict[str, tuple[str, ...]] = {
    "isolate": ("host",),
    "block": ("src_subnet", "srcs", "dst", "port"),
    "bandwidth": ("src", "dst", "min", "max"),
    "waypoint": ("src", "dst", "via"),
    "slice": ("slice", "min", "max", "ues"),
}

#: Required parameters per command operation (docs/data_format.md, "Command").
COMMAND_FIELDS: dict[str, tuple[str, ...]] = {
    "isolate": ("host", "switch"),
    "unisolate": ("host",),
    "block": ("src", "dst", "port", "switch"),
    "set_bw": ("src", "dst", "rate", "switch"),
    "route": ("src", "dst", "path"),
    "mirror": ("src", "collector", "switch"),
    "delete_flows": ("switch",),
    "read_stats": ("switch",),
    "create_slice": ("slice", "rate"),
    "assign_ue": ("ue", "slice"),
    "set_slice_qos": ("slice", "rate"),
}

TEMPLATE_TYPES = ("opset", "scope_sw", "scope_param", "bound", "precedence", "frame", "invariant_reach",
                  "goal_isolated", "goal_blocked", "goal_bw", "goal_via", "goal_slice")


def _no_floats(obj: Any, where: str) -> None:
    if isinstance(obj, float):
        raise SchemaError(f"{where}: floats are not allowed in signed artefacts (use integers)")
    if isinstance(obj, dict):
        for k, v in obj.items():
            if not isinstance(k, str):
                raise SchemaError(f"{where}: object keys must be strings")
            _no_floats(v, f"{where}.{k}")
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            _no_floats(v, f"{where}[{i}]")


def validate_spec(itype: str, spec: dict, topo: Topology | None = None) -> None:
    if itype not in SPEC_FIELDS:
        raise SchemaError(f"unknown intent type {itype!r}; expected one of {INTENT_TYPES}")
    if not isinstance(spec, dict):
        raise SchemaError("spec must be an object")
    missing = [f for f in SPEC_FIELDS[itype] if f not in spec]
    if missing:
        raise SchemaError(f"{itype} spec lacks fields {missing}")
    _no_floats(spec, "spec")
    if "min" in spec and (not isinstance(spec["min"], int) or not isinstance(spec["max"], int)
                          or spec["min"] < 0 or spec["min"] > spec["max"]):
        raise SchemaError("spec min/max must be integers with 0 <= min <= max (Mbps)")
    if itype == "block" and spec["port"] not in PORTS:
        raise SchemaError(f"block port must be one of {PORTS}")
    if topo is not None:
        hosts = set(topo.edge_of)
        for f in ("host", "src", "dst"):
            if f in spec and spec[f] not in hosts:
                raise SchemaError(f"spec.{f}={spec[f]!r} is not a host of the topology")
        if itype == "block":
            if spec["src_subnet"] not in topo.subnet:
                raise SchemaError(f"src_subnet {spec['src_subnet']!r} is not an access switch")
            if any(s not in hosts for s in spec["srcs"]):
                raise SchemaError("block srcs contain unknown hosts")
        if itype == "waypoint" and spec["via"] not in topo.g:
            raise SchemaError(f"waypoint {spec['via']!r} is not a switch")
        if itype == "slice" and any(u not in topo.ues for u in spec["ues"]):
            raise SchemaError("slice ues contain unknown UEs")


def validate_intent_record(rec: dict, topo: Topology | None = None, *, require_constraints: bool = False) -> None:
    """IntentRecord: {"iid": str, "type": str, "text": str, "spec": {...}} (+ compiled fields)."""
    if not isinstance(rec, dict):
        raise SchemaError("intent must be an object")
    for f in ("iid", "type", "spec"):
        if f not in rec:
            raise SchemaError(f"intent lacks field {f!r}")
    if not isinstance(rec["iid"], str) or not rec["iid"]:
        raise SchemaError("iid must be a non-empty string")
    validate_spec(rec["type"], rec["spec"], topo)
    if require_constraints:
        for f in ("compiler", "scope_mode", "constraints"):
            if f not in rec:
                raise SchemaError(f"compiled intent lacks {f!r}")
        for c in rec["constraints"]:
            validate_constraint(c)
    _no_floats(rec, "intent")


def validate_constraint(c: dict) -> None:
    if not isinstance(c, dict) or c.get("t") not in TEMPLATE_TYPES:
        raise SchemaError(f"unknown constraint template {c.get('t') if isinstance(c, dict) else c!r}")
    if "id" not in c:
        raise SchemaError("constraint lacks id")


def validate_command(cmd: dict) -> None:
    """Command: {"op": <operation>, ...parameters}. Unknown operations are allowed by the protocol
    (the checker rejects them via the operation-set template) but are flagged here for adapters."""
    if not isinstance(cmd, dict) or "op" not in cmd:
        raise SchemaError("command must be an object with 'op'")
    op = cmd["op"]
    if op not in OPS_ALL:
        raise SchemaError(f"unknown operation {op!r}; known: {OPS_ALL}")
    missing = [f for f in COMMAND_FIELDS[op] if f not in cmd]
    if missing:
        raise SchemaError(f"{op} command lacks {missing}")
    _no_floats(cmd, "command")
    if "rate" in cmd and (not isinstance(cmd["rate"], int) or isinstance(cmd["rate"], bool)):
        raise SchemaError("rate must be an integer (Mbps)")
    if "path" in cmd and (not isinstance(cmd["path"], list) or not cmd["path"]):
        raise SchemaError("path must be a non-empty list of switch names")
