"""Loading and writing intent sets (JSONL, one IntentRecord per line; docs/data_format.md).

``generated_intents`` reproduces the paper's workload (Sec. 7.3). ``load_intent_file`` reads an
externally prepared set (for example converted from IBNBench or NetInspector-Bench by an adapter) and
compiles each record for the requested scope mode, so the signed constraints are always produced by this
repository's template library.
"""
from __future__ import annotations

import random
from pathlib import Path

from ..intents.compiler import COMPILER, INTENT_TYPES, compile_intent
from ..intents.generator import make_intent
from ..network.model import Topology
from ..utils.io import read_jsonl, write_jsonl
from .schemas import validate_intent_record


def paper_workload(topo: Topology, seed: int, n: int, mode: str,
                   refiner_choices: list[int] | tuple[int, ...] = (0, 1, 2)) -> list[tuple[dict, int]]:
    """The paper's workload for one seed and scope mode (Sec. 7.3): (intent, refiner count) pairs.

    Intent k has type INTENT_TYPES[k mod 5]; after each intent the same RNG draws its refiner count.
    This interleaving is part of the reproducibility contract with the archived paper run.
    """
    rng = random.Random(seed)
    out = []
    for k in range(n):
        it = make_intent(topo, rng, INTENT_TYPES[k % len(INTENT_TYPES)], k, mode, prefix=f"I{seed}")
        out.append((it, rng.choice(list(refiner_choices))))
    return out


def file_workload(topo: Topology, records: list[dict], seed: int, mode: str,
                  refiner_choices: list[int] | tuple[int, ...] = (0, 1, 2)) -> list[tuple[dict, int]]:
    """Workload from an external intent set: every record compiled for ``mode``; refiner counts from ``seed``."""
    rng = random.Random(seed)
    return [(compile_record(topo, r, mode), rng.choice(list(refiner_choices))) for r in records]


def compile_record(topo: Topology, rec: dict, mode: str) -> dict:
    """Turn a raw IntentRecord into a compiled, signable intent for one scope mode."""
    validate_intent_record(rec, topo)
    return {"iid": rec["iid"], "type": rec["type"], "text": rec.get("text", ""), "spec": rec["spec"],
            "compiler": COMPILER, "scope_mode": mode,
            "constraints": compile_intent(topo, rec["type"], rec["spec"], mode)}


def load_intent_file(path: str | Path, topo: Topology) -> list[dict]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"intent file not found: {p} (see docs/data_format.md)")
    recs = read_jsonl(p)
    if not recs:
        raise ValueError(f"intent file {p} is empty")
    seen = set()
    for r in recs:
        validate_intent_record(r, topo)
        if r["iid"] in seen:
            raise ValueError(f"duplicate iid {r['iid']!r} in {p}")
        seen.add(r["iid"])
    return recs


def write_intent_file(path: str | Path, intents: list[dict]) -> Path:
    """Write raw records (iid, type, text, spec); compiled fields are dropped on purpose."""
    return write_jsonl(path, [{k: it[k] for k in ("iid", "type", "text", "spec")} for it in intents])
