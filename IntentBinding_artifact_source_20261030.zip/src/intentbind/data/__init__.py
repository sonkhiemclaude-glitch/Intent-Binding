"""Intent-set schemas, loaders and external dataset adapter stubs."""
