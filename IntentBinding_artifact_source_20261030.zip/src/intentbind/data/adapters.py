"""Adapters for external datasets named in the paper or its experiment plan. NONE ARE IMPLEMENTED.

The paper's reported results use only the generated intent workload (Sec. 7.3). The datasets below are
named as optional sources for the planned system-level evaluation (paper Sec. 8; experiment plan E1-E6).
Their file formats were not available to this repository, so no field mapping is invented here: each
adapter documents what it must produce and raises ``ExternalDependencyMissing`` until implemented.

Target output of every adapter: a JSONL file of IntentRecords (docs/data_format.md) whose hosts, switches
and UEs exist in the topology used for the run, or a documented topology adapter (TODO T-TOPO-1).
Nothing here downloads data.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..errors import ExternalDependencyMissing


@dataclass(frozen=True)
class ExternalDataset:
    key: str
    name: str
    reference: str  # bibliographic key in the manuscript
    role_in_paper: str
    availability: str
    expected_location: str  # relative to config ``data.root``
    todo_id: str


EXTERNAL_DATASETS = {
    "ibnbench": ExternalDataset(
        "ibnbench", "IBNBench (Intent2Flow-ONOS, FlowConflict-ONOS)", "hossain2025netintent",
        "candidate intent-to-flow ground truth for the ONOS evaluation (experiment plan)",
        "release and licence not verified", "ibnbench/", "T-DATA-1"),
    "netinspector": ExternalDataset(
        "netinspector", "NetInspector-Bench (2,224 synthetic violates/benign samples)", "zhang2026netinspector",
        "optional policy-violation sub-experiment; NOT an intent set with controller-level ground truth",
        "no repository located (2026-10-18)", "netinspector/", "T-DATA-2"),
    "netinjectbench": ExternalDataset(
        "netinjectbench", "NetInjectBench injection scenarios", "shayoni2026netinjectbench",
        "payloads for LLM-agent prompt-injection experiments (E3)",
        "availability not verified", "netinjectbench/", "T-DATA-3"),
}


class DatasetAdapter:
    """Base class: ``to_intent_records`` must return IntentRecord dicts (docs/data_format.md)."""

    dataset: ExternalDataset

    def __init__(self, data_root: str | Path | None):
        self.data_root = Path(data_root) if data_root else None

    @property
    def location(self) -> Path:
        if self.data_root is None:
            raise ExternalDependencyMissing(
                f"{self.dataset.name}: set data.root in the config and place the files under "
                f"<data.root>/{self.dataset.expected_location} (see docs/data_format.md)")
        return self.data_root / self.dataset.expected_location

    def check_present(self) -> Path:
        loc = self.location
        if not loc.exists():
            raise ExternalDependencyMissing(
                f"{self.dataset.name} not found at {loc}. Provision it manually on the experiment host; "
                f"this repository never downloads data ({self.dataset.todo_id}).")
        return loc

    def to_intent_records(self) -> list[dict]:
        self.check_present()
        raise ExternalDependencyMissing(
            f"{self.dataset.name}: the field mapping to IntentRecord is not implemented because the dataset's "
            f"file format was not available when this repository was written ({self.dataset.todo_id}).")


class IBNBenchAdapter(DatasetAdapter):
    dataset = EXTERNAL_DATASETS["ibnbench"]


class NetInspectorBenchAdapter(DatasetAdapter):
    dataset = EXTERNAL_DATASETS["netinspector"]


class NetInjectBenchAdapter(DatasetAdapter):
    """Would yield injection payload texts for LLM-agent runs, not IntentRecords."""

    dataset = EXTERNAL_DATASETS["netinjectbench"]

    def payloads(self) -> list[dict]:
        self.check_present()
        raise ExternalDependencyMissing("NetInjectBench payload loading is not implemented (T-DATA-3).")


ADAPTERS = {"ibnbench": IBNBenchAdapter, "netinspector": NetInspectorBenchAdapter,
            "netinjectbench": NetInjectBenchAdapter}
