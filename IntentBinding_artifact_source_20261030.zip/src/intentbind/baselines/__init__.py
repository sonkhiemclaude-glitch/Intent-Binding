"""Baseline registry (paper Sec. 7.3, "Defences"). See docs/baseline_adapters.md."""
from .base import BASELINES, BaselineInfo, get_baseline

__all__ = ["BASELINES", "BaselineInfo", "get_baseline"]
