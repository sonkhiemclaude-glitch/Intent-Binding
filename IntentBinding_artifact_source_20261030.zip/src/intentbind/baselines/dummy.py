"""Test-only baseline. NEVER used for reported numbers: it exists to check that the scoring code
distinguishes a defence that flags nothing (detection 0) from one that flags everything."""
from __future__ import annotations

from ..network import model as nm


def allow_all(world, ep) -> dict:
    s = nm.initial_state(world.topo)
    for c in ep.cmds:
        s = nm.apply(world.topo, s, c)
    return {"flags": [], "executed": list(range(len(ep.cmds))), "state": s}


def block_all(world, ep) -> dict:
    return {"flags": [(i, "pre", "DUMMY") for i in range(len(ep.cmds))], "executed": [],
            "state": nm.initial_state(world.topo)}
