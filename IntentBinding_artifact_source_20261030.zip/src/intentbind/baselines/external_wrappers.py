"""Adapter stubs for external defence systems. NOT IMPLEMENTED; no external API is assumed.

To add one: implement ``run(world, ep) -> {"flags": [(pos|None, "pre"|"post", cause)], "executed": [pos],
"state": State}`` with the same contract as ``defenses.runner.run_defense`` so that ``metrics.episode``
can score it unchanged (docs/baseline_adapters.md).
"""
from __future__ import annotations

from ..errors import ExternalDependencyMissing


class ExternalDefenseAdapter:
    key = "external"
    todo = "T-BASE-0"

    def __init__(self, *args, **kwargs):
        pass

    def run(self, world, ep) -> dict:
        raise ExternalDependencyMissing(
            f"{self.key}: external defence adapter not implemented ({self.todo}). Install the external system "
            "on the experiment host and implement run() following docs/baseline_adapters.md.")


class AgentSpecAdapter(ExternalDefenseAdapter):
    key, todo = "agentspec", "T-BASE-1"


class NetInjectBenchGateAdapter(ExternalDefenseAdapter):
    key, todo = "netinjectbench_gate", "T-BASE-2"
