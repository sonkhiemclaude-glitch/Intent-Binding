"""Which defences are real implementations and which are adapters waiting for external code.

The paper's Table 4 columns are all implemented in ``defenses.runner`` from their written definitions.
B2 is a rule set "in the style of AgentSpec"; the AgentSpec system itself is not included. External
systems are listed with ``kind="adapter_stub"`` and raise ``ExternalDependencyMissing`` when used.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..defenses.runner import DEFENSES


@dataclass(frozen=True)
class BaselineInfo:
    key: str
    kind: str  # "implemented" | "adapter_stub" | "test_dummy"
    paper_name: str
    description: str
    module: str


BASELINES: dict[str, BaselineInfo] = {
    "B0": BaselineInfo("B0", "implemented", "unprotected", "every command executes", "defenses.runner"),
    "B1a": BaselineInfo("B1a", "implemented", "B1a plan-state",
                        "final state vs the state predicted from the executor's committed plan", "defenses.runner"),
    "B1b": BaselineInfo("B1b", "implemented", "B1b goal", "final state vs goal templates of the received intent",
                        "defenses.runner"),
    "B2": BaselineInfo("B2", "implemented", "B2 guardrail",
                       "intent-agnostic rules in the style of AgentSpec (not AgentSpec itself)", "defenses.runner"),
    "BIND": BaselineInfo("BIND", "implemented", "BIND only", "binding protocol without conformance",
                         "defenses.runner"),
    "ROOTCONF": BaselineInfo("ROOTCONF", "implemented", "ROOT+CONF",
                             "operator signature over (I, Phi_I) plus conformance; no hop tokens or commitment",
                             "defenses.runner"),
    "CONF": BaselineInfo("CONF", "implemented", "CONF only", "conformance on the intent as received",
                         "defenses.runner"),
    "FULL": BaselineInfo("FULL", "implemented", "FULL", "binding plus conformance", "defenses.runner"),
    "agentspec": BaselineInfo("agentspec", "adapter_stub", "AgentSpec (external)",
                              "runtime rule enforcement for LLM agents; not evaluated in the paper",
                              "baselines.external_wrappers"),
    "netinjectbench_gate": BaselineInfo("netinjectbench_gate", "adapter_stub", "NetInjectBench policy gate",
                                        "policy-gated action selection; not evaluated in the paper",
                                        "baselines.external_wrappers"),
    "dummy_allow_all": BaselineInfo("dummy_allow_all", "test_dummy", "(test only)",
                                    "allows every command; used only by unit tests", "baselines.dummy"),
}

assert all(k in BASELINES and BASELINES[k].kind == "implemented" for k in DEFENSES)


def get_baseline(key: str) -> BaselineInfo:
    if key not in BASELINES:
        raise KeyError(f"unknown baseline {key!r}; known: {sorted(BASELINES)}")
    return BASELINES[key]
