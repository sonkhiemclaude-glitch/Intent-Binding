"""Verifier V at the controller boundary: Algorithm 1 of the paper (Sec. 4, p. 6).

Chain verification runs once per bundle and is cached; each command then gets a validity-window
check, a Merkle proof check, replay and order checks. Every failure carries a named cause.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from ..crypto import JWSError, b64u_dec, h, jws_parse, jws_verify, pk_from_raw
from .merkle import merkle_verify
from .protocol import TYP_CERT, TYP_HOP, TYP_INTENT

#: Rejection causes produced by the chain checks (tampering, forgery, replay); paper Sec. 5, "Cause classes".
CHAIN_CAUSES = {"ROOT_MALFORMED", "ROOT_UNKNOWN_ISSUER", "ROOT_BAD_SIG", "INTENT_DIGEST_MISMATCH",
                "INTENT_EXPIRED", "CHAIN_SHAPE", "CERT_UNKNOWN_DOMAIN", "CERT_INVALID", "HOP_KEY_MISMATCH",
                "HOP_BAD_SIG", "IID_MISMATCH", "HOP_FIELDS", "CHAIN_BREAK", "CONTINUITY_BREAK",
                "EID_MISMATCH", "ROLE_SEQUENCE", "ARTIFACT_MISMATCH", "REPLAY", "CMD_NOT_COMMITTED", "CMD_REPLAY",
                "CMD_ORDER"}


@dataclass
class ChainResult:
    ok: bool
    cause: str = "OK"
    detail: str = ""
    iat: int = 0
    valid_until: int = 0  # min(intent exp, certificate exps); rechecked for every command


@dataclass
class Bundle:
    """What reaches the controller boundary for one fulfilment attempt."""
    intent: dict
    root: str
    hops: list[str]
    certs: list[str]
    exec_artifact: dict


@dataclass
class Verifier:
    operators: dict  # oid -> Ed25519PublicKey
    domain_roots: dict  # dom -> Ed25519PublicKey
    allowed_sequences: list  # list of role tuples
    controller_dom: str
    now: int = 0
    consumed: dict = field(default_factory=dict)  # (iid, nonce) -> (eid, executor commitment)
    seen_cmds: set = field(default_factory=set)
    last_j: dict = field(default_factory=dict)  # (iid, eid) -> last forwarded index
    _cache: dict = field(default_factory=dict)

    def verify_root(self, b: Bundle) -> ChainResult:
        """Root-only checks (operator signature, digest, validity); used by the ROOT+CONF ablation."""
        try:
            hdr, rp, _, _ = jws_parse(b.root)
            if hdr.get("typ") != TYP_INTENT:
                return ChainResult(False, "ROOT_MALFORMED", "typ")
            pk = self.operators.get(rp.get("iss"))
            if pk is None:
                return ChainResult(False, "ROOT_UNKNOWN_ISSUER", str(rp.get("iss")))
            try:
                _, rp = jws_verify(b.root, pk)
            except JWSError as e:
                return ChainResult(False, "ROOT_BAD_SIG", str(e))
            if rp["dig"] != h(b.intent) or rp["iid"] != b.intent.get("iid"):
                return ChainResult(False, "INTENT_DIGEST_MISMATCH")
            if not (rp["iat"] <= self.now <= rp["exp"]):
                return ChainResult(False, "INTENT_EXPIRED")
            return ChainResult(True, iat=rp["iat"], valid_until=rp["exp"])
        except JWSError as e:
            return ChainResult(False, "ROOT_MALFORMED", str(e))
        except (KeyError, TypeError) as e:
            return ChainResult(False, "ROOT_MALFORMED", f"missing field {e}")

    def verify_chain(self, b: Bundle) -> ChainResult:
        try:
            return self._verify_chain(b)
        except (KeyError, TypeError, ValueError) as e:  # malformed payloads and public keys fail closed
            return ChainResult(False, "HOP_FIELDS", f"missing field {e}")

    def _verify_chain(self, b: Bundle) -> ChainResult:
        # --- root: operator signature, digest, validity, freshness
        try:
            hdr, _, _, _ = jws_parse(b.root)
        except JWSError as e:
            return ChainResult(False, "ROOT_MALFORMED", str(e))
        if hdr.get("typ") != TYP_INTENT:
            return ChainResult(False, "ROOT_MALFORMED", "typ")
        _, rp, _, _ = jws_parse(b.root)
        pk = self.operators.get(rp.get("iss"))
        if pk is None:
            return ChainResult(False, "ROOT_UNKNOWN_ISSUER", str(rp.get("iss")))
        try:
            _, rp = jws_verify(b.root, pk)
        except JWSError as e:
            return ChainResult(False, "ROOT_BAD_SIG", str(e))
        if rp["dig"] != h(b.intent) or rp["iid"] != b.intent.get("iid"):
            return ChainResult(False, "INTENT_DIGEST_MISMATCH")
        if not (rp["iat"] <= self.now <= rp["exp"]):
            return ChainResult(False, "INTENT_EXPIRED")
        # --- hops
        if len(b.hops) != len(b.certs) or not b.hops:
            return ChainResult(False, "CHAIN_SHAPE")
        roles, prev_tok, prev_out, eid = [], b.root, rp["dig"], None
        valid_until = rp["exp"]
        for k, (tok, cert) in enumerate(zip(b.hops, b.certs), start=1):
            try:
                ch, cp, _, _ = jws_parse(cert)
                if ch.get("typ") != TYP_CERT:
                    return ChainResult(False, "CERT_INVALID", "typ")
                droot = self.domain_roots.get(cp.get("dom"))
                if droot is None:
                    return ChainResult(False, "CERT_UNKNOWN_DOMAIN", str(cp.get("dom")))
                _, cp = jws_verify(cert, droot)
            except JWSError as e:
                return ChainResult(False, "CERT_INVALID", str(e))
            if cp["exp"] < self.now:
                return ChainResult(False, "CERT_INVALID", "expired")
            valid_until = min(valid_until, cp["exp"])
            try:
                th, tp, _, _ = jws_parse(tok)
                if th.get("typ") != TYP_HOP:
                    return ChainResult(False, "HOP_FIELDS", f"hop {k}: typ")
                if th.get("kid") != cp["sub"]:
                    return ChainResult(False, "HOP_KEY_MISMATCH", f"hop {k}")
                _, tp = jws_verify(tok, pk_from_raw(b64u_dec(cp["pk"])))
            except JWSError as e:
                return ChainResult(False, "HOP_BAD_SIG", f"hop {k}: {e}")
            if tp["iid"] != rp["iid"]:
                return ChainResult(False, "IID_MISMATCH", f"hop {k}")
            if tp["k"] != k or tp["role"] != cp["role"] or tp["dom"] != cp["dom"] or tp["cert"] != h(cert.encode()):
                return ChainResult(False, "HOP_FIELDS", f"hop {k}")
            if tp["prev"] != h(prev_tok.encode()):
                return ChainResult(False, "CHAIN_BREAK", f"hop {k}")
            if tp["in"] != prev_out:
                return ChainResult(False, "CONTINUITY_BREAK", f"hop {k}")
            if eid is None:
                eid = tp["eid"]
            elif tp["eid"] != eid:
                return ChainResult(False, "EID_MISMATCH", f"hop {k}")
            roles.append(tp["role"])
            prev_tok, prev_out = tok, tp["out"]
        if tuple(roles) not in [tuple(s) for s in self.allowed_sequences]:
            return ChainResult(False, "ROLE_SEQUENCE", "/".join(roles))
        if tp["dom"] != self.controller_dom:
            return ChainResult(False, "ROLE_SEQUENCE", "executor domain")
        if (h(b.exec_artifact) != prev_out or b.exec_artifact.get("eid") != eid
                or b.exec_artifact.get("iid") != rp["iid"]):
            return ChainResult(False, "ARTIFACT_MISMATCH")
        # --- freshness: one execution (and one executor commitment) per signed intent
        key = (rp["iid"], rp["nonce"])
        commit = (eid, prev_out)
        if key in self.consumed and self.consumed[key] != commit:
            return ChainResult(False, "REPLAY")
        self.consumed[key] = commit
        return ChainResult(True, iat=rp["iat"], valid_until=valid_until)

    def chain(self, b: Bundle) -> ChainResult:
        """Chain verification, once per bundle (cached)."""
        ck = (b.root, tuple(b.hops), tuple(b.certs), h(b.exec_artifact), h(b.intent))
        if ck not in self._cache:
            self._cache[ck] = self.verify_chain(b)
        return self._cache[ck]

    def verify_command(self, b: Bundle, j: int, cmd: dict, proof) -> ChainResult:
        r = self.chain(b)
        if not r.ok:
            return r
        if not (r.iat <= self.now <= r.valid_until):  # validity rechecked for every command
            return ChainResult(False, "INTENT_EXPIRED", "window closed after first verification")
        art = b.exec_artifact
        root = art.get("cmd_root")
        if (type(j) is not int or type(art.get("n")) is not int or not (0 <= j < art["n"])
                or not isinstance(root, str) or not merkle_verify(cmd, j, proof, root)):
            return ChainResult(False, "CMD_NOT_COMMITTED")
        sk = (art["iid"], art["eid"], j)
        if sk in self.seen_cmds:
            return ChainResult(False, "CMD_REPLAY")
        if j <= self.last_j.get((art["iid"], art["eid"]), -1):
            return ChainResult(False, "CMD_ORDER")  # committed order is enforced
        self.seen_cmds.add(sk)
        self.last_j[(art["iid"], art["eid"])] = j
        return ChainResult(True)
