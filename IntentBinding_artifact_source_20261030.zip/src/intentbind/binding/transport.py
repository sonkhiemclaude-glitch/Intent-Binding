"""Carrying a bundle and per-command proofs in MCP ``_meta`` (paper Sec. 4, "Transport"). DESIGN HELPER ONLY.

The paper states that MCP requests carry a ``_meta`` object in which implementations may place
vendor-prefixed keys, including on ``tools/call``, and that the bundle and the per-command proof can be
carried there. The paper did NOT implement an MCP transport, and neither does this repository: these
functions only build and parse the ``_meta`` dictionary. No MCP client or server code is included
(TODO T-MCP-1). The key prefix ``org.intentbind/`` follows the MCP rule that ``_meta`` keys may carry a
reverse-DNS style prefix ending in "/"; prefixes containing ``modelcontextprotocol`` or ``mcp`` are
reserved and are not used here.
"""
from __future__ import annotations

from dataclasses import asdict
from typing import Any

from ..errors import SchemaError
from .verifier import Bundle

PREFIX = "org.intentbind/"
KEY_BUNDLE = PREFIX + "bundle"
KEY_BUNDLE_REF = PREFIX + "bundle_ref"
KEY_INDEX = PREFIX + "index"
KEY_PROOF = PREFIX + "proof"


def bundle_to_meta(b: Bundle) -> dict[str, Any]:
    """Full bundle, sent once per intent (for example on the first tools/call)."""
    return {KEY_BUNDLE: asdict(b)}


def command_meta(iid: str, eid: str, j: int, proof: list, *, include_bundle: Bundle | None = None) -> dict[str, Any]:
    """Per-command metadata: the bundle reference (iid, eid), the committed index and its Merkle proof."""
    meta: dict[str, Any] = {KEY_BUNDLE_REF: {"iid": iid, "eid": eid}, KEY_INDEX: j,
                            KEY_PROOF: [[side, digest] for side, digest in proof]}
    if include_bundle is not None:
        meta.update(bundle_to_meta(include_bundle))
    return meta


def bundle_from_meta(meta: dict[str, Any]) -> Bundle | None:
    raw = meta.get(KEY_BUNDLE)
    if raw is None:
        return None
    try:
        return Bundle(intent=raw["intent"], root=raw["root"], hops=list(raw["hops"]), certs=list(raw["certs"]),
                      exec_artifact=raw["exec_artifact"])
    except (KeyError, TypeError) as e:
        raise SchemaError(f"malformed {KEY_BUNDLE}: {e}") from e


def command_from_meta(meta: dict[str, Any]) -> tuple[str, str, int, list]:
    """Return (iid, eid, index, proof). Raises SchemaError if a field is missing or mistyped."""
    try:
        ref = meta[KEY_BUNDLE_REF]
        j = meta[KEY_INDEX]
        proof = meta[KEY_PROOF]
        iid, eid = ref["iid"], ref["eid"]
    except (KeyError, TypeError) as e:
        raise SchemaError(f"missing intentbind _meta field: {e}") from e
    if not isinstance(j, int) or isinstance(j, bool) or j < 0:
        raise SchemaError("index must be a non-negative integer")
    if not isinstance(proof, list) or any(not isinstance(p, (list, tuple)) or len(p) != 2 for p in proof):
        raise SchemaError("proof must be a list of [side, digest] pairs")
    return iid, eid, j, [tuple(p) for p in proof]
