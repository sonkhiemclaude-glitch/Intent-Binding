"""Binding protocol (paper Sec. 4): tokens, Merkle commitment, verifier (Algorithm 1), MCP _meta helper."""
from .merkle import merkle_root_and_proofs, merkle_verify
from .protocol import TYP_CERT, TYP_HOP, TYP_INTENT, Agent, DomainAuthority, Operator, executor_artifact
from .verifier import CHAIN_CAUSES, Bundle, ChainResult, Verifier

__all__ = ["merkle_root_and_proofs", "merkle_verify", "TYP_CERT", "TYP_HOP", "TYP_INTENT", "Agent",
           "DomainAuthority", "Operator", "executor_artifact", "CHAIN_CAUSES", "Bundle", "ChainResult", "Verifier"]
