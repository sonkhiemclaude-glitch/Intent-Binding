"""Merkle commitment of the executor's command list (paper Sec. 4, "Executor commitment").

Leaf  = SHA-256(0x00 || j (8-byte big endian) || H(c_j))   -- index bound into the leaf
Node  = SHA-256(0x01 || left || right)                      -- domain separated from leaves
Odd nodes are promoted unchanged to the next level.
"""
from __future__ import annotations

import hashlib

from ..crypto import h


def _leaf(j: int, cmd: dict) -> bytes:
    """Leaf binds the command and its index, so a proof cannot be reused at another index."""
    return hashlib.sha256(b"\x00" + j.to_bytes(8, "big") + bytes.fromhex(h(cmd))).digest()


def _node(a: bytes, b: bytes) -> bytes:
    return hashlib.sha256(b"\x01" + a + b).digest()


def merkle_root_and_proofs(cmds: list[dict]):
    """Return (root_hex, proofs) where proofs[j] is a list of (side, hex) pairs."""
    if not cmds:
        return hashlib.sha256(b"\x02empty").hexdigest(), []
    level = [_leaf(j, c) for j, c in enumerate(cmds)]
    idx = list(range(len(cmds)))
    proofs: list[list[tuple[str, str]]] = [[] for _ in cmds]
    pos = {j: j for j in idx}
    while len(level) > 1:
        nxt = []
        for i in range(0, len(level), 2):
            if i + 1 < len(level):
                nxt.append(_node(level[i], level[i + 1]))
            else:
                nxt.append(level[i])  # odd node promoted unchanged
        for j in idx:
            p = pos[j]
            sib = p ^ 1
            if sib < len(level):
                proofs[j].append(("L" if sib < p else "R", level[sib].hex()))
            pos[j] = p // 2
        level = nxt
    return level[0].hex(), proofs


def merkle_verify(cmd: dict, j: int, proof, root_hex: str) -> bool:
    try:
        if type(j) is not int or not 0 <= j < 2**64:
            return False
        cur = _leaf(j, cmd)
        for side, sib_hex in proof:
            if side not in ("L", "R"):
                return False
            sib = bytes.fromhex(sib_hex)
            if len(sib) != 32:
                return False
            cur = _node(sib, cur) if side == "L" else _node(cur, sib)
        return cur.hex() == root_hex
    except (TypeError, ValueError, OverflowError):
        return False


