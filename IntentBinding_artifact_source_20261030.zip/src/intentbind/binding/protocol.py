"""Principals and artefacts of the intent binding protocol (paper Sec. 4).

Operator: signs the intent root tau_0 over (iid, iss, dig=H(I), nonce, iat, exp).
DomainAuthority: certifies agent keys (cert_k binds kid, pk, role, domain, software hash, exp).
Agent: emits hop tokens tau_k over (iid, k, role, dom, eid, H(tau_{k-1}), H(x_k), H(y_k), H(cert_k)).
executor_artifact: y_m = (iid, eid, n, Merkle root R) and the per-command inclusion proofs.
"""
from __future__ import annotations

from dataclasses import dataclass

from ..crypto import KeyPair, b64u, h, jws_sign
from .merkle import merkle_root_and_proofs

TYP_INTENT, TYP_HOP, TYP_CERT = "ib-intent", "ib-hop", "ib-cert"


@dataclass
class Operator:
    oid: str
    key: KeyPair

    def sign_intent(self, intent: dict, nonce: str, iat: int, exp: int) -> str:
        payload = {"iid": intent["iid"], "iss": self.oid, "dig": h(intent), "nonce": nonce,
                   "iat": iat, "exp": exp}
        return jws_sign(payload, self.key, TYP_INTENT)


@dataclass
class DomainAuthority:
    dom: str
    key: KeyPair

    def certify(self, agent_key: KeyPair, role: str, sw_hash: str, exp: int) -> str:
        payload = {"sub": agent_key.kid, "pk": b64u(agent_key.pk_raw()), "role": role,
                   "dom": self.dom, "sw": sw_hash, "exp": exp}
        return jws_sign(payload, self.key, TYP_CERT)


@dataclass
class Agent:
    role: str
    dom: str
    key: KeyPair
    cert: str = ""

    def emit(self, iid: str, k: int, eid: str, prev_token: str, inp, out) -> str:
        payload = {"iid": iid, "k": k, "role": self.role, "dom": self.dom, "eid": eid,
                   "prev": h(prev_token.encode()), "in": h(inp), "out": h(out), "cert": h(self.cert.encode())}
        return jws_sign(payload, self.key, TYP_HOP)


def executor_artifact(iid: str, eid: str, cmds: list[dict]):
    root, proofs = merkle_root_and_proofs(cmds)
    return {"iid": iid, "eid": eid, "n": len(cmds), "cmd_root": root}, proofs


