"""Compact JWS with Ed25519 (alg "EdDSA"; RFC 7515, RFC 8032, RFC 8037) -- Sig_X(.) in the paper."""
from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from .canonical import canon


def b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


@dataclass
class KeyPair:
    kid: str
    sk: Ed25519PrivateKey

    @classmethod
    def generate(cls, kid: str, seed: bytes | None = None) -> KeyPair:
        """Fresh random key, or a deterministic key derived from ``seed`` and ``kid``.

        Deterministic keys exist only for reproducible test artefacts (identical token bytes
        across runs). They must never be used for real deployments.
        """
        if seed is None:
            return cls(kid, Ed25519PrivateKey.generate())
        material = hashlib.sha256(b"intentbind-test-key|" + seed + b"|" + kid.encode()).digest()
        return cls(kid, Ed25519PrivateKey.from_private_bytes(material))

    @property
    def pk(self) -> Ed25519PublicKey:
        return self.sk.public_key()

    def pk_raw(self) -> bytes:
        return self.pk.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def pk_from_raw(raw: bytes) -> Ed25519PublicKey:
    return Ed25519PublicKey.from_public_bytes(raw)


def jws_sign(payload: dict, key: KeyPair, typ: str) -> str:
    header = {"alg": "EdDSA", "kid": key.kid, "typ": typ}
    signing_input = b64u(canon(header)) + "." + b64u(canon(payload))
    sig = key.sk.sign(signing_input.encode("ascii"))
    return signing_input + "." + b64u(sig)


class JWSError(Exception):
    pass


def jws_parse(token: str):
    try:
        hb, pb, sb = token.split(".")
        header = json.loads(b64u_dec(hb))
        payload = json.loads(b64u_dec(pb))
        if not isinstance(header, dict) or not isinstance(payload, dict):
            raise ValueError("JWS header and payload must be JSON objects")
        sig = b64u_dec(sb)
    except Exception as e:  # malformed
        raise JWSError(f"malformed token: {e}") from e
    return header, payload, sig, (hb + "." + pb).encode("ascii")


def jws_verify(token: str, pk: Ed25519PublicKey):
    header, payload, sig, signing_input = jws_parse(token)
    if header.get("alg") != "EdDSA":
        raise JWSError("unexpected alg")
    try:
        pk.verify(sig, signing_input)
    except InvalidSignature:
        raise JWSError("bad signature") from None
    return header, payload
