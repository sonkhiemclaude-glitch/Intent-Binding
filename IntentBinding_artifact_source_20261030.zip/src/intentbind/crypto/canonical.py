"""Canonical JSON encoding and hashing H (paper Sec. 4, "Notation").

H is SHA-256 over a canonical JSON encoding: keys sorted, no insignificant whitespace, UTF-8,
integers only. With ASCII object keys and integers within +/-2^53 this coincides with RFC 8785
(JCS). Floats are rejected so number serialisation can never differ between implementations.
"""
from __future__ import annotations

import hashlib
import json


def _check(v):
    if isinstance(v, float):
        raise TypeError("floats are not allowed in canonical objects")
    if isinstance(v, dict):
        for k, x in v.items():
            if not isinstance(k, str):
                raise TypeError("object keys must be strings")
            _check(x)
    elif isinstance(v, (list, tuple)):
        for x in v:
            _check(x)


def canon(obj) -> bytes:
    _check(obj)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def h(obj_or_bytes) -> str:
    """SHA-256 over canonical bytes, hex."""
    b = obj_or_bytes if isinstance(obj_or_bytes, (bytes, bytearray)) else canon(obj_or_bytes)
    return hashlib.sha256(b).hexdigest()


