"""Constraint conformance (paper Sec. 5): incremental checker and an independent LTLf evaluator."""
