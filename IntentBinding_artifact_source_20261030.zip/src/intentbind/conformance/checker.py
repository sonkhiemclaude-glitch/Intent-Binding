"""Runtime conformance checker: hand-compiled finite-trace monitors for the
template library (LTLf semantics in ltlf.py; equivalence tested in tests/)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..network import model as nm

CAUSE = {"opset": "OPSET", "scope_sw": "SCOPE", "scope_param": "SCOPE", "bound": "BOUND",
         "frame": "FRAME", "invariant_reach": "INVARIANT", "precedence": "ORDER"}
SAFETY = set(CAUSE)
GOALS = {"goal_isolated", "goal_blocked", "goal_bw", "goal_via", "goal_slice"}


def action_violations(constraints, cmd, seen_a):
    """Action-only templates (no state): opset, scope, bound, precedence."""
    out = []
    op = cmd.get("op")
    for c in constraints:
        t = c["t"]
        if t == "opset":
            if op not in c["ops"]:
                out.append(c)
        elif t == "scope_sw":
            if any(s not in c["allowed"] for s in nm.switches_of(cmd)):
                out.append(c)
        elif t == "scope_param":
            if op == c["op"] and cmd.get(c["param"]) not in c["allowed"]:
                out.append(c)
        elif t == "bound":
            if op == c["op"]:
                v = cmd.get(c["param"])
                if not isinstance(v, int) or isinstance(v, bool) or not (c["lo"] <= v <= c["hi"]):
                    out.append(c)
        elif t == "precedence":
            if op == c["b"] and (c["a"], cmd.get(c["key"])) not in seen_a:
                out.append(c)
    return out


def state_violations(topo, constraints, s0, s1):
    out = []
    ents = None
    for c in constraints:
        t = c["t"]
        if t == "frame":
            if ents is None:
                ents = nm.diff_entities(s0, s1)
            allowed = {tuple(e) for e in c["allowed"]}
            if not ents <= allowed:
                out.append(c)
        elif t == "invariant_reach":
            if not all(nm.reach(topo, s1, a, b) for a, b in c["pairs"]):
                out.append(c)
    return out


def goal_violations(topo, constraints, s):
    out = []
    for c in constraints:
        t = c["t"]
        if t == "goal_isolated":
            if any(nm.reach(topo, s, c["host"], x) or nm.reach(topo, s, x, c["host"]) for x in c["probe"]):
                out.append(c)
        elif t == "goal_blocked":
            if not all(nm.port_blocked(s, x, c["dst"], c["port"]) for x in c["srcs"]):
                out.append(c)
        elif t == "goal_bw":
            v = s.bw.get((c["src"], c["dst"]))
            if v is None or not (c["lo"] <= v <= c["hi"]) or not nm.reach(topo, s, c["src"], c["dst"]):
                out.append(c)
        elif t == "goal_via":
            if not nm.via(topo, s, c["src"], c["dst"], c["via"]):
                out.append(c)
        elif t == "goal_slice":
            r = s.slices.get(c["slice"])
            if r is None or not (c["lo"] <= r <= c["hi"]) or any(s.member.get(u) != c["slice"] for u in c["ues"]):
                out.append(c)
    return out


@dataclass
class Checker:
    topo: nm.Topology
    constraints: list
    s0: nm.State
    mode: str = "block"  # "block" (pre-execution) or "alarm" (post-execution flagging)
    s: Any = None  # current predicted state; set to s0 in __post_init__
    seen_a: set = field(default_factory=set)
    trace: list = field(default_factory=list)

    def __post_init__(self):
        if self.s is None:
            self.s = self.s0.copy()

    def step(self, cmd: dict):
        """Check one proposed command. Returns (execute, violations)."""
        v = action_violations(self.constraints, cmd, self.seen_a)
        s1 = nm.apply(self.topo, self.s, cmd)
        v += state_violations(self.topo, self.constraints, self.s0, s1)
        execute = not v or self.mode == "alarm"
        if execute:
            self.s = s1
            self.trace.append(cmd)
            for c in self.constraints:
                if c["t"] == "precedence" and cmd.get("op") == c["a"]:
                    self.seen_a.add((c["a"], cmd.get(c["key"])))
        return execute, [(c["id"], c["t"], CAUSE[c["t"]]) for c in v]

    def finish(self, observed: nm.State | None = None):
        s = observed if observed is not None else self.s
        return [(c["id"], c["t"], "GOAL") for c in goal_violations(self.topo, self.constraints, s)]
