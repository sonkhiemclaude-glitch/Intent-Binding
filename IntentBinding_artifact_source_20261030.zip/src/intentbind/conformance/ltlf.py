"""Reference LTLf semantics over finite traces (De Giacomo and Vardi, 2013) and the
LTLf formula of each template. Used only to test the hand-compiled monitors.

A trace is a list of positions; position i holds (cmd_i, state_before_i, state_after_i, s0).
Formulas are nested tuples: ("ap", fn) | ("not", f) | ("and", f, g) | ("or", f, g)
| ("X", f) strong next | ("WX", f) weak next | ("U", f, g) | ("G", f) | ("F", f) | ("last", f)
where ("last", f) holds iff f holds at the final position (used for goals)."""
from __future__ import annotations

from functools import cache

from ..network import model as nm


def holds(f, trace, i=0):
    n = len(trace)

    @cache
    def ev(fid, i):
        g = table[fid]
        k = g[0]
        if k == "ap":
            return i < n and g[1](trace[i])
        if k == "true":
            return True
        if k == "not":
            return not ev(id(g[1]), i)
        if k == "and":
            return ev(id(g[1]), i) and ev(id(g[2]), i)
        if k == "or":
            return ev(id(g[1]), i) or ev(id(g[2]), i)
        if k == "X":
            return i + 1 < n and ev(id(g[1]), i + 1)
        if k == "WX":
            return i + 1 >= n or ev(id(g[1]), i + 1)
        if k == "U":
            for j in range(i, n):
                if ev(id(g[2]), j):
                    return True
                if not ev(id(g[1]), j):
                    return False
            return False
        if k == "G":
            return all(ev(id(g[1]), j) for j in range(i, n))
        if k == "F":
            return any(ev(id(g[1]), j) for j in range(i, n))
        if k == "last":
            return n > 0 and ev(id(g[1]), n - 1)
        raise ValueError(k)

    table = {}

    def reg(g):
        table[id(g)] = g
        for x in g[1:]:
            if isinstance(x, tuple):
                reg(x)

    reg(f)
    return ev(id(f), i)


def _sw(cmd):
    """Switches named by a command (re-derived here, not taken from the checker)."""
    out = []
    if "switch" in cmd:
        out.append(cmd["switch"])
    out += list(cmd.get("path", []))
    return out


def _atom(topo, c):
    """Atomic proposition for template c, written from the template definition (Table 2)
    without calling the checker's violation functions. Shares only the effect model and
    the state predicates reach / port_blocked / via / diff_entities with the checker."""
    t = c["t"]
    if t == "opset":
        return lambda p: p[0].get("op") in c["ops"]
    if t == "scope_sw":
        return lambda p: set(_sw(p[0])) <= set(c["allowed"])
    if t == "scope_param":
        return lambda p: p[0].get("op") != c["op"] or p[0].get(c["param"]) in c["allowed"]
    if t == "bound":
        def ok(p):
            if p[0].get("op") != c["op"]:
                return True
            v = p[0].get(c["param"])
            return isinstance(v, int) and not isinstance(v, bool) and c["lo"] <= v <= c["hi"]
        return ok
    if t == "frame":
        allowed = {tuple(e) for e in c["allowed"]}
        return lambda p: all(e in allowed for e in nm.diff_entities(p[3], p[2]))
    if t == "invariant_reach":
        return lambda p: all(nm.reach(topo, p[2], x, y) for x, y in c["pairs"])
    if t == "goal_isolated":
        return lambda p: all(not nm.reach(topo, p[2], c["host"], x) and not nm.reach(topo, p[2], x, c["host"])
                             for x in c["probe"])
    if t == "goal_blocked":
        return lambda p: all(nm.port_blocked(p[2], x, c["dst"], c["port"]) for x in c["srcs"])
    if t == "goal_bw":
        return lambda p: (p[2].bw.get((c["src"], c["dst"])) is not None
                          and c["lo"] <= p[2].bw[(c["src"], c["dst"])] <= c["hi"]
                          and nm.reach(topo, p[2], c["src"], c["dst"]))
    if t == "goal_via":
        return lambda p: nm.via(topo, p[2], c["src"], c["dst"], c["via"])
    if t == "goal_slice":
        return lambda p: (p[2].slices.get(c["slice"]) is not None and c["lo"] <= p[2].slices[c["slice"]] <= c["hi"]
                          and all(p[2].member.get(u) == c["slice"] for u in c["ues"]))
    raise ValueError(t)


def formula(topo, c):
    """LTLf formula for constraint c over positions (cmd, s_before, s_after, s0)."""
    t = c["t"]
    if t == "precedence":
        def is_b(p, v): return p[0].get("op") == c["b"] and p[0].get(c["key"]) == v
        def is_a(p, v): return p[0].get("op") == c["a"] and p[0].get(c["key"]) == v
        # for every key value v that occurs: (not b_v U a_v) or G not b_v
        f = ("true",)
        for v in c.get("_vals", []):
            nb = ("not", ("ap", lambda p, v=v: is_b(p, v)))
            f = ("and", f, ("or", ("U", nb, ("ap", lambda p, v=v: is_a(p, v))), ("G", nb)))
        return f
    if t.startswith("goal"):
        return ("last", ("ap", _atom(topo, c)))
    return ("G", ("ap", _atom(topo, c)))


def positions(topo, s0, cmds):
    out, s = [], s0
    for c in cmds:
        s1 = nm.apply(topo, s, c)
        out.append((c, s, s1, s0))
        s = s1
    return out
