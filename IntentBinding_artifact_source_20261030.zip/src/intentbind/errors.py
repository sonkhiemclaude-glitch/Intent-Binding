"""Exception types shared across the package."""
from __future__ import annotations


class NotApplicable(Exception):
    """An attack class is not defined for this intent (e.g. 'relax bound' on an isolation intent).

    The paper applies each attack 'to every intent for which it is defined' (Sec. 7.3); episodes
    raising this are skipped, not counted.
    """


class ConfigError(ValueError):
    """Invalid or inconsistent experiment configuration."""


class SchemaError(ValueError):
    """An input record (intent, command, constraint, result row) does not match its schema."""


class ExternalDependencyMissing(RuntimeError):
    """A component needs an external system, dataset or package that is not provisioned.

    Raised by adapter stubs (LLM agents, ONOS, Open5GS, external datasets) and by the Mininet
    testbed when Mininet / Open vSwitch / root are unavailable. The message says what is needed.
    """
