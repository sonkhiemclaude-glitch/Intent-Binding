"""Attribution of commands to an attack (paper Sec. 7.3, "Metrics").

An attacked episode is *effective* if its command sequence differs from the benign episode's (all
forgery episodes are effective). Attack-caused commands are identified by content, so a blocked
injected duplicate counts as detected.
"""
from __future__ import annotations

from collections import Counter

from ..crypto import h
from ..pipeline.episode import Episode


def affected(ep: Episode):
    """Multiset of commands not present in the benign counterfactual."""
    if ep.family == "forgery":
        return Counter(range(len(ep.cmds)))  # every command of a forged intent is attack-caused
    if ep.cls == "reorder":
        return Counter(i for i, (a, b) in enumerate(zip(ep.cmds, ep.benign_cmds)) if h(a) != h(b))
    bc = Counter(h(c) for c in ep.benign_cmds)
    out: Counter[int] = Counter()
    for i, c in enumerate(ep.cmds):
        k = h(c)
        if bc[k] > 0:
            bc[k] -= 1
        else:
            out[i] += 1
    return out


def is_effective(ep: Episode) -> bool:
    """Paper Sec. 7.3: the command sequence differs from the benign one, or the family is forgery."""
    return [h(c) for c in ep.cmds] != [h(c) for c in ep.benign_cmds] or ep.family == "forgery"


def attack_caused_predicate(ep: Episode):
    """Return f(i) -> True if arriving command i is attack-caused (by position or by content)."""
    aff = set(affected(ep))
    aff_h = {h(ep.cmds[i]) for i in aff}

    def is_aff(i: int | None) -> bool:
        return i is not None and (i in aff or h(ep.cmds[i]) in aff_h)

    return is_aff
