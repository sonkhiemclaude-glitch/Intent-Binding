"""Episode scoring and aggregation (paper Sec. 7.3, Metrics)."""
