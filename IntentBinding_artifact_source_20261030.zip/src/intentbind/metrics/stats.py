"""Summary statistics (paper Sec. 7.3, "Metrics": means over seeds with 95% t-intervals)."""
from __future__ import annotations

import math
from collections.abc import Iterable

from scipy import stats


def mean_t_interval(values: Iterable[float], level: float = 0.95) -> tuple[float, float]:
    """Return (mean, half-width) of a two-sided Student-t confidence interval over per-seed values.

    Edge cases: n = 0 -> (nan, nan); n = 1 -> (value, 0.0) because no spread can be estimated
    (reported as a point value, never as a zero-width interval claim). Values must be finite.
    """
    x = [float(v) for v in values]
    if not 0.0 < level < 1.0:
        raise ValueError("level must be in (0, 1)")
    n = len(x)
    if n == 0:
        return math.nan, math.nan
    if any(not math.isfinite(v) for v in x):
        raise ValueError("values must be finite")
    m = sum(x) / n
    if n < 2:
        return m, 0.0
    sd = (sum((v - m) ** 2 for v in x) / (n - 1)) ** 0.5
    return m, float(stats.t.ppf(0.5 + level / 2, n - 1)) * sd / math.sqrt(n)


def safe_rate(numerator: float, denominator: float) -> float:
    """numerator / denominator, or nan when the denominator is zero (never silently 0)."""
    if denominator < 0 or numerator < 0:
        raise ValueError("counts must be non-negative")
    return math.nan if denominator == 0 else numerator / denominator
