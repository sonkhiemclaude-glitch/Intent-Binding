"""Aggregate episode rows into the quantities reported in the paper (Tables 4, 5, S1; Fig. 2; Sec. 7.4-7.6).

All rates are computed per seed and summarised as mean +/- 95% t half-width over seeds
(``metrics.stats.mean_t_interval``). Keys use ``mode|defence|family[|class]``.

Reported quantities and where they appear in the paper:
  fpr                          benign episodes with any flag (Table 4 last row; Table 5)
  fpr_by_type                  pooled over seeds, by intent type (Table 5; Fig. 2a)
  dr_family / dr_class         detection among effective attacks (Table 4; Table S1)
  dr_overall_all               pooled over all effective classes (abstract, Sec. 7.4)
  dr_overall_excl_within       pooled, excluding WITHIN_INTENT classes (Table 4; Fig. 2b)
  dr_macro_all / _excl_within  mean over classes of the pooled class rate (Sec. 7.4)
  dr_keyholder_excl_within     insider + injection + drift (Sec. 7.4)
  share_chain_families_excl_within  share of chain-level episodes (Sec. 7.4)
  cause_accuracy               first cause is a chain cause iff the family is chain-level (Sec. 7.4)
"""
from __future__ import annotations

from typing import Any

import pandas as pd

from ..attacks.catalogue import CHAIN_FAMILIES, KEYHOLDER_FAMILIES, WITHIN_INTENT
from ..binding.verifier import CHAIN_CAUSES
from .stats import mean_t_interval

REQUIRED_COLUMNS = ("seed", "mode", "itype", "family", "cls", "defense", "effective", "detected",
                    "pre_detected", "first_cause", "n_flags", "benign_flagged")


def _within_mask(df: pd.DataFrame) -> pd.Series:
    if df.empty:
        return pd.Series([], dtype=bool, index=df.index)
    return df.apply(lambda r: (r.family, r.cls) in WITHIN_INTENT, axis=1)


def summarise(df: pd.DataFrame) -> dict[str, Any]:
    """Compute the summary dictionary from an episode table (one row per episode and defence)."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"episode table lacks columns {missing}")
    df = df.copy()
    df["first_cause"] = df["first_cause"].fillna("")
    ci = mean_t_interval
    out: dict[str, Any] = {}

    ben = df[df.family == "benign"]
    fp = ben.assign(f=(ben.n_flags > 0).astype(int)).groupby(["mode", "defense", "seed"]).f.mean().reset_index()
    out["fpr"] = {f"{m}|{d}": ci(g.f) for (m, d), g in fp.groupby(["mode", "defense"])}
    fpt = ben.assign(f=(ben.n_flags > 0).astype(int)).groupby(["mode", "defense", "itype"]).f.mean()
    out["fpr_by_type"] = {f"{m}|{d}|{t}": v for (m, d, t), v in fpt.items()}

    att = df[(df.family != "benign") & (df.effective == 1)]
    fam = att.groupby(["mode", "defense", "family", "seed"]).agg(dr=("detected", "mean"),
                                                                  pre=("pre_detected", "mean")).reset_index()
    out["dr_family"] = {f"{m}|{d}|{f}": {"dr": ci(g.dr), "pre": ci(g.pre)}
                        for (m, d, f), g in fam.groupby(["mode", "defense", "family"])}
    cls = att.groupby(["mode", "defense", "family", "cls", "seed"]).agg(dr=("detected", "mean"),
                                                                         pre=("pre_detected", "mean")).reset_index()
    out["dr_class"] = {f"{m}|{d}|{f}|{c}": {"dr": ci(g.dr), "pre": ci(g.pre)}
                       for (m, d, f, c), g in cls.groupby(["mode", "defense", "family", "cls"])}
    # Episode counts and family shares do not depend on which defence scored them.
    reference = "FULL" if "FULL" in df.defense.values else df.defense.iloc[0]
    cnt = att[att.defense == reference].groupby(["mode", "family", "cls"]).size()
    out["n_effective"] = {f"{m}|{f}|{c}": int(v) for (m, f, c), v in cnt.items()}
    allatt = df[(df.family != "benign") & (df.defense == reference)].groupby(["mode", "family", "cls"]).size()
    out["n_total"] = {f"{m}|{f}|{c}": int(v) for (m, f, c), v in allatt.items()}

    a2 = att[~_within_mask(att)]
    fam2 = a2.groupby(["mode", "defense", "family", "seed"]).detected.mean().reset_index()
    out["dr_family_excl_within"] = {f"{m}|{d}|{f}": ci(g.detected)
                                    for (m, d, f), g in fam2.groupby(["mode", "defense", "family"])}
    ov = a2.groupby(["mode", "defense", "seed"]).detected.mean().reset_index()
    out["dr_overall_excl_within"] = {f"{m}|{d}": ci(g.detected) for (m, d), g in ov.groupby(["mode", "defense"])}

    allc = att.groupby(["mode", "defense", "seed"]).detected.mean().reset_index()
    out["dr_overall_all"] = {f"{m}|{d}": ci(g.detected) for (m, d), g in allc.groupby(["mode", "defense"])}
    macro = att.groupby(["mode", "defense", "family", "cls"]).detected.mean().reset_index()
    out["dr_macro_all"] = {f"{m}|{d}": float(g.detected.mean()) for (m, d), g in macro.groupby(["mode", "defense"])}
    m2 = macro[~_within_mask(macro)]
    out["dr_macro_excl_within"] = {f"{m}|{d}": float(g.detected.mean())
                                   for (m, d), g in m2.groupby(["mode", "defense"])}
    kh = (a2[a2.family.isin(sorted(KEYHOLDER_FAMILIES))].groupby(["mode", "defense", "seed"])
          .detected.mean().reset_index())
    out["dr_keyholder_excl_within"] = {f"{m}|{d}": ci(g.detected) for (m, d), g in kh.groupby(["mode", "defense"])}
    chs = a2[a2.family.isin(sorted(CHAIN_FAMILIES))]
    out["share_chain_families_excl_within"] = {
        m: float(len(g[g.defense == reference])) / float(len(a2[(a2["mode"] == m) & (a2.defense == reference)]))
        for m, g in chs.groupby("mode")}
    op = att[(att.defense == "FULL") & (att.detected == 1) & (att.family == "injection")]
    out["injection_first_cause_FULL"] = {m: g.first_cause.value_counts().to_dict() for m, g in op.groupby("mode")}

    fd = att[(att.defense == "FULL") & (att.detected == 1)].copy()
    fd["pred_chain"] = fd.first_cause.isin(sorted(CHAIN_CAUSES))
    fd["true_chain"] = fd.family.isin(sorted(CHAIN_FAMILIES))
    fd["ok"] = fd.pred_chain == fd.true_chain
    out["cause_accuracy"] = {m: float(g.ok.mean()) for m, g in fd.groupby("mode")}
    out["cause_counts"] = {f"{m}|{f}": g.first_cause.value_counts().to_dict()
                           for (m, f), g in fd.groupby(["mode", "family"])}
    col = df[(df.family != "benign") & (df.defense == "FULL")]
    out["collateral_mean_benign_flagged"] = {m: float(g.benign_flagged.mean()) for m, g in col.groupby("mode")}
    out["n_rows"] = int(len(df))
    n_def = max(1, df.defense.nunique())
    n_modes = max(1, df["mode"].nunique())
    # Corrected: the archived 2026-10-18 script divided by a hard-coded 7 defences (see audits).
    out["n_benign_episodes_per_mode"] = int(len(ben) / n_def / n_modes)
    return out


def read_episodes(path: str) -> pd.DataFrame:
    """Read an episode CSV(.gz) written by the component runner."""
    return pd.read_csv(path)
