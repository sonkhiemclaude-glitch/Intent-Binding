"""Command-line interface: ``intentbind <command>`` (see README.md, "Commands").

The CLI never downloads anything and never executes commands taken from config files.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import yaml

from . import __version__
from .errors import ConfigError, ExternalDependencyMissing, SchemaError
from .utils.logging import setup_logging

REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SYNTHETIC = REPO_ROOT / "configs" / "synthetic_demo.yaml"


def _overrides(pairs: list[str] | None) -> dict:
    out = {}
    for p in pairs or []:
        if "=" not in p:
            raise ConfigError(f"--set expects key=value, got {p!r}")
        k, v = p.split("=", 1)
        out[k.strip()] = yaml.safe_load(v)  # data only; never evaluated as code
    return out


def _load(path: str | None, overrides: list[str] | None, fallback: Path | None = None):
    from .utils.config import load_config
    p = Path(path) if path else fallback
    if p is None:
        raise ConfigError("--config is required")
    return load_config(p, _overrides(overrides))


def cmd_demo(a) -> int:
    from .experiments.stages import run_stage
    cfg = _load(a.config, a.set, DEFAULT_SYNTHETIC)
    if not cfg.is_synthetic:
        raise ConfigError("the demo command only runs configs with label: synthetic_smoke")
    paths = run_stage("all", cfg, a.out)
    print(f"[{cfg.label_text()}] wrote {len(paths)} files to {a.out or cfg.output_dir}")
    for p in paths:
        print("  ", p)
    return 0


def cmd_run(a) -> int:
    from .experiments.stages import run_stage
    cfg = _load(a.config, a.set)
    paths = run_stage(a.stage, cfg, a.out)
    print(f"[{cfg.label_text()}] stage {a.stage}: {len(paths)} files")
    for p in paths:
        print("  ", p)
    return 0


def cmd_testbed(a) -> int:
    from .controllers.testbed import run_testbed
    from .experiments.testbed_summary import summarise_testbed
    from .utils.io import read_json, write_json
    cfg = _load(a.config, a.set)
    if a.check_only:
        from .controllers.mininet_ovs import check_environment
        check_environment()
        print("Mininet/OVS environment OK")
        return 0
    path = run_testbed(cfg, a.out)
    s = write_json(path.parent / "testbed_summary.json", summarise_testbed(read_json(path)))
    print("wrote", path, "and", s)
    return 0


def cmd_attacks(a) -> int:
    from .attacks.catalogue import ATTACKS, FAMILIES
    for f, cs in ATTACKS.items():
        print(f"{f:15s} {FAMILIES[f].threat:2s} {FAMILIES[f].label}: {', '.join(cs)}")
    print(f"total classes: {sum(map(len, ATTACKS.values()))}")
    return 0


def cmd_baselines(a) -> int:
    from .baselines import BASELINES
    for b in BASELINES.values():
        print(f"{b.key:20s} {b.kind:13s} {b.paper_name}: {b.description}")
    return 0


def cmd_adapters(a) -> int:
    from .data.adapters import ADAPTERS
    root = a.data_root
    for key, cls in ADAPTERS.items():
        ad = cls(root)
        try:
            loc = ad.check_present()
            status = f"files present at {loc} (mapping not implemented, {ad.dataset.todo_id})"
        except ExternalDependencyMissing as e:
            status = f"missing: {e}"
        print(f"{key:15s} {ad.dataset.name}\n    {status}")
    return 0


def cmd_validate_intents(a) -> int:
    from .data.intent_sets import load_intent_file
    from .network.model import Topology
    recs = load_intent_file(a.path, Topology(hosts_per_access=a.hosts_per_access))
    print(f"{a.path}: {len(recs)} valid intent records")
    return 0


def cmd_verify_archive(a) -> int:
    from .utils.provenance import verify_manifest
    d = Path(a.dir)
    problems = verify_manifest(d)
    if problems:
        for p in problems:
            print("FAIL", p)
        return 1
    print(f"{d}: all files match MANIFEST.sha256")
    if a.regenerate_summary:
        from .metrics.aggregate import read_episodes, summarise
        from .utils.io import read_json
        S = read_json(d / "summary.json")
        N = json.loads(json.dumps(summarise(read_episodes(str(d / "component_episodes.csv.gz"))), default=float)
                       .replace("NaN", "null"))
        from .utils.compare import differing_keys
        diff = differing_keys(S, N)
        print("summary keys that differ after regeneration:", diff or "none")
        expected = {"n_benign_episodes_per_mode"}  # documented correction, audits/result_integrity_audit.md
        return 0 if set(diff) <= expected else 1
    return 0


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="intentbind", description=__doc__)
    ap.add_argument("--version", action="version", version=f"intentbind {__version__}")
    ap.add_argument("--log-level", default="INFO")
    sub = ap.add_subparsers(dest="command", required=True)

    def common(p, config_required=True):
        p.add_argument("--config", required=config_required, help="YAML config (configs/)")
        p.add_argument("--out", default=None, help="output directory (default: config output_dir)")
        p.add_argument("--set", action="append", metavar="KEY=VALUE", help="override a top-level config key")

    p = sub.add_parser("demo", help="synthetic smoke test: every stage on a tiny grid (not a paper result)")
    common(p, config_required=False)
    p.set_defaults(fn=cmd_demo)
    p = sub.add_parser("run", help="run one stage or all stages of an experiment config")
    common(p)
    p.add_argument("--stage", required=True,
                   choices=["component", "aggregate", "miss-audit", "overhead", "tables", "figures", "all"])
    p.set_defaults(fn=cmd_run)
    p = sub.add_parser("testbed", help="Mininet/OVS data-plane run (Linux, root; see the Mac Studio guide)")
    common(p)
    p.add_argument("--check-only", action="store_true", help="only check that Mininet/OVS/root are available")
    p.set_defaults(fn=cmd_testbed)
    sub.add_parser("attacks", help="list the attack catalogue (Table 3)").set_defaults(fn=cmd_attacks)
    sub.add_parser("baselines", help="list defences and external adapters").set_defaults(fn=cmd_baselines)
    p = sub.add_parser("adapters", help="status of external dataset adapters")
    p.add_argument("--data-root", default=None)
    p.set_defaults(fn=cmd_adapters)
    p = sub.add_parser("validate-intents", help="validate a JSONL intent file (docs/data_format.md)")
    p.add_argument("path")
    p.add_argument("--hosts-per-access", type=int, default=4)
    p.set_defaults(fn=cmd_validate_intents)
    p = sub.add_parser("verify-archive", help="check an archived result folder against its manifest")
    p.add_argument("dir")
    p.add_argument("--regenerate-summary", action="store_true",
                   help="recompute summary.json from the archived episode CSV and compare")
    p.set_defaults(fn=cmd_verify_archive)
    return ap


def main(argv: list[str] | None = None) -> int:
    a = build_parser().parse_args(argv)
    setup_logging(a.log_level)
    try:
        return int(a.fn(a) or 0)
    except (ConfigError, SchemaError, FileNotFoundError, ExternalDependencyMissing) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
