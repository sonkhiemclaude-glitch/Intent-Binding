"""Audit of FULL misses with the independent LTLf evaluator (paper Sec. 7.4, Q2; Proposition 4).

For every effective attacked episode that FULL does not detect, the unprotected (B0) command trace is
evaluated against every compiled constraint with ``conformance.ltlf``. A conformant trace means the miss
is a specification gap or a within-intent change, not a monitoring error; a non-conformant miss would be
a checker bug.

Definitions are those of the component runner (``metrics.attribution``, ``metrics.episode``): effective =
command *sequence* differs from the benign one (or forgery); detected = pre-execution block of an
attack-caused command, or a post-execution flag absent from the paired benign run. The archived
2026-10-18 script used a multiset test for "effective" and no benign pairing for post flags; at path2 the
two give the same set because FULL detected every reorder episode and raised no post flag on benign runs
(see audits/math_to_code_audit.md, M-8).
"""
from __future__ import annotations

import collections
from pathlib import Path

from ..attacks.catalogue import ATTACKS
from ..attacks.episodes import attack_episode
from ..conformance.ltlf import formula, holds, positions
from ..data.intent_sets import file_workload, load_intent_file, paper_workload
from ..defenses.runner import run_defense
from ..errors import NotApplicable
from ..metrics.attribution import attack_caused_predicate, is_effective
from ..metrics.episode import attack_row
from ..network import model as nm
from ..pipeline.episode import benign_episode
from ..pipeline.world import World
from ..utils.config import ExperimentConfig
from ..utils.io import write_json
from ..utils.provenance import RunRecord
from ..utils.seeding import attack_rng, episode_seed

MISS_FILE = "miss_audit.json"


def trace_conforms(world: World, intent: dict, cmds: list[dict]) -> bool:
    P = positions(world.topo, nm.initial_state(world.topo), cmds)
    for c in intent["constraints"]:
        cc = dict(c)
        if c["t"] == "precedence":
            cc["_vals"] = sorted({x.get(c["key"]) for x in cmds if x.get("op") in (c["a"], c["b"])}, key=str)
        if not holds(formula(world.topo, cc), P):
            return False
    return True


def run_miss_audit(cfg: ExperimentConfig, out_dir: str | Path | None = None) -> Path:
    out = Path(out_dir or cfg.output_dir)
    rec = RunRecord("miss_audit", out, cfg.to_dict(), cfg.label_text())
    mode = cfg.miss_audit.mode
    res: dict[str, collections.Counter] = collections.defaultdict(collections.Counter)
    families = [f for f in ATTACKS if f in cfg.attack_families]
    for seed in cfg.seeds:
        world = World.build(cfg.max_refiners, key_seed=cfg.key_seed_bytes())
        if cfg.intents.source == "file":
            records = load_intent_file(cfg.intents.path, world.topo)  # type: ignore[arg-type]
            workload = file_workload(world.topo, records, seed, mode, cfg.refiner_choices)
        else:
            workload = paper_workload(world.topo, seed, cfg.intents_per_seed, mode, cfg.refiner_choices)
        for k, (it, nr) in enumerate(workload):
            es = episode_seed(seed, k)
            ben = run_defense(world, benign_episode(world, it, es, nr, cfg.detour_p), "FULL")
            ben_drift = ben if nr >= 1 else run_defense(world, benign_episode(world, it, es, 1, cfg.detour_p), "FULL")
            for fam in families:
                for cls in ATTACKS[fam]:
                    try:
                        ep = attack_episode(world, it, es, fam, cls, n_refiners=(nr if fam != "drift" else max(nr, 1)),
                                            detour_p=cfg.detour_p, rng=attack_rng(es, fam, cls))
                    except NotApplicable:
                        continue
                    if not is_effective(ep):
                        continue
                    r = run_defense(world, ep, "FULL")
                    row = attack_row(seed, mode, it["type"], nr, ep, "FULL", r, ben_drift if fam == "drift" else ben,
                                     attack_caused_predicate(ep), True)
                    if row.detected:
                        continue
                    key = "conformant_miss" if trace_conforms(world, ep.intent, ep.cmds) else "NONCONFORMANT_MISS"
                    res[f"{mode}|{fam}|{cls}"][key] += 1
    path = write_json(out / MISS_FILE, {k: dict(v) for k, v in sorted(res.items())})
    rec.add_output(path)
    rec.write({"n_nonconformant": sum(v.get("NONCONFORMANT_MISS", 0) for v in res.values())})
    return path
