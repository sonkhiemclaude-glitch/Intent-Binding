"""Experiment stages: component grid, miss audit, overhead, tables, figures, testbed summary."""
