"""Result figures (paper Fig. 2 scope trade-off, Fig. 3 overhead) drawn only from result files.

Palette: blue #2a78d6, orange #eb6834, aqua #1baf7a. Aqua has < 3:1 contrast, so every series also carries
a hatch or marker and a direct label. Synthetic runs get a visible watermark and a title prefix stating
"synthetic smoke-test output, not a paper result".
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from ..utils.config import SYNTHETIC_LABEL_TEXT  # noqa: E402

C = {"blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#d9d8d4"
RC: Any = {"font.family": "serif", "font.size": 8, "axes.edgecolor": INK2, "axes.labelcolor": INK,
      "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
      "pdf.fonttype": 42, "axes.titlesize": 8, "legend.fontsize": 7, "legend.frameon": False}
MODES = ["strict", "path0", "path2"]
MODE_LABELS = {"strict": "strict", "path0": "path, slack 0", "path2": "path, slack 2"}


def _mark_synthetic(fig) -> None:
    fig.text(0.5, 0.5, SYNTHETIC_LABEL_TEXT.upper(), ha="center", va="center", rotation=20, fontsize=13,
             color="#b00020", alpha=0.35, zorder=100)
    fig.text(0.01, 0.005, SYNTHETIC_LABEL_TEXT, ha="left", va="bottom", fontsize=6.5, color="#b00020")


def fig_scope_tradeoff(S: dict, out: Path, synthetic: bool) -> Path:
    cols = [C["blue"], C["orange"], C["aqua"]]
    hatches = ["", "////", "...."]
    modes = [m for m in MODES if f"{m}|FULL" in S.get("fpr", {})]
    with plt.rc_context(RC):
        fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.5))
        w = 0.26

        def bars(ax, groups, getter, ylabel, title):
            for i, m in enumerate(modes):
                vals = [100 * getter(m, g) for g in groups]
                xs = [j + (i - (len(modes) - 1) / 2) * w for j in range(len(groups))]
                ci = MODES.index(m)  # fixed colour and hatch per mode, also when a mode is absent
                ax.bar(xs, vals, width=w - 0.02, color=cols[ci], hatch=hatches[ci], edgecolor="white", linewidth=0.5,
                       label=MODE_LABELS[m])
                for x, v in zip(xs, vals):
                    ax.text(x, v + 2, f"{v:.0f}" if v < 99.5 or v > 100.4 else "100", ha="center", va="bottom",
                            fontsize=6.5, color=INK)
            ax.set_xticks(range(len(groups)))
            ax.set_ylabel(ylabel)
            ax.set_ylim(0, 115)
            ax.set_title(title, loc="left")
            ax.yaxis.grid(True, color=GRID, linewidth=0.5)
            ax.set_axisbelow(True)

        def dr_get(m, g):
            if g == "hijack":
                v = S["dr_class"].get(f"{m}|FULL|insider|hijack")
                return v["dr"][0] if v else 0.0
            return S["dr_overall_excl_within"][f"{m}|FULL"][0]

        pre = "Synthetic. " if synthetic else ""
        bars(axes[0], ["bandwidth", "waypoint"], lambda m, t: S["fpr_by_type"].get(f"{m}|FULL|{t}", 0.0),
             "benign episodes flagged (%)", pre + "(a) False positives")
        axes[0].set_xticklabels(["bandwidth intents", "waypoint intents"])
        bars(axes[1], ["hijack", "overall"], dr_get, "attacks detected by FULL (%)", pre + "(b) Detection")
        axes[1].set_xticklabels(["insider path via x1", "all classes excl.\nwithin-intent"])
        h, lab = axes[0].get_legend_handles_labels()
        fig.legend(h, lab, loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.0))
        fig.tight_layout(rect=(0, 0.03 if synthetic else 0, 1, 0.9))
        if synthetic:
            _mark_synthetic(fig)
        path = out / "fig_scope_tradeoff.pdf"
        fig.savefig(path)
        if synthetic:
            fig.savefig(out / "fig_scope_tradeoff.png", dpi=150)
        plt.close(fig)
    return path


def fig_overhead(O: dict, out: Path, synthetic: bool) -> Path:
    hops = sorted(int(k.split("=")[1]) for k in O["bundle_sizes"])
    with plt.rc_context(RC):
        fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.3))
        ax = axes[0]
        med = [O["chain_verify"][f"bandwidth/hops={h}"]["median_us"] / 1000 for h in hops]
        p95 = [O["chain_verify"][f"bandwidth/hops={h}"]["p95_us"] / 1000 for h in hops]
        ax.plot(hops, med, color=C["blue"], marker="o", markersize=4, linewidth=2, label="median")
        ax.plot(hops, p95, color=C["orange"], marker="s", markersize=4, linewidth=2, linestyle="--",
                label="95th percentile")
        ax.set_xticks(hops)
        ax.set_xlabel("hops in the chain (incl. executor)")
        ax.set_ylabel("chain verification (ms)")
        ax.set_ylim(0, max(p95) * 1.25)
        ax.yaxis.grid(True, color=GRID, linewidth=0.5)
        ax.set_axisbelow(True)
        ax.legend(loc="upper left")
        pre = "Synthetic. " if synthetic else ""
        ax.set_title(pre + "(a) One-time chain verification per intent", loc="left")
        ax2 = axes[1]
        by = [(O["bundle_sizes"][f"hops={h}"]["root"] + O["bundle_sizes"][f"hops={h}"]["hop_tokens"] +
               O["bundle_sizes"][f"hops={h}"]["certs"]) / 1000 for h in hops]
        ax2.plot(hops, by, color=C["blue"], marker="o", markersize=4, linewidth=2)
        for h, b in zip(hops, by):
            if h in (hops[0], hops[-1]):
                first = h == hops[0]
                ax2.text(h + (0.15 if first else -0.15), b + 0.9, f"{b:.1f} kB", ha="left" if first else "right",
                         fontsize=6.5, color=INK)
        ax2.set_xticks(hops)
        ax2.set_xlabel("hops in the chain (incl. executor)")
        ax2.set_ylabel("tokens + certificates (kB)")
        ax2.set_ylim(0, max(by) * 1.3)
        ax2.yaxis.grid(True, color=GRID, linewidth=0.5)
        ax2.set_axisbelow(True)
        ax2.set_title(pre + "(b) Binding bytes per intent", loc="left")
        fig.tight_layout(rect=(0, 0.03 if synthetic else 0, 1, 1))
        if synthetic:
            _mark_synthetic(fig)
        path = out / "fig_overhead.pdf"
        fig.savefig(path)
        if synthetic:
            fig.savefig(out / "fig_overhead.png", dpi=150)
        plt.close(fig)
    return path


def write_figures(out_dir: str | Path, *, summary: dict | None = None, overhead: dict | None = None,
                  synthetic: bool) -> list[Path]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []
    if summary is not None:
        written.append(fig_scope_tradeoff(summary, out, synthetic))
    if overhead is not None:
        written.append(fig_overhead(overhead, out, synthetic))
    return written
