"""Microbenchmarks (paper Sec. 7.8, Table 7, Fig. 3): token sizes, signing and verification cost, chain
verification vs hops, Merkle proof size and cost, conformance cost.

Timings depend on the machine; the archived values were measured on a 2-vCPU Intel Xeon 2.1 GHz cloud VM.
Repetition counts come from ``OverheadConfig`` (paper values are the defaults). Chain-verification
conditions are interleaved over rounds so that machine drift affects all conditions equally.
"""
from __future__ import annotations

import json
import platform
import random
import statistics
import subprocess
import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

import cryptography

from ..binding.merkle import merkle_root_and_proofs, merkle_verify
from ..conformance.checker import Checker
from ..crypto import KeyPair, canon, jws_sign, jws_verify
from ..intents.generator import make_intent
from ..network import model as nm
from ..pipeline.episode import run_pipeline
from ..pipeline.world import World
from ..utils.config import ExperimentConfig
from ..utils.io import write_json
from ..utils.provenance import RunRecord

OVERHEAD_FILE = "overhead.json"


def cpu_model() -> str:
    """CPU description without shell interpolation (Linux /proc/cpuinfo, macOS sysctl, else platform)."""
    p = Path("/proc/cpuinfo")
    if p.exists():
        for line in p.read_text().splitlines():
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    if platform.system() == "Darwin":
        try:
            r = subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True,
                               timeout=5, check=False)
            if r.stdout.strip():
                return r.stdout.strip()
        except (OSError, subprocess.SubprocessError):
            pass
    return platform.processor() or platform.machine()


def tm(f: Callable[[], Any], n: int) -> dict:
    xs = []
    for _ in range(n):
        t = time.perf_counter_ns()
        f()
        xs.append((time.perf_counter_ns() - t) / 1000)
    xs.sort()
    return {"median_us": round(statistics.median(xs), 2), "p95_us": round(xs[int(0.95 * len(xs))], 2), "n": n}


def measure_overhead(cfg: ExperimentConfig) -> dict:
    oc = cfg.overhead
    R: dict[str, Any] = {"env": {"python": platform.python_version(), "cryptography": cryptography.__version__,
                                 "cpu": cpu_model(), "platform": platform.platform()},
                         "config": {"reps_primitive": oc.reps_primitive, "rounds_chain": oc.rounds_chain,
                                    "reps_chain_per_round": oc.reps_chain_per_round,
                                    "reps_conformance": oc.reps_conformance, "max_hops": oc.max_hops}}
    max_ref = oc.max_hops - 3
    w = World.build(max_refiners=max_ref, key_seed=cfg.key_seed_bytes())
    rng = random.Random(1)
    k = KeyPair.generate("b", cfg.key_seed_bytes())
    payload = {"iid": "I-1", "k": 2, "role": "planner", "dom": "ops", "eid": "E-1", "prev": "0" * 64,
               "in": "1" * 64, "out": "2" * 64, "cert": "3" * 64}
    tok = jws_sign(payload, k, "ib-hop")
    R["sign_hop"] = tm(lambda: jws_sign(payload, k, "ib-hop"), oc.reps_primitive)
    R["verify_hop"] = tm(lambda: jws_verify(tok, k.pk), oc.reps_primitive)
    sizes, bundles = {}, {}
    for itype in ("bandwidth", "slice"):
        it = make_intent(w.topo, rng, itype, 1, "path0")
        for nr in range(0, max_ref + 1):
            b, _cmds, _proofs = run_pipeline(w, it, 7, nr)
            bundles[(itype, nr + 3)] = b
            if itype == "bandwidth":
                sizes[f"hops={nr + 3}"] = {"root": len(b.root), "hop_tokens": sum(map(len, b.hops)),
                                         "certs": sum(map(len, b.certs)), "intent_body": len(canon(it)),
                                         "exec_artifact": len(canon(b.exec_artifact))}
    samples: dict[tuple, list[float]] = {key: [] for key in bundles}
    for _ in range(oc.rounds_chain):
        for (itype, hops), b in bundles.items():
            dom = "5g" if itype == "slice" else "sdn"
            for _ in range(oc.reps_chain_per_round):
                ver = w.verifier(dom)
                t = time.perf_counter_ns()
                ver.verify_chain(b)
                samples[(itype, hops)].append((time.perf_counter_ns() - t) / 1000)
    chain = {}
    for (itype, hops), xs in samples.items():
        xs.sort()
        chain[f"{itype}/hops={hops}"] = {"median_us": round(statistics.median(xs), 2),
                                         "p95_us": round(xs[int(0.95 * len(xs))], 2), "n": len(xs)}
    R["chain_verify"] = chain
    b = bundles[("slice", oc.max_hops)]  # as in the archived run: the last bundle built
    R["bytes_per_hop"] = {"hop_token_mean": round(sum(map(len, b.hops)) / len(b.hops), 1),
                          "cert_mean": round(sum(map(len, b.certs)) / len(b.certs), 1), "root": len(b.root)}
    R["bundle_sizes"] = sizes
    mk = {}
    for n in (1, 4, 16, 64, 256):
        cmds = [{"op": "block", "src": f"h{i}", "dst": "h1", "port": 22, "switch": "a11"} for i in range(n)]
        root, proofs = merkle_root_and_proofs(cmds)
        p = proofs[n // 2]

        def verify_one(c: list = cmds, p: list = p, r: str = root, n: int = n) -> bool:
            return merkle_verify(c[n // 2], n // 2, p, r)
        mk[str(n)] = {"proof_bytes_json": len(json.dumps(p)), "proof_hashes": len(p),
                      "verify": tm(verify_one, max(1, (2 * oc.reps_primitive) // 3))}
    R["merkle"] = mk
    cs = {}
    it = make_intent(w.topo, rng, "isolate", 2, "path0")
    cmd = {"op": "isolate", "host": it["spec"]["host"], "switch": w.topo.edge_of[it["spec"]["host"]]}
    s0 = nm.initial_state(w.topo)
    for mult in (1, 4, 16):
        C = [dict(c, id=f"{c['id']}_{m}") for m in range(mult) for c in it["constraints"]]

        def step(C: list = C) -> Any:
            return Checker(w.topo, C, s0, "block").step(cmd)

        def goal(C: list = C) -> Any:
            return Checker(w.topo, C, s0, "block").finish()
        cs[str(len(C))] = {"step": tm(step, max(1, oc.reps_conformance * 3 // 2)),
                           "goal_check": tm(goal, max(1, oc.reps_conformance // 2))}
    R["conformance_step_isolate"] = cs
    per = {}
    for itype in ("bandwidth", "waypoint", "block", "slice"):
        it = make_intent(w.topo, rng, itype, 3, "path2")
        _b, cmds, _p = run_pipeline(w, it, 9, 0)

        def run_all(it=it, cmds=cmds):
            ch = Checker(w.topo, it["constraints"], s0, "block")
            for c in cmds:
                ch.step(c)
            ch.finish()
        per[itype] = dict(tm(run_all, oc.reps_conformance), n_cmds=len(cmds), n_constraints=len(it["constraints"]))
    R["conformance_per_intent"] = per
    return R


def run_overhead(cfg: ExperimentConfig, out_dir: str | Path | None = None) -> Path:
    out = Path(out_dir or cfg.output_dir)
    rec = RunRecord("overhead", out, cfg.to_dict(), cfg.label_text())
    R = measure_overhead(cfg)
    R["label"] = cfg.label_text()
    path = write_json(out / OVERHEAD_FILE, R)
    rec.add_output(path)
    rec.write()
    return path
