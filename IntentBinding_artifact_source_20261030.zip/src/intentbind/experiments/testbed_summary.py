"""Summary of an emulated data-plane run (testbed.json -> testbed_summary.json; paper Sec. 7.7, Table 6)."""
from __future__ import annotations

import statistics
from typing import Any


def _med(xs: list[float]) -> float | None:
    return statistics.median(xs) if xs else None


def summarise_testbed(T: dict) -> dict[str, Any]:
    ben, att = T["benign"], T.get("attack", [])
    ctrl = T.get("control", [])
    out: dict[str, Any] = {
        "control_agree": [sum(p["model"] == p["measured"] for p in ctrl), len(ctrl)],
        "benign_n": len(ben),
        "benign_agree": [sum(p["model"] == p["measured"] for r in ben for p in r["probes"]),
                         sum(len(r["probes"]) for r in ben)],
        "benign_chain_ok": sum(r["chain_ok"] for r in ben), "benign_flagged": sum(r["flagged"] for r in ben),
        "benign_goal_viol": sum(r["goal_viol"] for r in ben),
        "probe_kinds": {k: sum(1 for r in ben for p in r["probes"] if p["probe"][0] == k)
                        for k in ("icmp", "tcp", "via")},
    }
    by = {}
    for t in ("isolate", "block", "bandwidth", "waypoint"):
        R = [r for r in ben if r["type"] == t]
        by[t] = {"n": len(R), "chain_check_med_ms": _med([r["t_chain_ms"] + r["t_check_ms"] for r in R]),
                 "install_med_ms": _med([r["t_install_ms"] for r in R]),
                 "chain_med_ms": _med([r["t_chain_ms"] for r in R]), "check_med_ms": _med([r["t_check_ms"] for r in R])}
    out["by_type"] = by
    allcc = [r["t_chain_ms"] + r["t_check_ms"] for r in ben]
    allins = [r["t_install_ms"] for r in ben]
    out["overall"] = {"chain_check_med_ms": _med(allcc), "install_med_ms": _med(allins),
                      "ratio_med": _med([a / b for a, b in zip(allcc, allins) if b > 0])}
    A: dict[str, dict[str, list]] = {}
    for r in att:
        d = A.setdefault(f"{r['family']}/{r['cls']}", {"B0": [], "FULL": []})
        gw = [p for p in r["probes"] if p["probe"][2] == "gw" and p["probe"][0] == "icmp"]
        d[r["defense"]].append({"flags": r["flags"], "executed": r["executed"], "n_cmds": r["n_cmds"],
                                "agree": sum(p["model"] == p["measured"] for p in r["probes"]),
                                "probes": len(r["probes"]), "gw_ok": sum(p["measured"] for p in gw), "gw_n": len(gw)})
    out["attacks"] = {k: {d: {"episodes": len(v[d]), "gw_ok": sum(x["gw_ok"] for x in v[d]),
                              "gw_n": sum(x["gw_n"] for x in v[d]), "agree": sum(x["agree"] for x in v[d]),
                              "probes": sum(x["probes"] for x in v[d]),
                              "flagged_episodes": sum(1 for x in v[d] if x["flags"]),
                              "attack_cmds_blocked": sum(x["n_cmds"] - x["executed"] for x in v[d])} for d in v}
                      for k, v in A.items()}
    out["attack_agree_total"] = [sum(sum(p["model"] == p["measured"] for p in r["probes"]) for r in att),
                                 sum(len(r["probes"]) for r in att)]
    return out
