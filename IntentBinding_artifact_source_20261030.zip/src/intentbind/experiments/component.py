"""Component evaluation on the abstract model with scripted agents (paper Sec. 7.3-7.6, Tables 4-5, S1).

For every seed and scope mode: draw the workload, run the benign episode and every applicable attack class,
apply every configured defence, and score one row per (episode, defence). The loop order and RNG
derivations are identical to the archived paper run (verified by tests/test_regression_paper_run.py).
"""
from __future__ import annotations

import csv
import gzip
import logging
import time
from multiprocessing import Pool
from pathlib import Path
from typing import Any

from ..attacks.catalogue import ATTACKS
from ..attacks.episodes import attack_episode
from ..data.intent_sets import file_workload, load_intent_file, paper_workload
from ..defenses.runner import DEFENSES, run_defense
from ..errors import NotApplicable
from ..metrics.attribution import attack_caused_predicate, is_effective
from ..metrics.episode import FIELDS, attack_row, benign_row
from ..pipeline.episode import benign_episode
from ..pipeline.world import World
from ..utils.config import ExperimentConfig, config_from_dict
from ..utils.provenance import RunRecord
from ..utils.seeding import attack_rng, episode_seed

log = logging.getLogger(__name__)
EPISODES_FILE = "component_episodes.csv.gz"


def run_job(seed: int, mode: str, cfg: ExperimentConfig, records: list[dict] | None = None) -> list[list[Any]]:
    """All rows for one (seed, scope mode). Pure function of its arguments."""
    world = World.build(cfg.max_refiners, key_seed=cfg.key_seed_bytes())
    if cfg.intents.source == "file":
        if records is None:
            records = load_intent_file(cfg.intents.path, world.topo)  # type: ignore[arg-type]
        workload = file_workload(world.topo, records, seed, mode, cfg.refiner_choices)
    else:
        workload = paper_workload(world.topo, seed, cfg.intents_per_seed, mode, cfg.refiner_choices)
    defenses = [d for d in DEFENSES if d in cfg.defenses]
    families = [f for f in ATTACKS if f in cfg.attack_families]
    rows: list[list[Any]] = []
    for k, (it, nr) in enumerate(workload):
        itype = it["type"]
        es = episode_seed(seed, k)
        ben = benign_episode(world, it, es, nr, cfg.detour_p)
        ben_res = {d: run_defense(world, ben, d) for d in defenses}
        # drift needs at least one refiner; pair it with a benign episode of the same shape
        ben_res_drift = ben_res if nr >= 1 or "drift" not in families else \
            {d: run_defense(world, benign_episode(world, it, es, 1, cfg.detour_p), d) for d in defenses}
        for d, r in ben_res.items():
            rows.append(benign_row(seed, mode, itype, nr, d, r).as_list())
        for fam in families:
            for cls in ATTACKS[fam]:
                try:
                    ep = attack_episode(world, it, es, fam, cls, n_refiners=(nr if fam != "drift" else max(nr, 1)),
                                        detour_p=cfg.detour_p, rng=attack_rng(es, fam, cls))
                except NotApplicable:
                    continue
                is_aff = attack_caused_predicate(ep)
                eff = is_effective(ep)
                pair = ben_res_drift if fam == "drift" else ben_res
                for d in defenses:
                    r = run_defense(world, ep, d)
                    rows.append(attack_row(seed, mode, itype, nr, ep, d, r, pair[d], is_aff, eff).as_list())
    return rows


def _job(args: tuple[int, str, dict, list[dict] | None]) -> list[list[Any]]:
    seed, mode, cfg_dict, records = args
    return run_job(seed, mode, config_from_dict(cfg_dict), records)


def run_component(cfg: ExperimentConfig, out_dir: str | Path | None = None) -> Path:
    """Run the grid and write ``component_episodes.csv.gz`` plus run metadata. Returns the CSV path."""
    out = Path(out_dir or cfg.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    rec = RunRecord("component", out, cfg.to_dict(), cfg.label_text())
    records = None
    if cfg.intents.source == "file":
        records = load_intent_file(cfg.intents.path, World.build(0).topo)  # type: ignore[arg-type]
    cfg_dict = cfg.to_dict()
    jobs = [(s, m, cfg_dict, records) for s in cfg.seeds for m in cfg.scope_modes]
    path = out / EPISODES_FILE
    t0 = time.time()
    results: dict[tuple[int, str], list[list[Any]]] = {}
    if cfg.procs == 1:
        for j in jobs:
            results[(j[0], j[1])] = _job(j)
            log.info("job seed=%s mode=%s rows=%d t=%.0fs", j[0], j[1], len(results[(j[0], j[1])]), time.time() - t0)
    else:
        with Pool(cfg.procs) as pool:
            for j, rows in zip(jobs, pool.imap(_job, jobs)):
                results[(j[0], j[1])] = rows
                log.info("job seed=%s mode=%s rows=%d t=%.0fs", j[0], j[1], len(rows), time.time() - t0)
    # deterministic file order: seeds, then modes, as configured
    with gzip.GzipFile(path, "wb", mtime=0) as gz, open_text(gz) as f:
        w = csv.writer(f)
        w.writerow(FIELDS)
        for s in cfg.seeds:
            for m in cfg.scope_modes:
                w.writerows(results[(s, m)])
    rec.add_output(path)
    rec.write({"n_jobs": len(jobs), "n_rows": sum(len(v) for v in results.values())})
    return path


def open_text(gz: gzip.GzipFile):
    import io
    return io.TextIOWrapper(gz, encoding="utf-8", newline="")
