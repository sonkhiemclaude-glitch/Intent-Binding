"""LaTeX tables generated from result files only (paper Tables 4, 5, 6, 7 and Supplementary Table S1).

``write_tables`` never contains numbers of its own: every value is read from ``summary.json``,
``overhead.json`` and ``testbed.json``. Captions take run-specific facts (number of seeds, intents per seed,
hardware) from a ``context`` dict so that tables of a new run do not inherit the paper run's description.
Missing entries print as "--". Synthetic runs get a caption prefix marking them as non-paper output.
"""
from __future__ import annotations

import statistics
from pathlib import Path
from typing import Any

from ..attacks.catalogue import ATTACKS, FAMILIES
from ..utils.config import SYNTHETIC_LABEL_TEXT

D = ["B1a", "B1b", "B2", "BIND", "ROOTCONF", "CONF", "FULL"]
FAM = [(f, FAMILIES[f].label) for f in ("tamper_channel", "insider", "forgery", "injection", "drift",
                                         "cmd_injection", "exec_tamper")]
CLS_NAMES = {"widen": "widen target", "relax": "relax bound", "redirect": "redirect target", "hijack": "path via x1",
             "inbound": "in-bound change$^\\dagger$", "unsigned": "unsigned root", "spoofed_issuer": "spoofed issuer",
             "replay": "replay, new eid", "replay_same_eid": "replay, same eid", "reorder": "reorder committed",
             "expired": "expired", "body_modified": "body modified", "splice": "splice",
             "infra_isolate": "isolate gw/dns", "mirror": "mirror to attacker", "delete_flows": "delete flows",
             "bw_grab": "bandwidth grab", "cut": "cut a pair", "in_scope": "in-scope duplicate$^\\dagger$",
             "drop_step": "drop a sub-goal", "shift": "shift target"}
MODES = ("strict", "path0", "path2")


def pct(v: float | None, ci: float | None = None, bold: bool = False) -> str:
    if v is None:
        return "--"
    s = f"{100 * v:.1f}"
    if ci is not None and ci >= 0.0005:
        s += f"\\,$\\pm$\\,{100 * ci:.1f}"
    return f"\\textbf{{{s}}}" if bold else s


def _pair(d: dict, key: str, sub: str | None = None) -> tuple[float | None, float | None]:
    v = d.get(key)
    if v is None:
        return None, None
    if sub is not None:
        v = v.get(sub)
        if v is None:
            return None, None
    return v[0], v[1]


def _prefix(synthetic: bool) -> str:
    return f"\\textsc{{{SYNTHETIC_LABEL_TEXT}.}} " if synthetic else ""


def table_results(S: dict, mode: str, ctx: dict[str, Any], synthetic: bool) -> str:
    caption = (_prefix(synthetic) +
               r"Detection rate (\%) per attack family on the abstract model, scope mode path (slack 2); "
               f"mean $\\pm$ 95\\% CI over {ctx['n_seeds']} seeds ({ctx['intents_per_seed']} intents each). "
               "An episode counts as detected if an attack-caused command is blocked or rejected before execution, "
               "or a post-execution violation appears that the paired benign episode does not show. Within-intent "
               "classes (in-bound parameter change, in-scope duplicate; designed to stay within the signed "
               "constraints) are included in the family rows and in the first aggregate row, and excluded from the "
               "second. Aggregates depend on the mix of classes.")
    L = [r"\begin{table*}[t]", r"\centering\small", f"\\caption{{{caption}}}", r"\label{tab:results}",
         r"\resizebox{\textwidth}{!}{%", r"\begin{tabular}{lrrrrrrr}", r"\toprule",
         r"Attack family & B1a plan-state & B1b goal & B2 guardrail & BIND only & ROOT+CONF & CONF only & FULL \\",
         r"\midrule"]
    for f, name in FAM:
        row = [name] + [pct(*_pair(S["dr_family"], f"{mode}|{d}|{f}", "dr"), bold=(d == "FULL")) for d in D]
        L.append(" & ".join(row) + r" \\")
    L.append(r"\midrule")
    for title, key in (("All effective attacks (all classes)", "dr_overall_all"),
                       ("All effective attacks, excl.\\ within-intent classes", "dr_overall_excl_within"),
                       ("Benign episodes flagged (FPR)", "fpr")):
        row = [title] + [pct(*_pair(S[key], f"{mode}|{d}"), bold=(d == "FULL")) for d in D]
        L.append(" & ".join(row) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}}", r"\end{table*}"]
    return "\n".join(L) + "\n"


def table_perclass(S: dict, ctx: dict[str, Any], synthetic: bool) -> str:
    dr = S["dr_class"]

    def g(key: str, sub: str = "dr") -> float | None:
        return dr[key][sub][0] if key in dr else None

    caption = (_prefix(synthetic) +
               f"Supplementary Table S1. Per-class detection (\\%) on the abstract model (mean over {ctx['n_seeds']} "
               "seeds). `pre' is the share detected before execution. $n$ is the number of effective episodes "
               "(path2). $^\\dagger$within-intent class, designed to stay within $\\Phi_I$.")
    L = [r"\begin{table*}[t]", r"\centering\footnotesize", f"\\caption{{{caption}}}",
         r"\label{tab:perclass}", r"\resizebox{\textwidth}{!}{%", r"\begin{tabular}{llrrrrrrr}", r"\toprule",
         r"Family & Class & FULL path2 & pre & FULL path0 & CONF path2 & B1b & B2 & $n$ \\", r"\midrule"]
    for f, name in FAM:
        first = True
        for c in ATTACKS[f]:
            k2 = f"path2|FULL|{f}|{c}"
            if k2 not in dr:
                continue
            n = S["n_effective"].get(f"path2|{f}|{c}")
            row = [name.split(" (")[0] if first else "", CLS_NAMES.get(c, c),
                   pct(g(k2)), pct(g(k2, "pre")), pct(g(f"path0|FULL|{f}|{c}")), pct(g(f"path2|CONF|{f}|{c}")),
                   pct(g(f"path2|B1b|{f}|{c}")), pct(g(f"path2|B2|{f}|{c}")), "--" if n is None else str(n)]
            L.append(" & ".join(row) + r" \\")
            first = False
        L.append(r"\addlinespace[2pt]")
    L += [r"\bottomrule", r"\end{tabular}}", r"\end{table*}"]
    return "\n".join(L) + "\n"


def table_scope(S: dict, ctx: dict[str, Any], synthetic: bool) -> str:
    caption = (_prefix(synthetic) +
               f"Effect of the switch-scope mode on FULL (abstract model, mean over {ctx['n_seeds']} seeds).")
    L = [r"\begin{table}[t]", r"\centering\small", f"\\caption{{{caption}}}", r"\label{tab:scope}",
         r"\begin{tabular}{lrrr}", r"\toprule", r"Metric (\%) & strict & path0 & path2 \\", r"\midrule"]
    L.append("Benign FPR, all intents & " + " & ".join(pct(_pair(S["fpr"], f"{m}|FULL")[0]) for m in MODES) + r" \\")
    for t in ("bandwidth", "waypoint"):
        L.append(f"Benign FPR, {t} intents & " +
                 " & ".join(pct(S["fpr_by_type"].get(f"{m}|FULL|{t}", 0.0 if f"{m}|FULL" in S["fpr"] else None))
                           for m in MODES) + r" \\")
    L.append("Detection, insider path via x1 & " +
             " & ".join(pct(_pair(S["dr_class"], f"{m}|FULL|insider|hijack", "dr")[0]) for m in MODES) + r" \\")
    L.append("Detection, all excl.\\ within-intent & " +
             " & ".join(pct(_pair(S["dr_overall_excl_within"], f"{m}|FULL")[0]) for m in MODES) + r" \\")
    L += [r"\bottomrule", r"\end{tabular}", r"\end{table}"]
    return "\n".join(L) + "\n"


def table_overhead(O: dict, ctx: dict[str, Any], synthetic: bool) -> str:
    cv, mk, ci, bs = O["chain_verify"], O["merkle"], O["conformance_per_intent"], O["bundle_sizes"]
    caption = (_prefix(synthetic) + "Cost of binding and checking in the Python reference implementation (median, "
               f"95th percentile in parentheses; single core of {ctx['hardware']}).")
    hi = f"hops={ctx.get('max_hops', 8)}"
    L = [r"\begin{table}[t]", r"\centering\small", f"\\caption{{{caption}}}",
         r"\label{tab:overhead}", r"\resizebox{\columnwidth}{!}{%", r"\begin{tabular}{lr}", r"\toprule",
         r"Operation & Cost \\", r"\midrule",
         f"Sign one hop token & {O['sign_hop']['median_us']:.0f}\\,\\textmu s ({O['sign_hop']['p95_us']:.0f}) \\\\",
         f"Verify one hop token & {O['verify_hop']['median_us']:.0f}\\,\\textmu s "
         f"({O['verify_hop']['p95_us']:.0f}) \\\\",
         f"Verify chain, 3 hops & {cv['bandwidth/hops=3']['median_us']/1000:.2f}\\,ms "
         f"({cv['bandwidth/hops=3']['p95_us']/1000:.2f}) \\\\",
         f"Verify chain, {ctx.get('max_hops', 8)} hops & {cv[f'bandwidth/{hi}']['median_us']/1000:.2f}\\,ms "
         f"({cv[f'bandwidth/{hi}']['p95_us']/1000:.2f}) \\\\",
         f"Merkle proof check, 64 commands & {mk['64']['verify']['median_us']:.1f}\\,\\textmu s "
         f"({mk['64']['verify']['p95_us']:.1f}) \\\\",
         f"Conformance, whole bandwidth intent & {ci['bandwidth']['median_us']:.0f}\\,\\textmu s "
         f"({ci['bandwidth']['p95_us']:.0f}) \\\\",
         f"Conformance, whole block intent (4 cmds) & {ci['block']['median_us']:.0f}\\,\\textmu s "
         f"({ci['block']['p95_us']:.0f}) \\\\",
         r"\midrule",
         f"Root token / hop token / certificate & {bs['hops=3']['root']} / "
         f"{O['bytes_per_hop']['hop_token_mean']:.0f} / "
         f"{O['bytes_per_hop']['cert_mean']:.0f}\\,B \\\\",
         f"Binding bytes per intent, 3 / {ctx.get('max_hops', 8)} hops & "
         f"{(bs['hops=3']['root'] + bs['hops=3']['hop_tokens'] + bs['hops=3']['certs']) / 1000:.1f} / "
         f"{(bs[hi]['root'] + bs[hi]['hop_tokens'] + bs[hi]['certs']) / 1000:.1f}\\,kB \\\\",
         f"Merkle proof per command, 64 commands & {mk['64']['proof_bytes_json']}\\,B "
         f"({mk['64']['proof_hashes']} hashes) \\\\",
         r"\bottomrule", r"\end{tabular}}", r"\end{table}"]
    return "\n".join(L) + "\n"


def table_testbed(T: dict, synthetic: bool) -> str:
    ben = T["benign"]
    caption = (_prefix(synthetic) +
               "Emulated data plane (Mininet, Open vSwitch userspace datapath, OpenFlow 1.3): benign intents. "
               "Agreement compares the checker's effect-model prediction with ICMP/TCP probes and waypoint counters. "
               "Times are per intent, medians.")
    L = [r"\begin{table}[t]", r"\centering\small", f"\\caption{{{caption}}}",
         r"\label{tab:testbed}", r"\resizebox{\columnwidth}{!}{%", r"\begin{tabular}{lrrrrr}", r"\toprule",
         r"Intent type & $n$ & Agree & Chain+check (ms) & Install (ms) & Ratio \\", r"\midrule"]
    for t in ("isolate", "block", "bandwidth", "waypoint"):
        R = [r for r in ben if r["type"] == t]
        if not R:
            continue
        ag = sum(p["model"] == p["measured"] for r in R for p in r["probes"])
        tot = sum(len(r["probes"]) for r in R)
        cc = statistics.median(r["t_chain_ms"] + r["t_check_ms"] for r in R)
        ins = statistics.median(r["t_install_ms"] for r in R)
        L.append(f"{t} & {len(R)} & {ag}/{tot} & {cc:.1f} & {ins:.1f} & {cc / ins:.2f} \\\\")
    ctrl = T.get("control", [])
    if ctrl:
        L.append(r"\midrule")
        L.append(f"Positive control (no intent) & -- & {sum(p['model'] == p['measured'] for p in ctrl)}/{len(ctrl)} "
                 "& -- & -- & -- \\\\")
    L += [r"\bottomrule", r"\end{tabular}}", r"\end{table}"]
    return "\n".join(L) + "\n"


def write_tables(out_dir: str | Path, *, summary: dict | None = None, overhead: dict | None = None,
                 testbed: dict | None = None, context: dict[str, Any], synthetic: bool) -> list[Path]:
    """Write every table whose inputs are available; return the written paths."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written = []

    def put(name: str, text: str) -> None:
        p = out / name
        p.write_text(text)
        written.append(p)

    if summary is not None:
        put("tab_results_path2.tex", table_results(summary, "path2", context, synthetic))
        put("tab_perclass.tex", table_perclass(summary, context, synthetic))
        put("tab_scope.tex", table_scope(summary, context, synthetic))
    if overhead is not None:
        put("tab_overhead.tex", table_overhead(overhead, context, synthetic))
    if testbed is not None:
        put("tab_testbed.tex", table_testbed(testbed, synthetic))
    return written
