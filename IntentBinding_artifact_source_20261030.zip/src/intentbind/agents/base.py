"""Agent policy interface (paper Sec. 3, "System"; Sec. 8, LLM agents not yet evaluated).

A pipeline is parser -> refiner* -> planner -> executor. The binding protocol and the checker do
not depend on how agents reason; they only see what each hop emits. ``AgentPolicy`` is the seam where
an LLM agent (e.g. a LangGraph node calling tools over MCP) replaces the scripted policy.

Contract (all artefacts must be canonical-JSON-serialisable: dict/list/str/int/bool/None, no floats):
  parse(intent)        -> task  {"iid", "type", "spec"}
  refine(task, k)      -> task  (k = 1-based refiner index)
  plan(task, rng)      -> list of command dicts (see docs/data_format.md, "Command")
"""
from __future__ import annotations

import copy
import random
from typing import Protocol, runtime_checkable

from ..network.model import Topology
from .scripted import plan_with_extras


@runtime_checkable
class AgentPolicy(Protocol):
    def parse(self, intent: dict) -> dict: ...

    def refine(self, task: dict, k: int) -> dict: ...

    def plan(self, task: dict, rng: random.Random) -> list[dict]: ...


class ScriptedPolicy:
    """The deterministic agents used for every result in the paper (Sec. 7.3)."""

    def __init__(self, topo: Topology, detour_p: float = 0.2):
        if not 0.0 <= detour_p <= 1.0:
            raise ValueError("detour_p must be in [0, 1]")
        self.topo = topo
        self.detour_p = detour_p

    def parse(self, intent: dict) -> dict:
        return {"iid": intent["iid"], "type": intent["type"], "spec": copy.deepcopy(intent["spec"])}

    def refine(self, task: dict, k: int) -> dict:
        return task

    def plan(self, task: dict, rng: random.Random) -> list[dict]:
        return plan_with_extras(self.topo, task, rng, self.detour_p)
