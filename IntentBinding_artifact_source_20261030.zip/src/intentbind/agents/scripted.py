"""Deterministic scripted agents (paper Sec. 7.3, "Intents and agents").

The planner varies benign plans: it picks a random shortest path, takes a detour of up to two extra
hops with probability ``detour_p`` (0.2 in the paper), draws rates uniformly within the bounds, and adds
a read-statistics call with probability 0.3 for isolation intents. Parser and refiners pass the task
through unchanged unless an attack hook alters it.

Internal spec flags written only by drift attacks: ``_dropped`` (a sub-goal is lost), ``_extra``
(additional isolation targets), ``_reverse`` (reverse direction added).
"""
from __future__ import annotations

import random

from ..intents.compiler import _waypoint_paths
from ..network.model import Topology


def plan_cmds(topo: Topology, task: dict, rng: random.Random, detour_p: float = 0.2) -> list[dict]:
    t, s = task["type"], task["spec"]
    E = topo.edge_of
    if t == "isolate":
        cmds = [] if s.get("_dropped") else [{"op": "isolate", "host": s["host"], "switch": E[s["host"]]}]
        if rng.random() < 0.3 or not cmds:
            cmds.append({"op": "read_stats", "switch": E[s["host"]]})
        return cmds
    if t == "block":
        srcs = s["srcs"][:-1] if s.get("_dropped") else s["srcs"]
        return [{"op": "block", "src": x, "dst": s["dst"], "port": s["port"], "switch": E[s["dst"]]} for x in srcs]
    if t in ("bandwidth", "waypoint"):
        a, b = s["src"], s["dst"]
        if t == "waypoint" and not s.get("_dropped"):
            P0 = _waypoint_paths(topo, a, b, s["via"], 0)
            P2 = [p for p in _waypoint_paths(topo, a, b, s["via"], 2) if p not in P0]
        else:
            P0 = [tuple(p) for p in topo.host_paths(a, b, 0)]
            P2 = [tuple(p) for p in topo.host_paths(a, b, 2) if tuple(p) not in P0]
        path = rng.choice(P2) if (P2 and rng.random() < detour_p) else rng.choice(P0)
        cmds = [{"op": "route", "src": a, "dst": b, "path": list(path)}]
        if t == "bandwidth" and not s.get("_dropped"):
            rate = rng.randrange(s["min"], s["max"] + 1, 10)
            cmds.append({"op": "set_bw", "src": a, "dst": b, "rate": rate, "switch": E[a]})
        return cmds
    if t == "slice":
        rate = rng.randrange(s["min"], s["max"] + 1, 10)
        ues = s["ues"][:-1] if s.get("_dropped") else s["ues"]
        return [{"op": "create_slice", "slice": s["slice"], "rate": rate}] + \
               [{"op": "assign_ue", "ue": u, "slice": s["slice"]} for u in ues]
    raise ValueError(f"unknown intent type {t!r}")


def plan_with_extras(topo: Topology, task: dict, rng: random.Random, detour_p: float) -> list[dict]:
    """Scripted planner including the effects of drifted task flags."""
    cmds = plan_cmds(topo, task, rng, detour_p)
    s = task["spec"]
    for x in s.get("_extra", []):
        cmds.append({"op": "isolate", "host": x, "switch": topo.edge_of[x]})
    if s.get("_reverse"):
        rev = dict(task, spec=dict(s, src=s["dst"], dst=s["src"], _reverse=False))
        cmds += plan_cmds(topo, rev, rng, detour_p)
    return cmds
