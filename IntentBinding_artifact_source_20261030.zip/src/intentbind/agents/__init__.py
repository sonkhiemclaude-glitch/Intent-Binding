"""Agent policies: scripted agents of the paper (Sec. 7.3) and an LLM adapter stub."""
