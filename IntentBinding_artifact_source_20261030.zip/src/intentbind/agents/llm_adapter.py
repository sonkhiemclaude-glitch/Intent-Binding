"""LLM agent adapter stub (paper Sec. 8: "LLM agents were not evaluated"; experiment plan E1-E6).

NOT IMPLEMENTED. This module defines where an LLM-based parser/refiner/planner plugs in. It makes no
network calls and names no model or vendor API. To implement it on the Mac Studio:

1. Choose the model(s) and access route (local model server or hosted API). Record model identifiers,
   versions and access dates in the run config (``agents.llm.*``) for the paper's Methods section.
2. Implement ``plan()`` so it returns a list of command dicts that pass
   ``intentbind.data.schemas.validate_command``; reject or log anything else.
3. Keep prompts and decoding settings in versioned files referenced from the config.
4. Never let the LLM produce or alter the constraint set Phi_I at runtime: Phi_I is compiled before
   signing and is part of the operator-signed intent (paper Sec. 4).

See TODO_IMPLEMENTATION.md (T-LLM-1..3) and docs/mac_studio_experiment_guide.md.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field

from ..errors import ExternalDependencyMissing


@dataclass
class LLMAgentConfig:
    """Fields the adapter will need; values come from the experiment config, never from code defaults."""

    model_id: str = ""
    endpoint_env_var: str = ""  # name of an environment variable holding the endpoint; never the secret itself
    temperature: int = 0  # stored as an integer per-mille value to keep configs float-free (0 = greedy)
    prompt_dir: str = ""
    extra: dict = field(default_factory=dict)


class LLMAgentPolicy:
    """Placeholder implementing the ``AgentPolicy`` signature. Every method raises until implemented."""

    def __init__(self, config: LLMAgentConfig):
        self.config = config

    def _missing(self) -> ExternalDependencyMissing:
        return ExternalDependencyMissing(
            "LLMAgentPolicy is a stub: no LLM agent is implemented in this repository. "
            "Implement intentbind/agents/llm_adapter.py on the experiment host (see TODO_IMPLEMENTATION.md, T-LLM-1).")

    def parse(self, intent: dict) -> dict:
        raise self._missing()

    def refine(self, task: dict, k: int) -> dict:
        raise self._missing()

    def plan(self, task: dict, rng: random.Random) -> list[dict]:
        raise self._missing()
