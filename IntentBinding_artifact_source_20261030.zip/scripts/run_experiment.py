#!/usr/bin/env python3
"""Run one stage (or all) of an experiment config.

Examples
  python scripts/run_experiment.py --config configs/experiment_template.yaml --stage component
  python scripts/run_experiment.py --config configs/default.yaml --stage all      # Mac Studio only
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))  # run from a checkout without installation

from intentbind.cli import main  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", required=True)
    ap.add_argument("--stage", default="all",
                    choices=["component", "aggregate", "miss-audit", "overhead", "tables", "figures", "all"])
    ap.add_argument("--out", default=None)
    ap.add_argument("--set", action="append", default=[], metavar="KEY=VALUE")
    a = ap.parse_args()
    argv = ["run", "--config", a.config, "--stage", a.stage] + (["--out", a.out] if a.out else [])
    for s in a.set:
        argv += ["--set", s]
    raise SystemExit(main(argv))
