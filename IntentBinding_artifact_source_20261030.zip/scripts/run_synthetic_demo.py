#!/usr/bin/env python3
"""Synthetic smoke test of every stage (component, aggregate, miss audit, overhead, tables, figures).

Output: outputs/synthetic_demo/ (default). Every file is labelled
"synthetic smoke-test output, not a paper result". Runs in well under a minute on a laptop.
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))  # run from a checkout without installation

from intentbind.cli import main  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", default=str(ROOT / "configs" / "synthetic_demo.yaml"))
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    argv = ["demo", "--config", a.config] + (["--out", a.out] if a.out else [])
    raise SystemExit(main(argv))
