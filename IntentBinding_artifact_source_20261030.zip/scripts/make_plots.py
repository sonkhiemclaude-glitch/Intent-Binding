#!/usr/bin/env python3
"""Draw figures from existing result files (summary.json, overhead.json) in a results folder.

The label (synthetic or not) comes from the config; synthetic figures carry a visible watermark.
  python scripts/make_plots.py --results outputs/synthetic_demo --config configs/synthetic_demo.yaml
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))  # run from a checkout without installation

from intentbind.experiments.stages import stage_figures  # noqa: E402
from intentbind.utils.config import load_config  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--results", required=True)
    ap.add_argument("--config", required=True)
    a = ap.parse_args()
    for p in stage_figures(load_config(a.config), Path(a.results)):
        print(p)
