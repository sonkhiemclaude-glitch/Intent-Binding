#!/usr/bin/env python3
"""Write LaTeX tables from existing result files in a results folder.

  python scripts/make_tables.py --results outputs/paper_run --config configs/default.yaml

To regenerate the manuscript tables from the archived run (byte-identical to the manuscript):
  python scripts/make_tables.py --archive paper_results/2026-10-18_cloud_vm --out outputs/archive_tables
"""
import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))  # run from a checkout without installation

from intentbind.experiments.stages import stage_tables  # noqa: E402
from intentbind.experiments.tables import write_tables  # noqa: E402
from intentbind.utils.config import load_config  # noqa: E402
from intentbind.utils.io import read_json  # noqa: E402

#: Run facts of the archived 2026-10-18 run as printed in the manuscript captions (not results).
ARCHIVE_CONTEXT = {"n_seeds": 10, "intents_per_seed": 200, "hardware": r"a 2-vCPU Intel Xeon 2.1\,GHz cloud VM",
                   "max_hops": 8}

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--results")
    ap.add_argument("--config")
    ap.add_argument("--archive")
    ap.add_argument("--out", default="outputs/archive_tables")
    a = ap.parse_args()
    if a.archive:
        d = Path(a.archive)
        paths = write_tables(a.out, summary=read_json(d / "summary.json"), overhead=read_json(d / "overhead.json"),
                             testbed=read_json(d / "testbed.json"), context=ARCHIVE_CONTEXT, synthetic=False)
    else:
        if not (a.results and a.config):
            ap.error("--results and --config are required unless --archive is given")
        paths = stage_tables(load_config(a.config), Path(a.results))
    for p in paths:
        print(p)
