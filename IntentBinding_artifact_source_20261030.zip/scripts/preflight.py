#!/usr/bin/env python3
"""Check an experiment host and snapshot source/dependencies without running experiments.

Run with the environment's interpreter, e.g. .venv/bin/python scripts/preflight.py.
The optional testbed gate is for Linux VMs: --require-testbed.
"""
from __future__ import annotations

import argparse
import json
import sys
from importlib import metadata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from intentbind.controllers.mininet_ovs import check_environment  # noqa: E402
from intentbind.errors import ExternalDependencyMissing  # noqa: E402
from intentbind.experiments.overhead import cpu_model  # noqa: E402
from intentbind.utils.config import load_config  # noqa: E402
from intentbind.utils.io import write_json  # noqa: E402
from intentbind.utils.provenance import environment, sha256_file, verify_manifest  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--config", type=Path, default=ROOT / "configs/default.yaml")
    ap.add_argument("--out", type=Path, default=ROOT / "preparation/latest")
    ap.add_argument("--require-testbed", action="store_true")
    a = ap.parse_args()
    cfg = load_config(a.config)
    if a.out.exists():
        ap.error(f"output already exists: {a.out}; use a fresh directory")
    problems = verify_manifest(ROOT / "paper_results/2026-10-18_cloud_vm")
    versions = environment()
    problems += [f"missing library: {p}" for p, v in versions["libraries"].items() if v is None]
    dataset = None
    if cfg.intents.source == "file":
        from intentbind.data.intent_sets import load_intent_file
        from intentbind.network.model import Topology
        records = load_intent_file(cfg.intents.path, Topology())
        dataset = {"path": cfg.intents.path, "sha256": sha256_file(cfg.intents.path), "records": len(records)}
    try:
        check_environment()
        testbed = {"ready": True, "reason": "Mininet/OVS dependencies available"}
    except ExternalDependencyMissing as e:
        testbed = {"ready": False, "reason": str(e)}
        if a.require_testbed:
            problems.append(str(e))
    source_files = sorted(p for folder in ("src", "configs", "scripts", "tests")
                          for p in (ROOT / folder).rglob("*") if p.suffix in (".py", ".sh", ".yaml"))
    source_files += [ROOT / name for name in ("pyproject.toml", "requirements.txt", "Makefile")]
    manifest = {str(p.relative_to(ROOT)): sha256_file(p) for p in source_files}
    pdf = ROOT.parent / "targets/compcom_vsi_intent/manuscript/main.pdf"
    report = {"config": cfg.to_dict(), "environment": versions, "cpu": cpu_model(),
              "component_ready": not problems, "problems": problems, "testbed": testbed,
              "input_dataset": dataset, "config_sha256": sha256_file(a.config),
              "manuscript_sha256": sha256_file(pdf) if pdf.exists() else None,
              "source_sha256": manifest, "n_component_jobs": len(cfg.seeds) * len(cfg.scope_modes),
              "external_evaluation": "LLM, ONOS, Open5GS, MCP, external datasets/baselines require implementation"}
    write_json(a.out / "preflight.json", report)
    freeze = sorted({f"{d.metadata['Name']}=={d.version}" for d in metadata.distributions()
                     if d.metadata['Name'].lower() != "intentbind"}, key=str.lower)
    (a.out / "environment.freeze.txt").write_text("\n".join(freeze) + "\n")
    (a.out / "source.MANIFEST.sha256").write_text("".join(f"{v}  {k}\n" for k, v in manifest.items()))
    snapshot = a.out / "source_snapshot.tar.gz"
    import tarfile
    with tarfile.open(snapshot, "w:gz") as archive:
        for p in source_files:
            archive.add(p, arcname=str(p.relative_to(ROOT)))
    # No API keys, shell environment, SSH settings or private keys are collected.
    print(json.dumps({"component_ready": not problems, "testbed": testbed, "report": str(a.out)}, indent=2))
    return 1 if problems else 0


if __name__ == "__main__":
    raise SystemExit(main())
