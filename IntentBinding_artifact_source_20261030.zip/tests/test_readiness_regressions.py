"""Regressions for failures found while preparing the Mac Studio experiments."""
import copy
import json
import random

import pandas as pd
import pytest

from intentbind.binding.merkle import merkle_verify
from intentbind.conformance.checker import Checker
from intentbind.conformance.ltlf import formula, holds, positions
from intentbind.crypto import JWSError, b64u, jws_parse
from intentbind.experiments.component import run_job
from intentbind.experiments.miss_audit import run_miss_audit
from intentbind.intents.generator import make_intent
from intentbind.metrics.aggregate import summarise
from intentbind.metrics.episode import FIELDS
from intentbind.network import model as nm
from intentbind.pipeline.episode import benign_episode
from intentbind.utils.config import config_from_dict


@pytest.mark.parametrize("part", ["header", "payload"])
def test_non_object_jws_is_rejected(part):
    header = b"[]" if part == "header" else b'{"alg":"EdDSA"}'
    payload = b"null" if part == "payload" else b"{}"
    token = ".".join([b64u(header), b64u(payload), b64u(b"x" * 64)])
    with pytest.raises(JWSError):
        jws_parse(token)


def test_empty_certificate_list_returns_rejection(world):
    it = make_intent(world.topo, random.Random(1), "isolate", 1, "path2")
    ep = benign_episode(world, it, 1)
    b = copy.deepcopy(ep.bundle)
    b.certs = []
    result = world.verifier("sdn").verify_command(b, 0, ep.cmds[0], ep.proofs[0])
    assert not result.ok and result.cause == "CHAIN_SHAPE"


@pytest.mark.parametrize("proof", [None, [["R", "not-hex"]], [["R", "00"]], [["bad", "00" * 32]], [["R"]]])
def test_malformed_proof_is_rejected_without_exception(world, proof):
    it = make_intent(world.topo, random.Random(1), "block", 1, "path2")
    ep = benign_episode(world, it, 1)
    result = world.verifier("sdn").verify_command(ep.bundle, 0, ep.cmds[0], proof)
    assert not result.ok and result.cause == "CMD_NOT_COMMITTED"


@pytest.mark.parametrize("index", [True, -1, 2**64, "0", 0.5])
def test_merkle_rejects_invalid_indices(index):
    assert not merkle_verify({"op": "read_stats"}, index, [], "0" * 64)


def test_boolean_bound_agrees_with_ltlf(world):
    # bool is an int subclass in Python, but is not a numerical rate.
    c = {"id": "phi0", "t": "bound", "op": "set_slice_qos", "param": "rate", "lo": 0, "hi": 1}
    cmd = {"op": "set_slice_qos", "slice": "s-default", "rate": True}
    s0 = nm.initial_state(world.topo)
    allowed, violations = Checker(world.topo, [c], s0).step(cmd)
    assert not allowed and violations[0][2] == "BOUND"
    assert not holds(formula(world.topo, c), positions(world.topo, s0, [cmd]))


def test_aggregate_without_full_supports_ablation():
    cfg = config_from_dict({"seeds": [1], "intents_per_seed": 1, "scope_modes": ["path2"],
                            "defenses": ["B0"], "attack_families": ["forgery"]})
    df = pd.DataFrame(run_job(1, "path2", cfg), columns=FIELDS)
    summary = summarise(df)
    assert summary["share_chain_families_excl_within"]["path2"] == 1.0
    assert summary["n_effective"]["path2|forgery|unsigned"] == 1
    assert summary["dr_overall_all"]["path2|B0"][0] == 0.0


def test_file_miss_audit_matches_component_workload(tmp_path):
    path = tmp_path / "intents.jsonl"
    path.write_text("\n".join(json.dumps({"iid": f"FILE-{k}", "type": "isolate", "spec": {"host": h}})
                              for k, h in enumerate(["h1", "h2"])) + "\n")
    # Deliberately different from the file length: generator fallback must be visible.
    cfg = config_from_dict({"seeds": [1], "intents_per_seed": 5, "scope_modes": ["path2"],
                            "defenses": ["FULL"], "attack_families": ["injection"],
                            "intents": {"source": "file", "path": str(path)}})
    df = pd.DataFrame(run_job(1, "path2", cfg), columns=FIELDS)
    misses = df[(df.family != "benign") & (df.effective == 1) & (df.detected == 0)]
    expected = {f"{m}|{f}|{c}": {"conformant_miss": len(g)}
                for (m, f, c), g in misses.groupby(["mode", "family", "cls"])}
    assert len(misses) == 2
    assert json.loads(run_miss_audit(cfg, tmp_path / "audit").read_text()) == expected
