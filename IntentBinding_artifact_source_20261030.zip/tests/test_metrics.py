import math

import pandas as pd
import pytest

from intentbind.metrics.aggregate import summarise
from intentbind.metrics.episode import FIELDS, attack_row, benign_row
from intentbind.metrics.stats import mean_t_interval, safe_rate


def test_t_interval_known_value():
    m, hw = mean_t_interval([1.0, 2.0, 3.0, 4.0, 5.0])
    assert m == 3.0
    # t_{0.975,4} = 2.776445; s = sqrt(2.5); hw = t * s / sqrt(5)
    assert hw == pytest.approx(2.776445105 * math.sqrt(2.5) / math.sqrt(5), rel=1e-6)


def test_t_interval_edge_cases():
    m, hw = mean_t_interval([])
    assert math.isnan(m) and math.isnan(hw)
    assert mean_t_interval([0.7]) == (0.7, 0.0)
    assert mean_t_interval([0.5, 0.5, 0.5]) == (0.5, 0.0)


def test_safe_rate():
    assert safe_rate(1, 4) == 0.25
    assert math.isnan(safe_rate(0, 0))


class _Ep:
    family, cls = "injection", "mirror"
    cmds = [{"op": "a"}, {"op": "b"}]
    benign_cmds = [{"op": "a"}]


def test_attack_row_detection_rules():
    ep = _Ep()
    clean = {"flags": []}
    post = {"flags": [(None, "post", "GOAL")]}
    r = attack_row(1, "path2", "isolate", 0, ep, "FULL", {"flags": [(1, "pre", "OPSET")]}, clean)
    assert (r.detected, r.pre_detected, r.post_only, r.first_cause, r.benign_flagged) == (1, 1, 0, "OPSET", 0)
    r = attack_row(1, "path2", "isolate", 0, ep, "FULL", {"flags": [(0, "pre", "SCOPE")]}, clean)
    assert (r.detected, r.benign_flagged) == (0, 1)  # blocking a benign command is not detection
    r = attack_row(1, "path2", "isolate", 0, ep, "B1b", post, clean)
    assert (r.detected, r.post_only) == (1, 1)
    r = attack_row(1, "path2", "isolate", 0, ep, "B1b", post, post)
    assert r.detected == 0  # the paired benign run raises the same post flag


def _rows():
    rows = []
    for seed in (1, 2):
        for d in ("B0", "FULL"):
            rows.append(benign_row(seed, "path2", "isolate", 0, d, {"flags": [] if d == "B0" or seed == 1 else
                                                                      [(0, "pre", "X")]}).as_list())
            for det in (0, 1):
                ep = _Ep()
                res = {"flags": [(1, "pre", "OPSET")]} if (d == "FULL" and (det or seed == 1)) else {"flags": []}
                rows.append(attack_row(seed, "path2", "isolate", 0, ep, d, res, {"flags": []}).as_list())
    return pd.DataFrame(rows, columns=FIELDS)


def test_summarise_on_controlled_rows():
    S = summarise(_rows())
    assert S["fpr"]["path2|B0"] == (0.0, 0.0)
    assert S["fpr"]["path2|FULL"][0] == 0.5
    assert S["dr_family"]["path2|FULL|injection"]["dr"][0] == 0.75  # seed1: 2/2, seed2: 1/2
    assert S["dr_family"]["path2|B0|injection"]["dr"] == (0.0, 0.0)
    assert S["n_effective"]["path2|injection|mirror"] == 4
    assert S["n_benign_episodes_per_mode"] == 2


def test_summarise_rejects_missing_columns():
    with pytest.raises(ValueError):
        summarise(pd.DataFrame({"seed": [1]}))


def test_equal_within_tolerance():
    from intentbind.utils.compare import differing_keys, equal_within
    assert equal_within({"a": [0.9867246775594827, 1]}, {"a": [0.9867246775594829, 1]})
    assert not equal_within({"a": [0.5]}, {"a": [0.5001]})
    assert not equal_within({"a": 1}, {"b": 1})
    assert differing_keys({"x": 1.0, "y": 2}, {"x": 1.0, "y": 3}) == ["y"]
