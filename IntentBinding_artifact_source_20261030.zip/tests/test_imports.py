import importlib
import pkgutil

import intentbind


def test_every_module_imports():
    names = [m.name for m in pkgutil.walk_packages(intentbind.__path__, "intentbind.")]
    assert len(names) > 40
    for n in names:
        if n == "intentbind.__main__":
            continue
        importlib.import_module(n)


def test_version():
    assert intentbind.__version__ == "1.0.0"


def test_mininet_not_imported_at_module_load():
    import sys

    importlib.import_module("intentbind.controllers.mininet_ovs")
    importlib.import_module("intentbind.controllers.testbed")
    assert "mininet" not in sys.modules or sys.modules["mininet"] is not None  # lazy: no import error
