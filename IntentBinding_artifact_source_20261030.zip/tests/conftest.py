import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from intentbind.pipeline.world import World  # noqa: E402

FIXTURES = ROOT / "tests" / "fixtures"
ARCHIVE = ROOT / "paper_results" / "2026-10-18_cloud_vm"


@pytest.fixture(scope="session")
def world():
    return World.build(key_seed=b"tests")


@pytest.fixture(scope="session")
def world_random_keys():
    return World.build()
