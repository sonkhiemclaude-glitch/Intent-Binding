import random

import pytest

from intentbind.attacks.catalogue import (
    ATTACKS,
    CHAIN_FAMILIES,
    FAMILIES,
    KEYHOLDER_FAMILIES,
    WITHIN_INTENT,
    all_classes,
)
from intentbind.attacks.episodes import attack_episode
from intentbind.baselines import BASELINES
from intentbind.baselines.dummy import allow_all, block_all
from intentbind.defenses.runner import DEFENSES, guardrail_flags, run_defense
from intentbind.intents.generator import make_intent
from intentbind.metrics.attribution import is_effective
from intentbind.metrics.episode import attack_row
from intentbind.pipeline.episode import benign_episode


def test_catalogue_matches_table3():
    assert len(all_classes()) == 34
    assert len(ATTACKS) == 7 and set(FAMILIES) == set(ATTACKS)
    assert CHAIN_FAMILIES | KEYHOLDER_FAMILIES == set(ATTACKS) and not CHAIN_FAMILIES & KEYHOLDER_FAMILIES
    assert all(c in ATTACKS[f] for f, c in WITHIN_INTENT)


def test_defences_registry():
    assert DEFENSES == ("B0", "B1a", "B1b", "B2", "BIND", "ROOTCONF", "CONF", "FULL")
    assert all(BASELINES[d].kind == "implemented" for d in DEFENSES)
    with pytest.raises(ValueError):
        run_defense(None, None, "NOPE")  # type: ignore[arg-type]


def test_conformance_misses_forgery_binding_misses_insider(world):
    it = make_intent(world.topo, random.Random(8), "bandwidth", 1, "path2")
    ep = attack_episode(world, it, 1, "forgery", "body_modified")
    assert run_defense(world, ep, "CONF")["flags"] == []
    assert run_defense(world, ep, "BIND")["flags"]
    ep = attack_episode(world, it, 1, "insider", "relax")
    assert run_defense(world, ep, "BIND")["flags"] == []
    assert run_defense(world, ep, "CONF")["flags"]


def test_rootconf_catches_body_modified_but_not_command_injection(world):
    """ROOT+CONF signs (I, Phi_I) but has no hop tokens or command commitment (Table 4)."""
    it = make_intent(world.topo, random.Random(8), "bandwidth", 1, "path2")
    assert run_defense(world, attack_episode(world, it, 1, "forgery", "body_modified"), "ROOTCONF")["flags"]
    ep = attack_episode(world, it, 1, "exec_tamper", "reorder")
    assert not any(f[2] == "CMD_ORDER" for f in run_defense(world, ep, "ROOTCONF")["flags"])


def test_b0_never_flags_and_executes_everything(world):
    it = make_intent(world.topo, random.Random(2), "isolate", 1, "path2")
    ep = attack_episode(world, it, 1, "injection", "infra_isolate")
    r = run_defense(world, ep, "B0")
    assert r["flags"] == [] and r["executed"] == list(range(len(ep.cmds)))


def test_guardrail_rules():
    assert guardrail_flags({"op": "delete_flows", "switch": "a11"}) == ["G_WIPE"]
    assert guardrail_flags({"op": "isolate", "host": "gw", "switch": "b1"}) == ["G_INFRA"]
    assert guardrail_flags({"op": "mirror", "src": "h1", "collector": "atk", "switch": "a11"}) == ["G_MIRROR"]
    assert guardrail_flags({"op": "isolate", "host": "h1", "switch": "a11"}) == []


def test_dummy_baselines_bound_detection(world):
    it = make_intent(world.topo, random.Random(3), "isolate", 1, "path2")
    ben = benign_episode(world, it, 1)
    ep = attack_episode(world, it, 1, "injection", "infra_isolate")
    assert is_effective(ep)
    nobody = attack_row(1, "path2", "isolate", 0, ep, "x", allow_all(world, ep), allow_all(world, ben))
    everyone = attack_row(1, "path2", "isolate", 0, ep, "x", block_all(world, ep), allow_all(world, ben))
    assert nobody.detected == 0 and everyone.detected == 1 and everyone.pre_detected == 1
    assert everyone.benign_flagged == len(ep.cmds) - 1  # one command is attack-caused


def test_drift_requires_a_refiner(world):
    it = make_intent(world.topo, random.Random(4), "bandwidth", 1, "path2")
    ep = attack_episode(world, it, 1, "drift", "relax", n_refiners=1)
    assert ep.family == "drift"
