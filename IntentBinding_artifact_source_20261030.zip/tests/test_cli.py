import json
import subprocess
import sys

import pytest

from intentbind.cli import main

from conftest import ROOT

SYN = str(ROOT / "configs" / "synthetic_demo.yaml")


def test_list_commands(capsys):
    assert main(["attacks"]) == 0
    assert "total classes: 34" in capsys.readouterr().out
    assert main(["baselines"]) == 0
    assert "adapter_stub" in capsys.readouterr().out
    assert main(["adapters"]) == 0
    assert "missing" in capsys.readouterr().out


def test_validate_intents(capsys):
    assert main(["validate-intents", str(ROOT / "examples" / "synthetic_data" / "smoke_intents.jsonl")]) == 0
    assert "10 valid intent records" in capsys.readouterr().out


def test_demo_end_to_end(tmp_path, capsys):
    out = tmp_path / "demo"
    assert main(["demo", "--config", SYN, "--out", str(out), "--set", "intents_per_seed=3",
                 "--set", "seeds=[1]"]) == 0
    for f in ("component_episodes.csv.gz", "summary.json", "miss_audit.json", "overhead.json", "LABEL.txt",
              "tables/tab_results_path2.tex", "figures/fig_scope_tradeoff.pdf", "figures/fig_overhead.png"):
        assert (out / f).exists(), f
    assert "not a paper result" in (out / "LABEL.txt").read_text()
    assert "synthetic smoke-test output, not a paper result" in (out / "tables" / "tab_results_path2.tex").read_text()
    meta = json.loads((out / "run_metadata_component.json").read_text())
    assert meta["label"] == "synthetic smoke-test output, not a paper result"
    assert meta["outputs"]["component_episodes.csv.gz"]["sha256"]


def test_demo_refuses_non_synthetic_config(capsys):
    assert main(["demo", "--config", str(ROOT / "configs" / "default.yaml")]) == 2


def test_bad_config_key_is_rejected(tmp_path, capsys):
    p = tmp_path / "c.yaml"
    p.write_text("name: x\nlabel: custom\nshell: rm -rf /\n")
    assert main(["run", "--config", str(p), "--stage", "component"]) == 2
    assert "unknown config keys ['shell']" in capsys.readouterr().err


def test_testbed_check_only_reports_missing_dependencies(capsys):
    code = main(["testbed", "--config", str(ROOT / "configs" / "testbed_mininet.yaml"), "--check-only"])
    assert code in (0, 2)


def test_module_entry_point():
    r = subprocess.run([sys.executable, "-m", "intentbind", "--version"], capture_output=True, text=True,
                       cwd=ROOT / "src", check=False)
    assert r.returncode == 0 and "intentbind 1.0.0" in r.stdout


@pytest.mark.parametrize("cfg", ["default.yaml", "synthetic_demo.yaml", "experiment_template.yaml",
                                 "testbed_mininet.yaml", "overhead.yaml"])
def test_shipped_configs_validate(cfg):
    from intentbind.utils.config import load_config
    c = load_config(ROOT / "configs" / cfg)
    assert c.label in ("paper", "synthetic_smoke", "custom")


def test_paper_config_matches_paper_settings():
    from intentbind.utils.config import load_config
    c = load_config(ROOT / "configs" / "default.yaml")
    assert c.seeds == list(range(1, 11)) and c.intents_per_seed == 200
    assert c.scope_modes == ["strict", "path0", "path2"] and c.detour_p == 0.2
    assert c.overhead.reps_primitive == 3000 and c.overhead.max_hops == 8
