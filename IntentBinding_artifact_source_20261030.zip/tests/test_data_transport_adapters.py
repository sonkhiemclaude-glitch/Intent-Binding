import json
import random

import pytest

from intentbind.agents.llm_adapter import LLMAgentConfig, LLMAgentPolicy
from intentbind.baselines.external_wrappers import AgentSpecAdapter, NetInjectBenchGateAdapter
from intentbind.binding.transport import bundle_from_meta, command_from_meta, command_meta
from intentbind.controllers.mininet_ovs import check_environment
from intentbind.controllers.onos import ONOSAdapter
from intentbind.controllers.open5gs import Open5GSAdapter
from intentbind.controllers.probes import ip_of, model_pred, probes_for
from intentbind.data.adapters import ADAPTERS
from intentbind.data.intent_sets import compile_record, load_intent_file, paper_workload, write_intent_file
from intentbind.data.schemas import validate_command, validate_intent_record
from intentbind.errors import ExternalDependencyMissing, SchemaError
from intentbind.intents.generator import make_intent
from intentbind.intents.nl_compiler import parse_nl_intent
from intentbind.network import model as nm
from intentbind.pipeline.episode import benign_episode


def test_paper_workload_is_deterministic(world):
    a = paper_workload(world.topo, 3, 12, "path2")
    b = paper_workload(world.topo, 3, 12, "path2")
    assert json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True)
    assert [it["type"] for it, _ in a][:5] == ["isolate", "block", "bandwidth", "waypoint", "slice"]
    assert all(nr in (0, 1, 2) for _, nr in a)


def test_intent_file_roundtrip(tmp_path, world):
    its = [it for it, _ in paper_workload(world.topo, 1, 5, "path2")]
    p = write_intent_file(tmp_path / "i.jsonl", its)
    recs = load_intent_file(p, world.topo)
    assert [compile_record(world.topo, r, "path2")["constraints"] for r in recs] == [it["constraints"] for it in its]


def test_intent_file_rejects_bad_records(tmp_path, world):
    p = tmp_path / "bad.jsonl"
    p.write_text('{"iid": "x", "type": "isolate", "spec": {"host": "nohost"}}\n')
    with pytest.raises(SchemaError):
        load_intent_file(p, world.topo)
    p.write_text('{"iid": "x", "type": "bandwidth", "spec": {"src": "h1", "dst": "h2", "min": 1.5, "max": 3}}\n')
    with pytest.raises(SchemaError):
        load_intent_file(p, world.topo)
    rec = {"iid": "x", "type": "isolate", "spec": {"host": "h1"}}
    p.write_text(json.dumps(rec) + "\n" + json.dumps(rec) + "\n")
    with pytest.raises(ValueError):
        load_intent_file(p, world.topo)
    with pytest.raises(FileNotFoundError):
        load_intent_file(tmp_path / "missing.jsonl", world.topo)
    validate_intent_record(rec, world.topo)


def test_command_schema():
    validate_command({"op": "block", "src": "h1", "dst": "h2", "port": 22, "switch": "a11"})
    with pytest.raises(SchemaError):
        validate_command({"op": "set_bw", "src": "h1", "dst": "h2", "rate": 1.0, "switch": "a11"})
    with pytest.raises(SchemaError):
        validate_command({"op": "format_disk"})


def test_mcp_meta_roundtrip(world):
    it = make_intent(world.topo, random.Random(1), "block", 1, "path2")
    ep = benign_episode(world, it, 1)
    meta = command_meta(it["iid"], "E-1", 0, ep.proofs[0], include_bundle=ep.bundle)
    meta = json.loads(json.dumps(meta))  # survives JSON transport
    assert all(k.startswith("org.intentbind/") for k in meta)
    b = bundle_from_meta(meta)
    iid, eid, j, proof = command_from_meta(meta)
    assert (iid, eid, j) == (it["iid"], "E-1", 0)
    assert world.verifier("sdn").verify_command(b, j, ep.cmds[0], proof).ok
    with pytest.raises(SchemaError):
        command_from_meta({"org.intentbind/index": 0})


def test_external_adapters_raise(tmp_path):
    for cls in ADAPTERS.values():
        with pytest.raises(ExternalDependencyMissing):
            cls(None).to_intent_records()
        with pytest.raises(ExternalDependencyMissing):
            cls(tmp_path).to_intent_records()  # folder absent
    for cls in (ONOSAdapter, Open5GSAdapter):
        with pytest.raises(ExternalDependencyMissing):
            cls()
    for ad in (AgentSpecAdapter(), NetInjectBenchGateAdapter()):
        with pytest.raises(ExternalDependencyMissing):
            ad.run(None, None)
    with pytest.raises(ExternalDependencyMissing):
        LLMAgentPolicy(LLMAgentConfig()).plan({}, random.Random(0))
    with pytest.raises(ExternalDependencyMissing):
        parse_nl_intent("isolate h1")


def test_mininet_environment_check_is_explicit():
    try:
        check_environment()
    except ExternalDependencyMissing as e:
        assert "Mininet testbed unavailable" in str(e)


def test_probe_predictions_follow_effect_model():
    topo = nm.Topology(hosts_per_access=2)
    s0 = nm.initial_state(topo)
    h = topo.hosts[0]
    assert model_pred(topo, s0, ("icmp", h, "gw"))
    s1 = nm.apply(topo, s0, {"op": "isolate", "host": h, "switch": topo.edge_of[h]})
    assert not model_pred(topo, s1, ("icmp", h, "gw"))
    assert ip_of("gw") == "10.0.0.101" and ip_of("h7") == "10.0.0.7"
    it = make_intent(topo, random.Random(1), "isolate", 1, "path2")
    assert probes_for(topo, it, random.Random(1))
