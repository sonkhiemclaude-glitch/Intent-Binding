import random

from intentbind.attacks.catalogue import ATTACKS
from intentbind.attacks.episodes import attack_episode
from intentbind.binding import Bundle
from intentbind.crypto import jws_sign
from intentbind.defenses.runner import run_defense
from intentbind.errors import NotApplicable
from intentbind.intents.compiler import INTENT_TYPES
from intentbind.intents.generator import make_intent
from intentbind.metrics.attribution import affected
from intentbind.pipeline.episode import benign_episode


def test_benign_chain_always_verifies(world):
    for mode in ("strict", "path0", "path2"):
        rng = random.Random(3)
        for k in range(25):
            it = make_intent(world.topo, rng, INTENT_TYPES[k % 5], k, mode)
            for nr in (0, 1, 2):
                r = run_defense(world, benign_episode(world, it, k, nr), "BIND")
                assert r["flags"] == [], (mode, k, nr, r["flags"])


def test_chain_attacks_always_rejected_by_binding(world):
    rng = random.Random(5)
    for k in range(20):
        it = make_intent(world.topo, rng, INTENT_TYPES[k % 5], k, "path2")
        for fam in ("tamper_channel", "forgery", "cmd_injection", "exec_tamper"):
            for cls in ATTACKS[fam]:
                try:
                    ep = attack_episode(world, it, k, fam, cls)
                except NotApplicable:
                    continue
                aff = set(affected(ep))
                assert any(f[0] in aff for f in run_defense(world, ep, "BIND")["flags"]), (fam, cls, k)


def test_command_cannot_be_replayed_under_another_index(world):
    it = make_intent(world.topo, random.Random(9), "block", 1, "path2")
    ep = benign_episode(world, it, 1)
    ver = world.verifier("sdn")
    assert ver.verify_command(ep.bundle, 0, ep.cmds[0], ep.proofs[0]).ok
    assert ver.verify_command(ep.bundle, 0, ep.cmds[0], ep.proofs[0]).cause == "CMD_REPLAY"
    r = ver.verify_command(ep.bundle, 1, ep.cmds[0], ep.proofs[0])
    assert not r.ok and r.cause == "CMD_NOT_COMMITTED"


def test_expiry_rechecked_after_cache(world):
    it = make_intent(world.topo, random.Random(10), "block", 2, "path2")
    ep = benign_episode(world, it, 2)
    ver = world.verifier("sdn")
    assert ver.verify_command(ep.bundle, 0, ep.cmds[0], ep.proofs[0]).ok
    ver.now = 10**9
    r = ver.verify_command(ep.bundle, 1, ep.cmds[1], ep.proofs[1])
    assert not r.ok and r.cause == "INTENT_EXPIRED"


def test_same_eid_replan_is_replay(world):
    it = make_intent(world.topo, random.Random(11), "bandwidth", 3, "path2")
    for k in range(6):
        r = run_defense(world, attack_episode(world, it, k, "forgery", "replay_same_eid"), "BIND")
        assert r["flags"] and all(f[2] in ("REPLAY", "CMD_REPLAY") for f in r["flags"]), r["flags"]


def test_reorder_rejected(world):
    it = make_intent(world.topo, random.Random(12), "block", 4, "path2")
    ep = attack_episode(world, it, 4, "exec_tamper", "reorder")
    assert any(f[2] == "CMD_ORDER" for f in run_defense(world, ep, "BIND")["flags"])


def test_malformed_hop_payload_fails_closed(world):
    it = make_intent(world.topo, random.Random(13), "isolate", 5, "path2")
    ep = benign_episode(world, it, 5)
    bad = jws_sign({"iid": it["iid"]}, world.agents["parser"].key, "ib-hop")
    b = ep.bundle
    r = world.verifier("sdn").verify_chain(Bundle(b.intent, b.root, [bad] + b.hops[1:], b.certs, b.exec_artifact))
    assert not r.ok and r.cause == "HOP_FIELDS"


def test_wrong_controller_domain_rejected(world):
    it = make_intent(world.topo, random.Random(14), "slice", 1, "path2")
    ep = benign_episode(world, it, 1)  # executor in the 5g domain
    assert world.verifier("5g").chain(ep.bundle).ok
    assert not world.verifier("sdn").chain(ep.bundle).ok
