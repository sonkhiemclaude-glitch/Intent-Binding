import gzip

from intentbind.experiments.component import run_component, run_job
from intentbind.utils.config import load_config

from conftest import ROOT


def _cfg(**kw):
    return load_config(ROOT / "configs" / "synthetic_demo.yaml",
                       {"seeds": [3], "intents_per_seed": 3, "scope_modes": ["path2"], **kw})


def test_same_seed_same_rows():
    cfg = _cfg()
    assert run_job(3, "path2", cfg) == run_job(3, "path2", cfg)


def test_rows_do_not_depend_on_keys():
    a = run_job(3, "path2", _cfg(key_seed="a"))
    b = run_job(3, "path2", _cfg(key_seed=None))
    assert a == b


def test_csv_byte_identical_and_procs_independent(tmp_path):
    p1 = run_component(_cfg(), tmp_path / "a")
    p2 = run_component(_cfg(procs=2, seeds=[3, 4]), tmp_path / "b")
    p3 = run_component(_cfg(seeds=[3, 4]), tmp_path / "c")
    assert p1.read_bytes() == run_component(_cfg(), tmp_path / "d").read_bytes()
    assert p2.read_bytes() == p3.read_bytes()
    with gzip.open(p1, "rt") as f:
        assert f.readline().startswith("seed,mode,itype,n_ref,family,cls,defense")


def test_different_seed_differs():
    assert run_job(3, "path2", _cfg()) != run_job(4, "path2", _cfg(seeds=[4]))
