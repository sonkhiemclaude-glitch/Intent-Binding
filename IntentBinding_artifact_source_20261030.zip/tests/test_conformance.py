import random

import pytest

from intentbind.attacks.catalogue import ATTACKS
from intentbind.attacks.episodes import attack_episode
from intentbind.conformance.checker import Checker
from intentbind.conformance.ltlf import formula, holds, positions
from intentbind.data.schemas import validate_constraint
from intentbind.defenses.runner import run_defense
from intentbind.errors import NotApplicable
from intentbind.intents.compiler import INTENT_TYPES, compile_intent
from intentbind.intents.generator import make_intent
from intentbind.network import model as nm
from intentbind.pipeline.episode import benign_episode


def test_compiler_emits_known_templates_for_every_type(world):
    rng = random.Random(1)
    for k, t in enumerate(INTENT_TYPES):
        it = make_intent(world.topo, rng, t, k, "path2")
        assert it["constraints"]
        for c in it["constraints"]:
            validate_constraint(c)
        assert any(c["t"].startswith("goal") for c in it["constraints"])
        assert compile_intent(world.topo, t, it["spec"], "path2") == it["constraints"]


def test_path2_has_no_false_positive(world):
    rng = random.Random(4)
    for k in range(60):
        it = make_intent(world.topo, rng, INTENT_TYPES[k % 5], k, "path2")
        assert run_defense(world, benign_episode(world, it, k), "FULL")["flags"] == []


def test_monitor_matches_ltlf_semantics(world):
    """Hand-compiled monitors give the independent LTLf verdict on perturbed traces (Prop. 4)."""
    rng = random.Random(6)
    topo = world.topo
    for k in range(50):
        it = make_intent(topo, rng, INTENT_TYPES[k % 5], k, rng.choice(["strict", "path0", "path2"]))
        cmds = list(benign_episode(world, it, k).cmds)
        fam = rng.choice(["injection", "insider", "drift", None])
        if fam:
            try:
                cmds = attack_episode(world, it, k, fam, rng.choice(ATTACKS[fam]), n_refiners=1).cmds
            except NotApplicable:
                pass
        if rng.random() < 0.3:
            rng.shuffle(cmds)
        s0 = nm.initial_state(topo)
        P = positions(topo, s0, cmds)
        for c in it["constraints"]:
            cc = dict(c)
            if c["t"] == "precedence":
                cc["_vals"] = sorted({x.get(c["key"]) for x in cmds if x.get("op") in (c["a"], c["b"])}, key=str)
            ltl = holds(formula(topo, cc), P)
            chk = Checker(topo, [c], s0, "alarm")
            viol = any(chk.step(x)[1] for x in cmds)
            if c["t"].startswith("goal"):
                viol = bool(chk.finish())
            assert ltl == (not viol), (k, c["t"])


def test_block_mode_prevents_violating_state(world):
    rng = random.Random(7)
    topo = world.topo
    for k in range(60):
        it = make_intent(topo, rng, INTENT_TYPES[k % 5], k, "path0")
        fam = rng.choice(["injection", "insider", "drift"])
        try:
            ep = attack_episode(world, it, k, fam, rng.choice(ATTACKS[fam]), n_refiners=1)
        except NotApplicable:
            continue
        s0 = nm.initial_state(topo)
        chk = Checker(topo, it["constraints"], s0, "block")
        for x in ep.cmds:
            chk.step(x)
        P = positions(topo, s0, chk.trace)
        for c in it["constraints"]:
            if c["t"] in ("opset", "scope_sw", "scope_param", "bound", "frame", "invariant_reach"):
                assert holds(formula(topo, c), P)


def test_block_mode_respects_precedence(world):
    topo = world.topo
    it = make_intent(topo, random.Random(14), "slice", 6, "path2")
    cmds = list(reversed(benign_episode(world, it, 6).cmds))  # assignments before creation
    s0 = nm.initial_state(topo)
    chk = Checker(topo, it["constraints"], s0, "block")
    for x in cmds:
        chk.step(x)
    P = positions(topo, s0, chk.trace)
    for c in it["constraints"]:
        if c["t"] == "precedence":
            cc = dict(c, _vals=sorted({x.get(c["key"]) for x in chk.trace if x.get("op") in (c["a"], c["b"])},
                                      key=str))
            assert holds(formula(topo, cc), P)


@pytest.mark.parametrize("mode", ["strict", "path0", "path2"])
def test_scope_modes_nested(world, mode):
    """path2 admits at least the switches path0 admits, which admits at least strict's (Sec. 5)."""
    from intentbind.intents.compiler import scope_switches
    rng = random.Random(21)
    for k in range(15):
        t = ("bandwidth", "waypoint")[k % 2]
        it = make_intent(world.topo, rng, t, k, mode)
        s = {m: set(scope_switches(world.topo, t, it["spec"], m)) for m in ("strict", "path0", "path2")}
        assert s["strict"] <= s["path0"] <= s["path2"]
