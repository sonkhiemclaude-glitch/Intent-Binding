import pytest

from intentbind.binding import merkle_root_and_proofs, merkle_verify
from intentbind.crypto import JWSError, KeyPair, canon, h, jws_sign, jws_verify


def test_canon_rejects_float_and_sorts():
    assert canon({"b": 1, "a": [2, "x"]}) == b'{"a":[2,"x"],"b":1}'
    with pytest.raises(TypeError):
        canon({"a": 1.5})


def test_hash_is_sha256_of_canonical_json():
    import hashlib
    assert h({"b": 1, "a": 2}) == hashlib.sha256(b'{"a":2,"b":1}').hexdigest()


def test_jws_roundtrip_and_tamper():
    k = KeyPair.generate("k")
    t = jws_sign({"x": 1}, k, "t")
    assert jws_verify(t, k.pk)[1] == {"x": 1}
    hb, pb, sb = t.split(".")
    bad = hb + "." + pb[:-2] + ("AA" if pb[-2:] != "AA" else "BB") + "." + sb
    with pytest.raises(JWSError):
        jws_verify(bad, k.pk)
    with pytest.raises(JWSError):
        jws_verify(t, KeyPair.generate("o").pk)


def test_seeded_keys_are_deterministic_and_distinct():
    a, b = KeyPair.generate("x", b"s"), KeyPair.generate("x", b"s")
    assert a.pk_raw() == b.pk_raw()
    assert KeyPair.generate("y", b"s").pk_raw() != a.pk_raw()
    assert jws_sign({"x": 1}, a, "t") == jws_sign({"x": 1}, b, "t")  # Ed25519 is deterministic


@pytest.mark.parametrize("n", [1, 2, 3, 5, 8, 13])
def test_merkle(n):
    cmds = [{"op": "x", "i": i} for i in range(n)]
    root, proofs = merkle_root_and_proofs(cmds)
    for j, (c, p) in enumerate(zip(cmds, proofs)):
        assert merkle_verify(c, j, p, root)
    assert not merkle_verify({"op": "y"}, 0, proofs[0], root)
    if n > 1:
        assert not merkle_verify(cmds[1], 1, proofs[0], root)
        assert not merkle_verify(cmds[0], 1, proofs[0], root)  # index is bound into the leaf


def test_merkle_proof_length_is_logarithmic():
    cmds = [{"op": "x", "i": i} for i in range(64)]
    _, proofs = merkle_root_and_proofs(cmds)
    assert all(len(p) == 6 for p in proofs)
